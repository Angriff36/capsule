/**
 * Generated Manifest product-wiring bindings.
 * DO NOT EDIT — regenerate from IR via the wiring projection.
 *
 * This module does NOT generate UI. It provides typed client inputs,
 * trusted-context injection helpers, and invalidation metadata.
 */

export const WIRING_CONTRACT_HASH = "0316c79111f8aecc2a5b6841ff2be359239be8cb207727655dcf8ba4ccd2c3e4:06b7dec31def1f29cc03adb7ba52a450f2802272720bdcfcd4bbd3aedb74f96e:0861b118eaa6a83a9967ed0b71f90d8139877c79b6ce258ef0101de49c4f5bc8:0a9f778281608cd26bb45eaeabccf8dc2ec51f97fb5a4f3b637ddca88919dcf6:0f5f4fe542932fa133ec9d857a43dd1f154fd5915cb9104048bed9f9180b34f1:1854a8f2359e581edc177de41a884783adcbcc85bfca1efe56fa53942d9bb922:18e92c4c16ae436134bb34da461b9bc5c2e705ad9e372143fa4fe254affd9a33:21d57d616e827ed9eba8950af310277f2eb66471f5fba0eb3107b6da20518a15:24a28a86ed8d5207cebd1e31bc068bb1065c0f925e17f683711d771b797f0a94:2a01013fba2d1ff8774621ad2555e614295a07caf35089343024deded273bbfb:364b3b96fcd8f3fb90028b59cb634dfa76390b7a61bd98f178427f78cd1b2fa5:44817c0e4d994b4f9eaaec0ff77a7354d8c429d3ff64ed2ed697a04afa1ecc61:4ddbfd5dcbca31ec5e65b1bc8c7fb4c3a5114c4d43fed3108abcc506c52df544:4e98d2c148d64da23d416275679711659861fcbb02b90749171a66a5c310a512:4ec5fc5a8d9086b2ea720eaeede6d08c73e23624c155d5bf42d89d77e78f97ae:52bf9056917c6250dba159da29f7aaafac2f65f3050af2a5eb194be9a707f007:5684e36052f2f3e9f2970eddd04d2c910664e2ad238b7981517cc430f653a959:5a6d59634bc99c6820b53319f767e1d284a9a0136fa367c65f651c9ca8fa660f:5cbcf1d2ed5dd5c27c68e35afe234db4014ffb027f91be6b18096419731f4626:5f7c59531b5ddb5cc145fdc34df87a86401c89f25d80c45d8a6406e02fc298c7:5fab7113a1dac24c1565d20ad39ea54b4a6423687cfee845ae4d7afdd56d5cb6:740e5fd73da6f86a070e0435aae951f2008294e485361b48106344ac7eb3c920:7b2cc0e31b7c4c06582c7a72587c5c3782c0bf4344483952e25d8c01315e541c:8ba2ef2e0c4f041b349ead888c6a07203a63814f30c84cfea66447dfb430ca48:952203740dd05c52a2ee55ca78f80b811be3bb48449b03126e87f3171ef3179d:96b5958136a1a09ee039422008844ec9239f72349635f56a5a46ecb6a8b45740:9bd7fd575269fab78b265cc37ab2403ee389301a73457196d27e730ee6700254:a0cf07f3644a6db7bd90c804609100aedfa5d36db72b670f86cb1f14cc393963:a34e034bab205cb1d3c9e2cf46abbca10791fa81149520f876525690a5df3885:a75dc45988f7fcf22fc8397fd340666ff31cde4af8653c561f65d43ff418898d:b42238d427001b39dbfbd3becd1f66b96f676331afc164c7ccd1209349510271:b6c9fc82df46ff1bc7146dd50758304fa799f340ad58ff6abbfe8acb0fd0562f:b84efd99bf9cc24012aa4878eeb9a1227dec1c71a2964b544fded5923266471a:b9d877e0f0a31e49aeafcd9a666bf789995dad7dac4d1c177b953a18ff79081b:c2aaeb4df10a3e01aca6fe6d19916b99d7d3a25fe9005a76ff6f142db1a488f4:c482d82f5f59253e77c79804a11c46c29750c7b8a0e27d93db81ab06606cbc03:c5c3cb8a23265c76b507a7206d6a5353cead202dadcbc117b937c6082e568123:c6e45b19b85bc0b8984104efa85e6f12c60f381e4a1ba0340ac4c64d15f3c664:cabb3d721184454e6197c3b51ad513712b04642b05775eb540a53f807159e2e7:cfa8c6c27621f38fe254c8657e8c8215fcdcb6e1ef47b0d6308bf34f436af3b2:cfd3f63f28e209efbcb595ad4213aefe472f404b76538660d27817a45ea19e4e:d42158155248e729c7f6c0d953412b64694a10568af4ee4ba1b9885104915afc:d734ba9287bb449fad867011f13ea06e9ed4ea523f81065b1788aa578732e6b8:df9d88910d9244b2e2133bb65f6aabfc3368222cdf8e9530c8c535d376b0cd8e:e0075d8a464086e6ce13e8e365b0c886dbca7ad52d30a09e2f2f0d4523062adb:e74b9b5daa7d95fce8cdb2c07b6aa64c2324ceacb79698bf2d1dee829c408cdc:ea8e764f3555eee1381b681fba30974755c9317d22b80db43cc44fd691eb6368:ec0ea6723a647ff6ac911057fb10a8125f19feb51d374d0ec502262f6b1a277c:ec9971ce1c031ad5c042cb3dcc36c516e37a4d1509a302f7aea0e0b293452f4c:edbdc523cc9e747e626e5ea5723754a8b8ade05e42e937b83081467b2f4e767e:f11fe404117b95e0128c4db248a7a1b6a1fe4cfa8ad0dc423cbc905708430042:f24d1f4d667f7fc0c5cfb7bfe4e957bc65ed819dd017d1d61b07692e22f6a6b0:f9416be6404f3534e9810933f0b9bedad6b7280982da3a18434d0cbce353ae6a:fb1267c682a05285e37ae1447389ce5fc323b2f4241c81bb03e2048ffa8f8610:fdc28fad241416ceed92a345c3acf5b15954417bb2bda3075aff77e7beebeb45:fe26a5b7a9db4d5795174080fc6afc7a994dd04143b27a188c3d51e37ad19d52";

// --- Attachment.attach ---
export interface AttachmentAttachClientInput {
  /** Allowed: "eventRecord" | "client" | "contract" | "vendor" | "delivery" | "closeout" */
  parentType: "eventRecord" | "client" | "contract" | "vendor" | "delivery" | "closeout";
  parentId: string;
  fileName: string;
  contentType: string;
  /** Bounds: 0..∞ */
  fileSize: number;
  storageId: string;
  /** Allowed: "venueCondition" | "leftoverFood" | "equipmentReturn" */
  evidenceType?: "venueCondition" | "leftoverFood" | "equipmentReturn";
}

export const AttachmentAttachCapability = {
  capabilityId: "Attachment.attach",
  entity: "Attachment",
  command: "attach",
  route: "/api/manifest/Attachment/commands/attach",
  instanceCommand: true,
  clientParameterNames: ["parentType","parentId","fileName","contentType","fileSize","storageId","evidenceType"],
  serverParameterNames: [],
  emits: ["AttachmentAdded"],
} as const;

/**
 * Build command input for Attachment.attach.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindAttachmentAttachInput(client: AttachmentAttachClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Attachment.attach. */
export const AttachmentAttachInvalidation = [
  {
    "kind": "entityList",
    "entity": "Attachment",
    "queryKeyHint": "queryKeys.attachment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Attachment",
    "queryKeyHint": "queryKeys.attachment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Attachment.remove ---
export type AttachmentRemoveClientInput = Record<string, never>;

export const AttachmentRemoveCapability = {
  capabilityId: "Attachment.remove",
  entity: "Attachment",
  command: "remove",
  route: "/api/manifest/Attachment/commands/remove",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["AttachmentRemoved"],
} as const;

/**
 * Build command input for Attachment.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindAttachmentRemoveInput(client: AttachmentRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Attachment.remove. */
export const AttachmentRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "Attachment",
    "queryKeyHint": "queryKeys.attachment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Attachment",
    "queryKeyHint": "queryKeys.attachment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- AvailabilityWindow.declare ---
export interface AvailabilityWindowDeclareClientInput {
  personId: string;
  /** Must not be "". */
  startsAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  endsAt: string & { readonly __nonEmpty?: true };
  /** Allowed: "available" | "unavailable" */
  kind?: "available" | "unavailable";
  notes?: string;
}

export const AvailabilityWindowDeclareCapability = {
  capabilityId: "AvailabilityWindow.declare",
  entity: "AvailabilityWindow",
  command: "declare",
  route: "/api/manifest/AvailabilityWindow/commands/declare",
  instanceCommand: true,
  clientParameterNames: ["personId","startsAt","endsAt","kind","notes"],
  serverParameterNames: [],
  emits: ["AvailabilityDeclared"],
} as const;

/**
 * Build command input for AvailabilityWindow.declare.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindAvailabilityWindowDeclareInput(client: AvailabilityWindowDeclareClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful AvailabilityWindow.declare. */
export const AvailabilityWindowDeclareInvalidation = [
  {
    "kind": "entityList",
    "entity": "AvailabilityWindow",
    "queryKeyHint": "queryKeys.availabilityWindow.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "AvailabilityWindow",
    "queryKeyHint": "queryKeys.availabilityWindow.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- AvailabilityWindow.withdraw ---
export type AvailabilityWindowWithdrawClientInput = Record<string, never>;

export const AvailabilityWindowWithdrawCapability = {
  capabilityId: "AvailabilityWindow.withdraw",
  entity: "AvailabilityWindow",
  command: "withdraw",
  route: "/api/manifest/AvailabilityWindow/commands/withdraw",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["AvailabilityWithdrawn"],
} as const;

/**
 * Build command input for AvailabilityWindow.withdraw.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindAvailabilityWindowWithdrawInput(client: AvailabilityWindowWithdrawClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful AvailabilityWindow.withdraw. */
export const AvailabilityWindowWithdrawInvalidation = [
  {
    "kind": "entityList",
    "entity": "AvailabilityWindow",
    "queryKeyHint": "queryKeys.availabilityWindow.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "AvailabilityWindow",
    "queryKeyHint": "queryKeys.availabilityWindow.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for AvailabilityWindow.withdraw. */
export const AvailabilityWindowWithdrawLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "withdrawn",
    "proven": true
  }
] as const;

// --- Client.archive ---
export interface ClientArchiveClientInput {
  reason: string;
}

export const ClientArchiveCapability = {
  capabilityId: "Client.archive",
  entity: "Client",
  command: "archive",
  route: "/api/manifest/Client/commands/archive",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["ClientArchived"],
} as const;

/**
 * Build command input for Client.archive.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientArchiveInput(client: ClientArchiveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Client.archive. */
export const ClientArchiveInvalidation = [
  {
    "kind": "entityList",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Client.archive. */
export const ClientArchiveLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "archived",
    "proven": true
  }
] as const;

// --- Client.assignOwner ---
export interface ClientAssignOwnerClientInput {
  assignedToId?: string;
}

export const ClientAssignOwnerCapability = {
  capabilityId: "Client.assignOwner",
  entity: "Client",
  command: "assignOwner",
  route: "/api/manifest/Client/commands/assignOwner",
  instanceCommand: true,
  clientParameterNames: ["assignedToId"],
  serverParameterNames: [],
  emits: ["ClientOwnerAssigned"],
} as const;

/**
 * Build command input for Client.assignOwner.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientAssignOwnerInput(client: ClientAssignOwnerClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Client.assignOwner. */
export const ClientAssignOwnerInvalidation = [
  {
    "kind": "entityList",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Client.changeBillingProfile ---
export interface ClientChangeBillingProfileClientInput {
  /** Bounds: 0..365 */
  paymentTermsDays: number;
  taxExempt: boolean;
  taxId?: string;
}

export const ClientChangeBillingProfileCapability = {
  capabilityId: "Client.changeBillingProfile",
  entity: "Client",
  command: "changeBillingProfile",
  route: "/api/manifest/Client/commands/changeBillingProfile",
  instanceCommand: true,
  clientParameterNames: ["paymentTermsDays","taxExempt","taxId"],
  serverParameterNames: [],
  emits: ["ClientBillingProfileChanged"],
} as const;

/**
 * Build command input for Client.changeBillingProfile.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientChangeBillingProfileInput(client: ClientChangeBillingProfileClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Client.changeBillingProfile. */
export const ClientChangeBillingProfileInvalidation = [
  {
    "kind": "entityList",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Client.changeContact ---
export interface ClientChangeContactClientInput {
  email?: string;
  phone?: string;
  website?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  region?: string;
  postalCode?: string;
  countryCode?: string;
}

export const ClientChangeContactCapability = {
  capabilityId: "Client.changeContact",
  entity: "Client",
  command: "changeContact",
  route: "/api/manifest/Client/commands/changeContact",
  instanceCommand: true,
  clientParameterNames: ["email","phone","website","addressLine1","addressLine2","city","region","postalCode","countryCode"],
  serverParameterNames: [],
  emits: ["ClientContactChanged"],
} as const;

/**
 * Build command input for Client.changeContact.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientChangeContactInput(client: ClientChangeContactClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Client.changeContact. */
export const ClientChangeContactInvalidation = [
  {
    "kind": "entityList",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Client.markMerged ---
export interface ClientMarkMergedClientInput {
  clientId: string;
}

export const ClientMarkMergedCapability = {
  capabilityId: "Client.markMerged",
  entity: "Client",
  command: "markMerged",
  route: "/api/manifest/Client/commands/markMerged",
  instanceCommand: true,
  clientParameterNames: ["clientId"],
  serverParameterNames: [],
  emits: ["ClientMerged"],
} as const;

/**
 * Build command input for Client.markMerged.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientMarkMergedInput(client: ClientMarkMergedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Client.markMerged. */
export const ClientMarkMergedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Client.markMerged. */
export const ClientMarkMergedLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "archived",
    "proven": true
  }
] as const;

// --- Client.reactivate ---
export type ClientReactivateClientInput = Record<string, never>;

export const ClientReactivateCapability = {
  capabilityId: "Client.reactivate",
  entity: "Client",
  command: "reactivate",
  route: "/api/manifest/Client/commands/reactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ClientReactivated"],
} as const;

/**
 * Build command input for Client.reactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientReactivateInput(client: ClientReactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Client.reactivate. */
export const ClientReactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Client.reactivate. */
export const ClientReactivateLifecycle = [
  {
    "property": "status",
    "from": "archived",
    "to": "active",
    "proven": true
  }
] as const;

// --- Client.register ---
export interface ClientRegisterClientInput {
  /** Allowed: "company" | "person" */
  clientType: "company" | "person";
  companyName?: string;
  givenName?: string;
  familyName?: string;
  email?: string;
  phone?: string;
  website?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  region?: string;
  postalCode?: string;
  countryCode?: string;
  taxId?: string;
  taxExempt?: boolean;
  /** Bounds: 0..365 */
  paymentTermsDays?: number;
  notes?: string;
  assignedToId?: string;
}

export const ClientRegisterCapability = {
  capabilityId: "Client.register",
  entity: "Client",
  command: "register",
  route: "/api/manifest/Client/commands/register",
  instanceCommand: true,
  clientParameterNames: ["clientType","companyName","givenName","familyName","email","phone","website","addressLine1","addressLine2","city","region","postalCode","countryCode","taxId","taxExempt","paymentTermsDays","notes","assignedToId"],
  serverParameterNames: [],
  emits: ["ClientRegistered"],
} as const;

/**
 * Build command input for Client.register.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientRegisterInput(client: ClientRegisterClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Client.register. */
export const ClientRegisterInvalidation = [
  {
    "kind": "entityList",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Client.stageClientMerge ---
export interface ClientStageClientMergeClientInput {
  clientMergeId: string;
  primaryClientId: string;
}

export const ClientStageClientMergeCapability = {
  capabilityId: "Client.stageClientMerge",
  entity: "Client",
  command: "stageClientMerge",
  route: "/api/manifest/Client/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","primaryClientId"],
  serverParameterNames: [],
  emits: ["ClientMergeStaged"],
} as const;

/**
 * Build command input for Client.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientStageClientMergeInput(client: ClientStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Client.stageClientMerge. */
export const ClientStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Client",
    "queryKeyHint": "queryKeys.client.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ClientCommunication.record ---
export interface ClientCommunicationRecordClientInput {
  clientContactId?: string;
  eventId?: string;
  /** Must not be "". */
  occurredAt: string & { readonly __nonEmpty?: true };
  /** Allowed: "call" | "email" | "meeting" */
  medium: "call" | "email" | "meeting";
  summary: string;
  authorName: string;
}

export const ClientCommunicationRecordCapability = {
  capabilityId: "ClientCommunication.record",
  entity: "ClientCommunication",
  command: "record",
  route: "/api/manifest/ClientCommunication/commands/record",
  instanceCommand: true,
  clientParameterNames: ["clientContactId","eventId","occurredAt","medium","summary","authorName"],
  serverParameterNames: [],
  emits: ["ClientCommunicationRecorded"],
} as const;

/**
 * Build command input for ClientCommunication.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientCommunicationRecordInput(client: ClientCommunicationRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ClientCommunication.record. */
export const ClientCommunicationRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "ClientCommunication",
    "queryKeyHint": "queryKeys.clientCommunication.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ClientCommunication",
    "queryKeyHint": "queryKeys.clientCommunication.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ClientContact.add ---
export interface ClientContactAddClientInput {
  clientId: string;
  givenName: string;
  familyName?: string;
  title?: string;
  email?: string;
  phone?: string;
  mobile?: string;
  isPrimary?: boolean;
  isBillingContact?: boolean;
  notes?: string;
}

export const ClientContactAddCapability = {
  capabilityId: "ClientContact.add",
  entity: "ClientContact",
  command: "add",
  route: "/api/manifest/ClientContact/commands/add",
  instanceCommand: true,
  clientParameterNames: ["clientId","givenName","familyName","title","email","phone","mobile","isPrimary","isBillingContact","notes"],
  serverParameterNames: [],
  emits: ["ClientContactAdded"],
} as const;

/**
 * Build command input for ClientContact.add.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientContactAddInput(client: ClientContactAddClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ClientContact.add. */
export const ClientContactAddInvalidation = [
  {
    "kind": "entityList",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ClientContact.reassignClient ---
export type ClientContactReassignClientClientInput = Record<string, never>;

export const ClientContactReassignClientCapability = {
  capabilityId: "ClientContact.reassignClient",
  entity: "ClientContact",
  command: "reassignClient",
  route: "/api/manifest/ClientContact/commands/reassignClient",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ClientContactReassigned"],
} as const;

/**
 * Build command input for ClientContact.reassignClient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientContactReassignClientInput(client: ClientContactReassignClientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ClientContact.reassignClient. */
export const ClientContactReassignClientInvalidation = [
  {
    "kind": "entityList",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ClientContact.remove ---
export type ClientContactRemoveClientInput = Record<string, never>;

export const ClientContactRemoveCapability = {
  capabilityId: "ClientContact.remove",
  entity: "ClientContact",
  command: "remove",
  route: "/api/manifest/ClientContact/commands/remove",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ClientContactRemoved"],
} as const;

/**
 * Build command input for ClientContact.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientContactRemoveInput(client: ClientContactRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ClientContact.remove. */
export const ClientContactRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ClientContact.remove. */
export const ClientContactRemoveLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "removed",
    "proven": true
  }
] as const;

// --- ClientContact.setPrimary ---
export type ClientContactSetPrimaryClientInput = Record<string, never>;

export const ClientContactSetPrimaryCapability = {
  capabilityId: "ClientContact.setPrimary",
  entity: "ClientContact",
  command: "setPrimary",
  route: "/api/manifest/ClientContact/commands/setPrimary",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ClientContactPrimarySet"],
} as const;

/**
 * Build command input for ClientContact.setPrimary.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientContactSetPrimaryInput(client: ClientContactSetPrimaryClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ClientContact.setPrimary. */
export const ClientContactSetPrimaryInvalidation = [
  {
    "kind": "entityList",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ClientContact.stageClientMerge ---
export interface ClientContactStageClientMergeClientInput {
  clientMergeId: string;
  clientId: string;
}

export const ClientContactStageClientMergeCapability = {
  capabilityId: "ClientContact.stageClientMerge",
  entity: "ClientContact",
  command: "stageClientMerge",
  route: "/api/manifest/ClientContact/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","clientId"],
  serverParameterNames: [],
  emits: ["ClientContactMergeStaged"],
} as const;

/**
 * Build command input for ClientContact.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientContactStageClientMergeInput(client: ClientContactStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ClientContact.stageClientMerge. */
export const ClientContactStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ClientContact.updateDetails ---
export interface ClientContactUpdateDetailsClientInput {
  givenName: string;
  familyName?: string;
  title?: string;
  email?: string;
  phone?: string;
  mobile?: string;
  isBillingContact?: boolean;
  notes?: string;
}

export const ClientContactUpdateDetailsCapability = {
  capabilityId: "ClientContact.updateDetails",
  entity: "ClientContact",
  command: "updateDetails",
  route: "/api/manifest/ClientContact/commands/updateDetails",
  instanceCommand: true,
  clientParameterNames: ["givenName","familyName","title","email","phone","mobile","isBillingContact","notes"],
  serverParameterNames: [],
  emits: ["ClientContactDetailsUpdated"],
} as const;

/**
 * Build command input for ClientContact.updateDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientContactUpdateDetailsInput(client: ClientContactUpdateDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ClientContact.updateDetails. */
export const ClientContactUpdateDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ClientContact",
    "queryKeyHint": "queryKeys.clientContact.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ClientMerge.merge ---
export interface ClientMergeMergeClientInput {
  primaryClientId: string;
  duplicateClientId: string;
}

export const ClientMergeMergeCapability = {
  capabilityId: "ClientMerge.merge",
  entity: "ClientMerge",
  command: "merge",
  route: "/api/manifest/ClientMerge/commands/merge",
  instanceCommand: true,
  clientParameterNames: ["primaryClientId","duplicateClientId"],
  serverParameterNames: [],
  emits: ["ClientMergeCompleted"],
} as const;

/**
 * Build command input for ClientMerge.merge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindClientMergeMergeInput(client: ClientMergeMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ClientMerge.merge. */
export const ClientMergeMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "ClientMerge",
    "queryKeyHint": "queryKeys.clientMerge.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ClientMerge",
    "queryKeyHint": "queryKeys.clientMerge.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Contract.draft ---
export interface ContractDraftClientInput {
  eventId: string;
  clientId: string;
  title: string;
  contractNumber?: string;
  documentUrl?: string;
  expiresAt?: string;
  notes?: string;
}

export const ContractDraftCapability = {
  capabilityId: "Contract.draft",
  entity: "Contract",
  command: "draft",
  route: "/api/manifest/Contract/commands/draft",
  instanceCommand: true,
  clientParameterNames: ["eventId","clientId","title","contractNumber","documentUrl","expiresAt","notes"],
  serverParameterNames: [],
  emits: ["ContractDrafted"],
} as const;

/**
 * Build command input for Contract.draft.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindContractDraftInput(client: ContractDraftClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Contract.draft. */
export const ContractDraftInvalidation = [
  {
    "kind": "entityList",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Contract.expire ---
export type ContractExpireClientInput = Record<string, never>;

export const ContractExpireCapability = {
  capabilityId: "Contract.expire",
  entity: "Contract",
  command: "expire",
  route: "/api/manifest/Contract/commands/expire",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ContractExpired"],
} as const;

/**
 * Build command input for Contract.expire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindContractExpireInput(client: ContractExpireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Contract.expire. */
export const ContractExpireInvalidation = [
  {
    "kind": "entityList",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Contract.expire. */
export const ContractExpireLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "expired",
    "proven": true
  },
  {
    "property": "status",
    "from": "viewed",
    "to": "expired",
    "proven": true
  }
] as const;

// --- Contract.markViewed ---
export type ContractMarkViewedClientInput = Record<string, never>;

export const ContractMarkViewedCapability = {
  capabilityId: "Contract.markViewed",
  entity: "Contract",
  command: "markViewed",
  route: "/api/manifest/Contract/commands/markViewed",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ContractViewed"],
} as const;

/**
 * Build command input for Contract.markViewed.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindContractMarkViewedInput(client: ContractMarkViewedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Contract.markViewed. */
export const ContractMarkViewedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Contract.markViewed. */
export const ContractMarkViewedLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "viewed",
    "proven": true
  }
] as const;

// --- Contract.markVoided ---
export interface ContractMarkVoidedClientInput {
  reason: string;
}

export const ContractMarkVoidedCapability = {
  capabilityId: "Contract.markVoided",
  entity: "Contract",
  command: "markVoided",
  route: "/api/manifest/Contract/commands/markVoided",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["ContractVoided"],
} as const;

/**
 * Build command input for Contract.markVoided.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindContractMarkVoidedInput(client: ContractMarkVoidedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Contract.markVoided. */
export const ContractMarkVoidedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Contract.markVoided. */
export const ContractMarkVoidedLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "voided",
    "proven": true
  },
  {
    "property": "status",
    "from": "viewed",
    "to": "voided",
    "proven": true
  }
] as const;

// --- Contract.reassignClient ---
export type ContractReassignClientClientInput = Record<string, never>;

export const ContractReassignClientCapability = {
  capabilityId: "Contract.reassignClient",
  entity: "Contract",
  command: "reassignClient",
  route: "/api/manifest/Contract/commands/reassignClient",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ContractClientReassigned"],
} as const;

/**
 * Build command input for Contract.reassignClient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindContractReassignClientInput(client: ContractReassignClientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Contract.reassignClient. */
export const ContractReassignClientInvalidation = [
  {
    "kind": "entityList",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Contract.send ---
export type ContractSendClientInput = Record<string, never>;

export const ContractSendCapability = {
  capabilityId: "Contract.send",
  entity: "Contract",
  command: "send",
  route: "/api/manifest/Contract/commands/send",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ContractSent"],
} as const;

/**
 * Build command input for Contract.send.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindContractSendInput(client: ContractSendClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Contract.send. */
export const ContractSendInvalidation = [
  {
    "kind": "entityList",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Contract.send. */
export const ContractSendLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "sent",
    "proven": true
  }
] as const;

// --- Contract.sign ---
export interface ContractSignClientInput {
  signedBy: string;
}

export const ContractSignCapability = {
  capabilityId: "Contract.sign",
  entity: "Contract",
  command: "sign",
  route: "/api/manifest/Contract/commands/sign",
  instanceCommand: true,
  clientParameterNames: ["signedBy"],
  serverParameterNames: [],
  emits: ["ContractSigned"],
} as const;

/**
 * Build command input for Contract.sign.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindContractSignInput(client: ContractSignClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Contract.sign. */
export const ContractSignInvalidation = [
  {
    "kind": "entityList",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Contract.sign. */
export const ContractSignLifecycle = [
  {
    "property": "status",
    "from": "viewed",
    "to": "signed",
    "proven": true
  }
] as const;

// --- Contract.stageClientMerge ---
export interface ContractStageClientMergeClientInput {
  clientMergeId: string;
  clientId: string;
}

export const ContractStageClientMergeCapability = {
  capabilityId: "Contract.stageClientMerge",
  entity: "Contract",
  command: "stageClientMerge",
  route: "/api/manifest/Contract/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","clientId"],
  serverParameterNames: [],
  emits: ["ContractClientMergeStaged"],
} as const;

/**
 * Build command input for Contract.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindContractStageClientMergeInput(client: ContractStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Contract.stageClientMerge. */
export const ContractStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Contract",
    "queryKeyHint": "queryKeys.contract.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- CorrectiveAction.close ---
export interface CorrectiveActionCloseClientInput {
  resolutionNotes: string;
}

export const CorrectiveActionCloseCapability = {
  capabilityId: "CorrectiveAction.close",
  entity: "CorrectiveAction",
  command: "close",
  route: "/api/manifest/CorrectiveAction/commands/close",
  instanceCommand: true,
  clientParameterNames: ["resolutionNotes"],
  serverParameterNames: [],
  emits: ["CorrectiveActionClosed"],
} as const;

/**
 * Build command input for CorrectiveAction.close.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindCorrectiveActionCloseInput(client: CorrectiveActionCloseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful CorrectiveAction.close. */
export const CorrectiveActionCloseInvalidation = [
  {
    "kind": "entityList",
    "entity": "CorrectiveAction",
    "queryKeyHint": "queryKeys.correctiveAction.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "CorrectiveAction",
    "queryKeyHint": "queryKeys.correctiveAction.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for CorrectiveAction.close. */
export const CorrectiveActionCloseLifecycle = [
  {
    "property": "status",
    "from": "open",
    "to": "closed",
    "proven": true
  }
] as const;

// --- CorrectiveAction.open ---
export interface CorrectiveActionOpenClientInput {
  incidentId: string;
  eventId: string;
  description: string;
}

export const CorrectiveActionOpenCapability = {
  capabilityId: "CorrectiveAction.open",
  entity: "CorrectiveAction",
  command: "open",
  route: "/api/manifest/CorrectiveAction/commands/open",
  instanceCommand: true,
  clientParameterNames: ["incidentId","eventId","description"],
  serverParameterNames: [],
  emits: ["CorrectiveActionOpened"],
} as const;

/**
 * Build command input for CorrectiveAction.open.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindCorrectiveActionOpenInput(client: CorrectiveActionOpenClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful CorrectiveAction.open. */
export const CorrectiveActionOpenInvalidation = [
  {
    "kind": "entityList",
    "entity": "CorrectiveAction",
    "queryKeyHint": "queryKeys.correctiveAction.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "CorrectiveAction",
    "queryKeyHint": "queryKeys.correctiveAction.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- CreditMemo.issue ---
export interface CreditMemoIssueClientInput {
  sourceInvoiceId: string;
  clientId: string;
  creditMemoNumber: string;
  /** Bounds: 1..∞ */
  amount: number;
  reason: string;
  /** Allowed: "apply_to_balance" | "carry_forward" */
  disposition: "apply_to_balance" | "carry_forward";
  targetInvoiceId?: string;
  eventId?: string;
}

export const CreditMemoIssueCapability = {
  capabilityId: "CreditMemo.issue",
  entity: "CreditMemo",
  command: "issue",
  route: "/api/manifest/CreditMemo/commands/issue",
  instanceCommand: true,
  clientParameterNames: ["sourceInvoiceId","clientId","creditMemoNumber","amount","reason","disposition","targetInvoiceId","eventId"],
  serverParameterNames: [],
  emits: ["CreditMemoIssued"],
} as const;

/**
 * Build command input for CreditMemo.issue.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindCreditMemoIssueInput(client: CreditMemoIssueClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful CreditMemo.issue. */
export const CreditMemoIssueInvalidation = [
  {
    "kind": "entityList",
    "entity": "CreditMemo",
    "queryKeyHint": "queryKeys.creditMemo.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "CreditMemo",
    "queryKeyHint": "queryKeys.creditMemo.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- CreditMemo.reassignClient ---
export type CreditMemoReassignClientClientInput = Record<string, never>;

export const CreditMemoReassignClientCapability = {
  capabilityId: "CreditMemo.reassignClient",
  entity: "CreditMemo",
  command: "reassignClient",
  route: "/api/manifest/CreditMemo/commands/reassignClient",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["CreditMemoClientReassigned"],
} as const;

/**
 * Build command input for CreditMemo.reassignClient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindCreditMemoReassignClientInput(client: CreditMemoReassignClientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful CreditMemo.reassignClient. */
export const CreditMemoReassignClientInvalidation = [
  {
    "kind": "entityList",
    "entity": "CreditMemo",
    "queryKeyHint": "queryKeys.creditMemo.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "CreditMemo",
    "queryKeyHint": "queryKeys.creditMemo.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- CreditMemo.stageClientMerge ---
export interface CreditMemoStageClientMergeClientInput {
  clientMergeId: string;
  clientId: string;
}

export const CreditMemoStageClientMergeCapability = {
  capabilityId: "CreditMemo.stageClientMerge",
  entity: "CreditMemo",
  command: "stageClientMerge",
  route: "/api/manifest/CreditMemo/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","clientId"],
  serverParameterNames: [],
  emits: ["CreditMemoClientMergeStaged"],
} as const;

/**
 * Build command input for CreditMemo.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindCreditMemoStageClientMergeInput(client: CreditMemoStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful CreditMemo.stageClientMerge. */
export const CreditMemoStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "CreditMemo",
    "queryKeyHint": "queryKeys.creditMemo.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "CreditMemo",
    "queryKeyHint": "queryKeys.creditMemo.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Delivery.cancel ---
export interface DeliveryCancelClientInput {
  reason: string;
}

export const DeliveryCancelCapability = {
  capabilityId: "Delivery.cancel",
  entity: "Delivery",
  command: "cancel",
  route: "/api/manifest/Delivery/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["DeliveryCancelled"],
} as const;

/**
 * Build command input for Delivery.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDeliveryCancelInput(client: DeliveryCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Delivery.cancel. */
export const DeliveryCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Delivery.cancel. */
export const DeliveryCancelLifecycle = [
  {
    "property": "status",
    "from": "scheduled",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "in_transit",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- Delivery.confirmDelivery ---
export type DeliveryConfirmDeliveryClientInput = Record<string, never>;

export const DeliveryConfirmDeliveryCapability = {
  capabilityId: "Delivery.confirmDelivery",
  entity: "Delivery",
  command: "confirmDelivery",
  route: "/api/manifest/Delivery/commands/confirmDelivery",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["DeliveryConfirmed"],
} as const;

/**
 * Build command input for Delivery.confirmDelivery.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDeliveryConfirmDeliveryInput(client: DeliveryConfirmDeliveryClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Delivery.confirmDelivery. */
export const DeliveryConfirmDeliveryInvalidation = [
  {
    "kind": "entityList",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Delivery.confirmDelivery. */
export const DeliveryConfirmDeliveryLifecycle = [
  {
    "property": "status",
    "from": "in_transit",
    "to": "delivered",
    "proven": true
  }
] as const;

// --- Delivery.markFailed ---
export interface DeliveryMarkFailedClientInput {
  reason: string;
}

export const DeliveryMarkFailedCapability = {
  capabilityId: "Delivery.markFailed",
  entity: "Delivery",
  command: "markFailed",
  route: "/api/manifest/Delivery/commands/markFailed",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["DeliveryFailed"],
} as const;

/**
 * Build command input for Delivery.markFailed.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDeliveryMarkFailedInput(client: DeliveryMarkFailedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Delivery.markFailed. */
export const DeliveryMarkFailedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Delivery.markFailed. */
export const DeliveryMarkFailedLifecycle = [
  {
    "property": "status",
    "from": "scheduled",
    "to": "failed",
    "proven": true
  },
  {
    "property": "status",
    "from": "in_transit",
    "to": "failed",
    "proven": true
  }
] as const;

// --- Delivery.schedule ---
export interface DeliveryScheduleClientInput {
  packListId: string;
  eventId: string;
  destination: string;
  /** Must not be "". */
  windowStartsAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  windowEndsAt: string & { readonly __nonEmpty?: true };
  driverId?: string;
  notes?: string;
}

export const DeliveryScheduleCapability = {
  capabilityId: "Delivery.schedule",
  entity: "Delivery",
  command: "schedule",
  route: "/api/manifest/Delivery/commands/schedule",
  instanceCommand: true,
  clientParameterNames: ["packListId","eventId","destination","windowStartsAt","windowEndsAt","driverId","notes"],
  serverParameterNames: [],
  emits: ["DeliveryScheduled"],
} as const;

/**
 * Build command input for Delivery.schedule.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDeliveryScheduleInput(client: DeliveryScheduleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Delivery.schedule. */
export const DeliveryScheduleInvalidation = [
  {
    "kind": "entityList",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Delivery.startTransit ---
export type DeliveryStartTransitClientInput = Record<string, never>;

export const DeliveryStartTransitCapability = {
  capabilityId: "Delivery.startTransit",
  entity: "Delivery",
  command: "startTransit",
  route: "/api/manifest/Delivery/commands/startTransit",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["DeliveryTransitStarted"],
} as const;

/**
 * Build command input for Delivery.startTransit.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDeliveryStartTransitInput(client: DeliveryStartTransitClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Delivery.startTransit. */
export const DeliveryStartTransitInvalidation = [
  {
    "kind": "entityList",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Delivery",
    "queryKeyHint": "queryKeys.delivery.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Delivery.startTransit. */
export const DeliveryStartTransitLifecycle = [
  {
    "property": "status",
    "from": "scheduled",
    "to": "in_transit",
    "proven": true
  }
] as const;

// --- Dish.classifyAllergens ---
export interface DishClassifyAllergensClientInput {
  allergenSummary: ("milk" | "eggs" | "fish" | "crustacean_shellfish" | "tree_nuts" | "peanuts" | "wheat" | "soybeans" | "sesame")[];
}

export const DishClassifyAllergensCapability = {
  capabilityId: "Dish.classifyAllergens",
  entity: "Dish",
  command: "classifyAllergens",
  route: "/api/manifest/Dish/commands/classifyAllergens",
  instanceCommand: true,
  clientParameterNames: ["allergenSummary"],
  serverParameterNames: [],
  emits: ["DishAllergensClassified"],
} as const;

/**
 * Build command input for Dish.classifyAllergens.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishClassifyAllergensInput(client: DishClassifyAllergensClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Dish.classifyAllergens. */
export const DishClassifyAllergensInvalidation = [
  {
    "kind": "entityList",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Dish.introduce ---
export interface DishIntroduceClientInput {
  name: string;
  /** Bounds: 1..∞ */
  portionSize: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  portionUnit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  description?: string;
  category?: string;
  course?: string;
  serviceStyle?: string;
  dietaryTags?: string[];
  allergenSummary?: ("milk" | "eggs" | "fish" | "crustacean_shellfish" | "tree_nuts" | "peanuts" | "wheat" | "soybeans" | "sesame")[];
}

export const DishIntroduceCapability = {
  capabilityId: "Dish.introduce",
  entity: "Dish",
  command: "introduce",
  route: "/api/manifest/Dish/commands/introduce",
  instanceCommand: true,
  clientParameterNames: ["name","portionSize","portionUnit","description","category","course","serviceStyle","dietaryTags","allergenSummary"],
  serverParameterNames: [],
  emits: ["DishIntroduced"],
} as const;

/**
 * Build command input for Dish.introduce.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishIntroduceInput(client: DishIntroduceClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Dish.introduce. */
export const DishIntroduceInvalidation = [
  {
    "kind": "entityList",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Dish.reinstate ---
export type DishReinstateClientInput = Record<string, never>;

export const DishReinstateCapability = {
  capabilityId: "Dish.reinstate",
  entity: "Dish",
  command: "reinstate",
  route: "/api/manifest/Dish/commands/reinstate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["DishReinstated"],
} as const;

/**
 * Build command input for Dish.reinstate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishReinstateInput(client: DishReinstateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Dish.reinstate. */
export const DishReinstateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Dish.reinstate. */
export const DishReinstateLifecycle = [
  {
    "property": "status",
    "from": "retired",
    "to": "active",
    "proven": true
  }
] as const;

// --- Dish.retire ---
export interface DishRetireClientInput {
  reason: string;
}

export const DishRetireCapability = {
  capabilityId: "Dish.retire",
  entity: "Dish",
  command: "retire",
  route: "/api/manifest/Dish/commands/retire",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["DishRetired"],
} as const;

/**
 * Build command input for Dish.retire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishRetireInput(client: DishRetireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Dish.retire. */
export const DishRetireInvalidation = [
  {
    "kind": "entityList",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Dish.retire. */
export const DishRetireLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "retired",
    "proven": true
  }
] as const;

// --- Dish.reviseDetails ---
export interface DishReviseDetailsClientInput {
  name: string;
  description?: string;
  category?: string;
  course?: string;
  serviceStyle?: string;
  dietaryTags?: string[];
}

export const DishReviseDetailsCapability = {
  capabilityId: "Dish.reviseDetails",
  entity: "Dish",
  command: "reviseDetails",
  route: "/api/manifest/Dish/commands/reviseDetails",
  instanceCommand: true,
  clientParameterNames: ["name","description","category","course","serviceStyle","dietaryTags"],
  serverParameterNames: [],
  emits: ["DishDetailsRevised"],
} as const;

/**
 * Build command input for Dish.reviseDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishReviseDetailsInput(client: DishReviseDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Dish.reviseDetails. */
export const DishReviseDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Dish.updatePortioning ---
export interface DishUpdatePortioningClientInput {
  /** Bounds: 1..∞ */
  portionSize: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  portionUnit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
}

export const DishUpdatePortioningCapability = {
  capabilityId: "Dish.updatePortioning",
  entity: "Dish",
  command: "updatePortioning",
  route: "/api/manifest/Dish/commands/updatePortioning",
  instanceCommand: true,
  clientParameterNames: ["portionSize","portionUnit"],
  serverParameterNames: [],
  emits: ["DishPortioningUpdated"],
} as const;

/**
 * Build command input for Dish.updatePortioning.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishUpdatePortioningInput(client: DishUpdatePortioningClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Dish.updatePortioning. */
export const DishUpdatePortioningInvalidation = [
  {
    "kind": "entityList",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Dish",
    "queryKeyHint": "queryKeys.dish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- DishRecipe.attach ---
export interface DishRecipeAttachClientInput {
  dishId: string;
  recipeId: string;
  /** Bounds: 1..∞ */
  yieldQuantity: number;
  /** Bounds: 1..∞ */
  batchMultiplier?: number;
  sortOrder?: number;
  role?: string;
}

export const DishRecipeAttachCapability = {
  capabilityId: "DishRecipe.attach",
  entity: "DishRecipe",
  command: "attach",
  route: "/api/manifest/DishRecipe/commands/attach",
  instanceCommand: true,
  clientParameterNames: ["dishId","recipeId","yieldQuantity","batchMultiplier","sortOrder","role"],
  serverParameterNames: [],
  emits: ["DishRecipeAttached"],
} as const;

/**
 * Build command input for DishRecipe.attach.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishRecipeAttachInput(client: DishRecipeAttachClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful DishRecipe.attach. */
export const DishRecipeAttachInvalidation = [
  {
    "kind": "entityList",
    "entity": "DishRecipe",
    "queryKeyHint": "queryKeys.dishRecipe.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "DishRecipe",
    "queryKeyHint": "queryKeys.dishRecipe.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- DishRecipe.detach ---
export interface DishRecipeDetachClientInput {
  reason: string;
}

export const DishRecipeDetachCapability = {
  capabilityId: "DishRecipe.detach",
  entity: "DishRecipe",
  command: "detach",
  route: "/api/manifest/DishRecipe/commands/detach",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["DishRecipeDetached"],
} as const;

/**
 * Build command input for DishRecipe.detach.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishRecipeDetachInput(client: DishRecipeDetachClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful DishRecipe.detach. */
export const DishRecipeDetachInvalidation = [
  {
    "kind": "entityList",
    "entity": "DishRecipe",
    "queryKeyHint": "queryKeys.dishRecipe.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "DishRecipe",
    "queryKeyHint": "queryKeys.dishRecipe.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- DishTask.add ---
export interface DishTaskAddClientInput {
  dishId: string;
  name: string;
  category?: string;
  taskType?: string;
  /** Bounds: 1..∞ */
  defaultQuantity?: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  defaultUnit?: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  sortOrder?: number;
  recipeId?: string;
  ingredientId?: string;
  instructions?: string;
}

export const DishTaskAddCapability = {
  capabilityId: "DishTask.add",
  entity: "DishTask",
  command: "add",
  route: "/api/manifest/DishTask/commands/add",
  instanceCommand: true,
  clientParameterNames: ["dishId","name","category","taskType","defaultQuantity","defaultUnit","sortOrder","recipeId","ingredientId","instructions"],
  serverParameterNames: [],
  emits: ["DishTaskAdded"],
} as const;

/**
 * Build command input for DishTask.add.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishTaskAddInput(client: DishTaskAddClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful DishTask.add. */
export const DishTaskAddInvalidation = [
  {
    "kind": "entityList",
    "entity": "DishTask",
    "queryKeyHint": "queryKeys.dishTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "DishTask",
    "queryKeyHint": "queryKeys.dishTask.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- DishTask.retire ---
export interface DishTaskRetireClientInput {
  reason: string;
}

export const DishTaskRetireCapability = {
  capabilityId: "DishTask.retire",
  entity: "DishTask",
  command: "retire",
  route: "/api/manifest/DishTask/commands/retire",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["DishTaskRetired"],
} as const;

/**
 * Build command input for DishTask.retire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishTaskRetireInput(client: DishTaskRetireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful DishTask.retire. */
export const DishTaskRetireInvalidation = [
  {
    "kind": "entityList",
    "entity": "DishTask",
    "queryKeyHint": "queryKeys.dishTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "DishTask",
    "queryKeyHint": "queryKeys.dishTask.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for DishTask.retire. */
export const DishTaskRetireLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "retired",
    "proven": true
  }
] as const;

// --- DishTask.revise ---
export interface DishTaskReviseClientInput {
  name: string;
  category?: string;
  taskType?: string;
  /** Bounds: 1..∞ */
  defaultQuantity?: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  defaultUnit?: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  sortOrder?: number;
  recipeId?: string;
  ingredientId?: string;
  instructions?: string;
}

export const DishTaskReviseCapability = {
  capabilityId: "DishTask.revise",
  entity: "DishTask",
  command: "revise",
  route: "/api/manifest/DishTask/commands/revise",
  instanceCommand: true,
  clientParameterNames: ["name","category","taskType","defaultQuantity","defaultUnit","sortOrder","recipeId","ingredientId","instructions"],
  serverParameterNames: [],
  emits: ["DishTaskRevised"],
} as const;

/**
 * Build command input for DishTask.revise.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindDishTaskReviseInput(client: DishTaskReviseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful DishTask.revise. */
export const DishTaskReviseInvalidation = [
  {
    "kind": "entityList",
    "entity": "DishTask",
    "queryKeyHint": "queryKeys.dishTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "DishTask",
    "queryKeyHint": "queryKeys.dishTask.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EmailNotificationSubscription.configure ---
export interface EmailNotificationSubscriptionConfigureClientInput {
  eventUpdates: boolean;
  invoiceReminders: boolean;
  lowStockAlerts: boolean;
  shiftChanges: boolean;
}

export const EmailNotificationSubscriptionConfigureCapability = {
  capabilityId: "EmailNotificationSubscription.configure",
  entity: "EmailNotificationSubscription",
  command: "configure",
  route: "/api/manifest/EmailNotificationSubscription/commands/configure",
  instanceCommand: true,
  clientParameterNames: ["eventUpdates","invoiceReminders","lowStockAlerts","shiftChanges"],
  serverParameterNames: [],
  emits: ["EmailNotificationSubscriptionConfigured"],
} as const;

/**
 * Build command input for EmailNotificationSubscription.configure.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEmailNotificationSubscriptionConfigureInput(client: EmailNotificationSubscriptionConfigureClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EmailNotificationSubscription.configure. */
export const EmailNotificationSubscriptionConfigureInvalidation = [
  {
    "kind": "entityList",
    "entity": "EmailNotificationSubscription",
    "queryKeyHint": "queryKeys.emailNotificationSubscription.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EmailNotificationSubscription",
    "queryKeyHint": "queryKeys.emailNotificationSubscription.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EmailNotificationSubscription.updateSubscriptions ---
export interface EmailNotificationSubscriptionUpdateSubscriptionsClientInput {
  eventUpdates: boolean;
  invoiceReminders: boolean;
  lowStockAlerts: boolean;
  shiftChanges: boolean;
}

export const EmailNotificationSubscriptionUpdateSubscriptionsCapability = {
  capabilityId: "EmailNotificationSubscription.updateSubscriptions",
  entity: "EmailNotificationSubscription",
  command: "updateSubscriptions",
  route: "/api/manifest/EmailNotificationSubscription/commands/updateSubscriptions",
  instanceCommand: true,
  clientParameterNames: ["eventUpdates","invoiceReminders","lowStockAlerts","shiftChanges"],
  serverParameterNames: [],
  emits: ["EmailNotificationSubscriptionsUpdated"],
} as const;

/**
 * Build command input for EmailNotificationSubscription.updateSubscriptions.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEmailNotificationSubscriptionUpdateSubscriptionsInput(client: EmailNotificationSubscriptionUpdateSubscriptionsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EmailNotificationSubscription.updateSubscriptions. */
export const EmailNotificationSubscriptionUpdateSubscriptionsInvalidation = [
  {
    "kind": "entityList",
    "entity": "EmailNotificationSubscription",
    "queryKeyHint": "queryKeys.emailNotificationSubscription.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EmailNotificationSubscription",
    "queryKeyHint": "queryKeys.emailNotificationSubscription.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Equipment.reactivate ---
export type EquipmentReactivateClientInput = Record<string, never>;

export const EquipmentReactivateCapability = {
  capabilityId: "Equipment.reactivate",
  entity: "Equipment",
  command: "reactivate",
  route: "/api/manifest/Equipment/commands/reactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EquipmentReactivated"],
} as const;

/**
 * Build command input for Equipment.reactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentReactivateInput(client: EquipmentReactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Equipment.reactivate. */
export const EquipmentReactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Equipment.reactivate. */
export const EquipmentReactivateLifecycle = [
  {
    "property": "status",
    "from": "retired",
    "to": "active",
    "proven": true
  }
] as const;

// --- Equipment.recount ---
export interface EquipmentRecountClientInput {
  /** Bounds: 0..∞ */
  actualQuantity: number;
}

export const EquipmentRecountCapability = {
  capabilityId: "Equipment.recount",
  entity: "Equipment",
  command: "recount",
  route: "/api/manifest/Equipment/commands/recount",
  instanceCommand: true,
  clientParameterNames: ["actualQuantity"],
  serverParameterNames: [],
  emits: ["EquipmentRecounted"],
} as const;

/**
 * Build command input for Equipment.recount.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentRecountInput(client: EquipmentRecountClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Equipment.recount. */
export const EquipmentRecountInvalidation = [
  {
    "kind": "entityList",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Equipment.register ---
export interface EquipmentRegisterClientInput {
  name: string;
  assetTag: string;
  category: string;
  /** Allowed: "owned" | "rented" */
  ownership: "owned" | "rented";
  /** Bounds: 1..∞ */
  quantity?: number;
  /** Bounds: 0..∞ */
  purchaseValue?: number;
  /** Allowed: "excellent" | "good" | "fair" | "poor" | "out_of_service" */
  condition?: "excellent" | "good" | "fair" | "poor" | "out_of_service";
}

export const EquipmentRegisterCapability = {
  capabilityId: "Equipment.register",
  entity: "Equipment",
  command: "register",
  route: "/api/manifest/Equipment/commands/register",
  instanceCommand: true,
  clientParameterNames: ["name","assetTag","category","ownership","quantity","purchaseValue","condition"],
  serverParameterNames: [],
  emits: ["EquipmentRegistered"],
} as const;

/**
 * Build command input for Equipment.register.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentRegisterInput(client: EquipmentRegisterClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Equipment.register. */
export const EquipmentRegisterInvalidation = [
  {
    "kind": "entityList",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Equipment.retire ---
export interface EquipmentRetireClientInput {
  reason: string;
}

export const EquipmentRetireCapability = {
  capabilityId: "Equipment.retire",
  entity: "Equipment",
  command: "retire",
  route: "/api/manifest/Equipment/commands/retire",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EquipmentRetired"],
} as const;

/**
 * Build command input for Equipment.retire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentRetireInput(client: EquipmentRetireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Equipment.retire. */
export const EquipmentRetireInvalidation = [
  {
    "kind": "entityList",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Equipment.retire. */
export const EquipmentRetireLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "retired",
    "proven": true
  }
] as const;

// --- Equipment.reviseDetails ---
export interface EquipmentReviseDetailsClientInput {
  name: string;
  category: string;
  /** Allowed: "owned" | "rented" */
  ownership?: "owned" | "rented";
  /** Bounds: 0..∞ */
  purchaseValue?: number;
}

export const EquipmentReviseDetailsCapability = {
  capabilityId: "Equipment.reviseDetails",
  entity: "Equipment",
  command: "reviseDetails",
  route: "/api/manifest/Equipment/commands/reviseDetails",
  instanceCommand: true,
  clientParameterNames: ["name","category","ownership","purchaseValue"],
  serverParameterNames: [],
  emits: ["EquipmentDetailsRevised"],
} as const;

/**
 * Build command input for Equipment.reviseDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentReviseDetailsInput(client: EquipmentReviseDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Equipment.reviseDetails. */
export const EquipmentReviseDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Equipment.updateCondition ---
export interface EquipmentUpdateConditionClientInput {
  /** Allowed: "excellent" | "good" | "fair" | "poor" | "out_of_service" */
  condition: "excellent" | "good" | "fair" | "poor" | "out_of_service";
  note?: string;
}

export const EquipmentUpdateConditionCapability = {
  capabilityId: "Equipment.updateCondition",
  entity: "Equipment",
  command: "updateCondition",
  route: "/api/manifest/Equipment/commands/updateCondition",
  instanceCommand: true,
  clientParameterNames: ["condition","note"],
  serverParameterNames: [],
  emits: ["EquipmentConditionUpdated"],
} as const;

/**
 * Build command input for Equipment.updateCondition.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentUpdateConditionInput(client: EquipmentUpdateConditionClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Equipment.updateCondition. */
export const EquipmentUpdateConditionInvalidation = [
  {
    "kind": "entityList",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Equipment",
    "queryKeyHint": "queryKeys.equipment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EquipmentMaintenanceTask.applyService ---
export interface EquipmentMaintenanceTaskApplyServiceClientInput {
  /** Must not be "". */
  completedAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  nextDueAt: string & { readonly __nonEmpty?: true };
}

export const EquipmentMaintenanceTaskApplyServiceCapability = {
  capabilityId: "EquipmentMaintenanceTask.applyService",
  entity: "EquipmentMaintenanceTask",
  command: "applyService",
  route: "/api/manifest/EquipmentMaintenanceTask/commands/applyService",
  instanceCommand: true,
  clientParameterNames: ["completedAt","nextDueAt"],
  serverParameterNames: [],
  emits: ["EquipmentMaintenanceAdvanced"],
} as const;

/**
 * Build command input for EquipmentMaintenanceTask.applyService.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentMaintenanceTaskApplyServiceInput(client: EquipmentMaintenanceTaskApplyServiceClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EquipmentMaintenanceTask.applyService. */
export const EquipmentMaintenanceTaskApplyServiceInvalidation = [
  {
    "kind": "entityList",
    "entity": "EquipmentMaintenanceTask",
    "queryKeyHint": "queryKeys.equipmentMaintenanceTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EquipmentMaintenanceTask",
    "queryKeyHint": "queryKeys.equipmentMaintenanceTask.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EquipmentMaintenanceTask.schedule ---
export interface EquipmentMaintenanceTaskScheduleClientInput {
  equipmentId: string;
  taskName: string;
  /** Bounds: 1..∞ */
  intervalDays: number;
  /** Must not be "". */
  nextDueAt: string & { readonly __nonEmpty?: true };
  instructions?: string;
}

export const EquipmentMaintenanceTaskScheduleCapability = {
  capabilityId: "EquipmentMaintenanceTask.schedule",
  entity: "EquipmentMaintenanceTask",
  command: "schedule",
  route: "/api/manifest/EquipmentMaintenanceTask/commands/schedule",
  instanceCommand: true,
  clientParameterNames: ["equipmentId","taskName","intervalDays","nextDueAt","instructions"],
  serverParameterNames: [],
  emits: ["EquipmentMaintenanceScheduled"],
} as const;

/**
 * Build command input for EquipmentMaintenanceTask.schedule.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentMaintenanceTaskScheduleInput(client: EquipmentMaintenanceTaskScheduleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EquipmentMaintenanceTask.schedule. */
export const EquipmentMaintenanceTaskScheduleInvalidation = [
  {
    "kind": "entityList",
    "entity": "EquipmentMaintenanceTask",
    "queryKeyHint": "queryKeys.equipmentMaintenanceTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EquipmentMaintenanceTask",
    "queryKeyHint": "queryKeys.equipmentMaintenanceTask.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EquipmentReservation.cancel ---
export interface EquipmentReservationCancelClientInput {
  reason?: string;
}

export const EquipmentReservationCancelCapability = {
  capabilityId: "EquipmentReservation.cancel",
  entity: "EquipmentReservation",
  command: "cancel",
  route: "/api/manifest/EquipmentReservation/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EquipmentReservationCancelled"],
} as const;

/**
 * Build command input for EquipmentReservation.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentReservationCancelInput(client: EquipmentReservationCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EquipmentReservation.cancel. */
export const EquipmentReservationCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "EquipmentReservation",
    "queryKeyHint": "queryKeys.equipmentReservation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EquipmentReservation",
    "queryKeyHint": "queryKeys.equipmentReservation.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EquipmentReservation.cancel. */
export const EquipmentReservationCancelLifecycle = [
  {
    "property": "status",
    "from": "reserved",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- EquipmentReservation.checkOut ---
export interface EquipmentReservationCheckOutClientInput {
  /** Allowed: "excellent" | "good" | "fair" | "poor" | "out_of_service" */
  condition: "excellent" | "good" | "fair" | "poor" | "out_of_service";
  note?: string;
}

export const EquipmentReservationCheckOutCapability = {
  capabilityId: "EquipmentReservation.checkOut",
  entity: "EquipmentReservation",
  command: "checkOut",
  route: "/api/manifest/EquipmentReservation/commands/checkOut",
  instanceCommand: true,
  clientParameterNames: ["condition","note"],
  serverParameterNames: [],
  emits: ["EquipmentCheckedOut"],
} as const;

/**
 * Build command input for EquipmentReservation.checkOut.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentReservationCheckOutInput(client: EquipmentReservationCheckOutClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EquipmentReservation.checkOut. */
export const EquipmentReservationCheckOutInvalidation = [
  {
    "kind": "entityList",
    "entity": "EquipmentReservation",
    "queryKeyHint": "queryKeys.equipmentReservation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EquipmentReservation",
    "queryKeyHint": "queryKeys.equipmentReservation.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EquipmentReservation.checkOut. */
export const EquipmentReservationCheckOutLifecycle = [
  {
    "property": "status",
    "from": "reserved",
    "to": "checked_out",
    "proven": true
  }
] as const;

// --- EquipmentReservation.markReturned ---
export interface EquipmentReservationMarkReturnedClientInput {
  /** Allowed: "excellent" | "good" | "fair" | "poor" | "out_of_service" */
  condition: "excellent" | "good" | "fair" | "poor" | "out_of_service";
  note?: string;
}

export const EquipmentReservationMarkReturnedCapability = {
  capabilityId: "EquipmentReservation.markReturned",
  entity: "EquipmentReservation",
  command: "markReturned",
  route: "/api/manifest/EquipmentReservation/commands/markReturned",
  instanceCommand: true,
  clientParameterNames: ["condition","note"],
  serverParameterNames: [],
  emits: ["EquipmentReturned"],
} as const;

/**
 * Build command input for EquipmentReservation.markReturned.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentReservationMarkReturnedInput(client: EquipmentReservationMarkReturnedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EquipmentReservation.markReturned. */
export const EquipmentReservationMarkReturnedInvalidation = [
  {
    "kind": "entityList",
    "entity": "EquipmentReservation",
    "queryKeyHint": "queryKeys.equipmentReservation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EquipmentReservation",
    "queryKeyHint": "queryKeys.equipmentReservation.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EquipmentReservation.markReturned. */
export const EquipmentReservationMarkReturnedLifecycle = [
  {
    "property": "status",
    "from": "checked_out",
    "to": "returned",
    "proven": true
  }
] as const;

// --- EquipmentServiceEntry.record ---
export interface EquipmentServiceEntryRecordClientInput {
  maintenanceTaskId: string;
  equipmentId: string;
  technician: string;
  /** Bounds: 0..∞ */
  cost: number;
  /** Must not be "". */
  completedAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  nextDueAt: string & { readonly __nonEmpty?: true };
  notes?: string;
}

export const EquipmentServiceEntryRecordCapability = {
  capabilityId: "EquipmentServiceEntry.record",
  entity: "EquipmentServiceEntry",
  command: "record",
  route: "/api/manifest/EquipmentServiceEntry/commands/record",
  instanceCommand: true,
  clientParameterNames: ["maintenanceTaskId","equipmentId","technician","cost","completedAt","nextDueAt","notes"],
  serverParameterNames: [],
  emits: ["EquipmentServiceRecorded"],
} as const;

/**
 * Build command input for EquipmentServiceEntry.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEquipmentServiceEntryRecordInput(client: EquipmentServiceEntryRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EquipmentServiceEntry.record. */
export const EquipmentServiceEntryRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "EquipmentServiceEntry",
    "queryKeyHint": "queryKeys.equipmentServiceEntry.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EquipmentServiceEntry",
    "queryKeyHint": "queryKeys.equipmentServiceEntry.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.approve ---
export type EventApproveClientInput = Record<string, never>;

export const EventApproveCapability = {
  capabilityId: "Event.approve",
  entity: "Event",
  command: "approve",
  route: "/api/manifest/Event/commands/approve",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventApproved"],
} as const;

/**
 * Build command input for Event.approve.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventApproveInput(client: EventApproveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.approve. */
export const EventApproveInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Event.approve. */
export const EventApproveLifecycle = [
  {
    "property": "stage",
    "from": "pending_approval",
    "to": "approved",
    "proven": true
  }
] as const;

// --- Event.assignOwner ---
export interface EventAssignOwnerClientInput {
  assignedToId?: string;
}

export const EventAssignOwnerCapability = {
  capabilityId: "Event.assignOwner",
  entity: "Event",
  command: "assignOwner",
  route: "/api/manifest/Event/commands/assignOwner",
  instanceCommand: true,
  clientParameterNames: ["assignedToId"],
  serverParameterNames: [],
  emits: ["EventOwnerAssigned"],
} as const;

/**
 * Build command input for Event.assignOwner.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventAssignOwnerInput(client: EventAssignOwnerClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.assignOwner. */
export const EventAssignOwnerInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.beginExecution ---
export type EventBeginExecutionClientInput = Record<string, never>;

export const EventBeginExecutionCapability = {
  capabilityId: "Event.beginExecution",
  entity: "Event",
  command: "beginExecution",
  route: "/api/manifest/Event/commands/beginExecution",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventExecutionStarted"],
} as const;

/**
 * Build command input for Event.beginExecution.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventBeginExecutionInput(client: EventBeginExecutionClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.beginExecution. */
export const EventBeginExecutionInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Event.beginExecution. */
export const EventBeginExecutionLifecycle = [
  {
    "property": "stage",
    "from": "approved",
    "to": "executing",
    "proven": true
  }
] as const;

// --- Event.cancel ---
export interface EventCancelClientInput {
  reason: string;
}

export const EventCancelCapability = {
  capabilityId: "Event.cancel",
  entity: "Event",
  command: "cancel",
  route: "/api/manifest/Event/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EventCancelled"],
} as const;

/**
 * Build command input for Event.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventCancelInput(client: EventCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.cancel. */
export const EventCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Event.cancel. */
export const EventCancelLifecycle = [
  {
    "property": "stage",
    "from": "planning",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "stage",
    "from": "pending_approval",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "stage",
    "from": "approved",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "stage",
    "from": "executing",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- Event.changeHeadcount ---
export interface EventChangeHeadcountClientInput {
  /** Bounds: 1..100000 */
  newHeadcount: number;
}

export const EventChangeHeadcountCapability = {
  capabilityId: "Event.changeHeadcount",
  entity: "Event",
  command: "changeHeadcount",
  route: "/api/manifest/Event/commands/changeHeadcount",
  instanceCommand: true,
  clientParameterNames: ["newHeadcount"],
  serverParameterNames: [],
  emits: ["EventHeadcountChanged"],
} as const;

/**
 * Build command input for Event.changeHeadcount.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventChangeHeadcountInput(client: EventChangeHeadcountClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.changeHeadcount. */
export const EventChangeHeadcountInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.changePricing ---
export interface EventChangePricingClientInput {
  /** Bounds: 0..∞ */
  budgetAmount: number;
  /** Bounds: 0..∞ */
  quotedPrice: number;
}

export const EventChangePricingCapability = {
  capabilityId: "Event.changePricing",
  entity: "Event",
  command: "changePricing",
  route: "/api/manifest/Event/commands/changePricing",
  instanceCommand: true,
  clientParameterNames: ["budgetAmount","quotedPrice"],
  serverParameterNames: [],
  emits: ["EventPricingChanged"],
} as const;

/**
 * Build command input for Event.changePricing.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventChangePricingInput(client: EventChangePricingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.changePricing. */
export const EventChangePricingInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.changePrimaryContact ---
export interface EventChangePrimaryContactClientInput {
  primaryContactName: string;
  primaryContactEmail?: string;
  primaryContactPhone?: string;
}

export const EventChangePrimaryContactCapability = {
  capabilityId: "Event.changePrimaryContact",
  entity: "Event",
  command: "changePrimaryContact",
  route: "/api/manifest/Event/commands/changePrimaryContact",
  instanceCommand: true,
  clientParameterNames: ["primaryContactName","primaryContactEmail","primaryContactPhone"],
  serverParameterNames: [],
  emits: ["EventPrimaryContactChanged"],
} as const;

/**
 * Build command input for Event.changePrimaryContact.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventChangePrimaryContactInput(client: EventChangePrimaryContactClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.changePrimaryContact. */
export const EventChangePrimaryContactInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.changeRequirements ---
export interface EventChangeRequirementsClientInput {
  accessibilityNeeds?: string[];
  serviceRequirements?: string;
  operationalRequirements?: string;
}

export const EventChangeRequirementsCapability = {
  capabilityId: "Event.changeRequirements",
  entity: "Event",
  command: "changeRequirements",
  route: "/api/manifest/Event/commands/changeRequirements",
  instanceCommand: true,
  clientParameterNames: ["accessibilityNeeds","serviceRequirements","operationalRequirements"],
  serverParameterNames: [],
  emits: ["EventRequirementsChanged"],
} as const;

/**
 * Build command input for Event.changeRequirements.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventChangeRequirementsInput(client: EventChangeRequirementsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.changeRequirements. */
export const EventChangeRequirementsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.changeVenue ---
export interface EventChangeVenueClientInput {
  venueId?: string;
  venueName?: string;
  venueAddress?: string;
  /** Bounds: 0..∞ */
  venueCapacity?: number;
}

export const EventChangeVenueCapability = {
  capabilityId: "Event.changeVenue",
  entity: "Event",
  command: "changeVenue",
  route: "/api/manifest/Event/commands/changeVenue",
  instanceCommand: true,
  clientParameterNames: ["venueId","venueName","venueAddress","venueCapacity"],
  serverParameterNames: [],
  emits: ["EventVenueChanged"],
} as const;

/**
 * Build command input for Event.changeVenue.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventChangeVenueInput(client: EventChangeVenueClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.changeVenue. */
export const EventChangeVenueInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.closeOut ---
export type EventCloseOutClientInput = Record<string, never>;

export const EventCloseOutCapability = {
  capabilityId: "Event.closeOut",
  entity: "Event",
  command: "closeOut",
  route: "/api/manifest/Event/commands/closeOut",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventClosedOut"],
} as const;

/**
 * Build command input for Event.closeOut.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventCloseOutInput(client: EventCloseOutClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.closeOut. */
export const EventCloseOutInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Event.closeOut. */
export const EventCloseOutLifecycle = [
  {
    "property": "stage",
    "from": "completed",
    "to": "closed_out",
    "proven": true
  }
] as const;

// --- Event.complete ---
export type EventCompleteClientInput = Record<string, never>;

export const EventCompleteCapability = {
  capabilityId: "Event.complete",
  entity: "Event",
  command: "complete",
  route: "/api/manifest/Event/commands/complete",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventCompleted"],
} as const;

/**
 * Build command input for Event.complete.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventCompleteInput(client: EventCompleteClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.complete. */
export const EventCompleteInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Event.complete. */
export const EventCompleteLifecycle = [
  {
    "property": "stage",
    "from": "executing",
    "to": "completed",
    "proven": true
  }
] as const;

// --- Event.configureRecurrence ---
export interface EventConfigureRecurrenceClientInput {
  /** Allowed: "weekly" | "monthly" | "annually" */
  frequency: "weekly" | "monthly" | "annually";
  /** Allowed: "on_date" | "after_occurrences" */
  endCondition: "on_date" | "after_occurrences";
  recurrenceEndsAt?: string;
  /** Bounds: 2..1000 */
  occurrenceLimit?: number;
  /** Must not be "". */
  nextStartsAt: string & { readonly __nonEmpty?: true };
  seriesId: string;
}

export const EventConfigureRecurrenceCapability = {
  capabilityId: "Event.configureRecurrence",
  entity: "Event",
  command: "configureRecurrence",
  route: "/api/manifest/Event/commands/configureRecurrence",
  instanceCommand: true,
  clientParameterNames: ["frequency","endCondition","recurrenceEndsAt","occurrenceLimit","nextStartsAt","seriesId"],
  serverParameterNames: [],
  emits: ["EventRecurrenceConfigured"],
} as const;

/**
 * Build command input for Event.configureRecurrence.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventConfigureRecurrenceInput(client: EventConfigureRecurrenceClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.configureRecurrence. */
export const EventConfigureRecurrenceInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.planEngagement ---
export interface EventPlanEngagementClientInput {
  clientId: string;
  title: string;
  eventType: string;
  /** Must not be "". */
  startsAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  endsAt: string & { readonly __nonEmpty?: true };
  /** Bounds: 1..100000 */
  expectedHeadcount: number;
  primaryContactName: string;
  /** Bounds: 0..∞ */
  budgetAmount: number;
  /** Bounds: 0..∞ */
  quotedPrice: number;
  venueId?: string;
  venueName?: string;
  venueAddress?: string;
  /** Bounds: 0..∞ */
  venueCapacity?: number;
  primaryContactEmail?: string;
  primaryContactPhone?: string;
  accessibilityNeeds?: string[];
  serviceRequirements?: string;
  operationalRequirements?: string;
  assignedToId?: string;
}

export const EventPlanEngagementCapability = {
  capabilityId: "Event.planEngagement",
  entity: "Event",
  command: "planEngagement",
  route: "/api/manifest/Event/commands/planEngagement",
  instanceCommand: true,
  clientParameterNames: ["clientId","title","eventType","startsAt","endsAt","expectedHeadcount","primaryContactName","budgetAmount","quotedPrice","venueId","venueName","venueAddress","venueCapacity","primaryContactEmail","primaryContactPhone","accessibilityNeeds","serviceRequirements","operationalRequirements","assignedToId"],
  serverParameterNames: [],
  emits: ["EventPlanned"],
} as const;

/**
 * Build command input for Event.planEngagement.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventPlanEngagementInput(client: EventPlanEngagementClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.planEngagement. */
export const EventPlanEngagementInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.reassignClient ---
export type EventReassignClientClientInput = Record<string, never>;

export const EventReassignClientCapability = {
  capabilityId: "Event.reassignClient",
  entity: "Event",
  command: "reassignClient",
  route: "/api/manifest/Event/commands/reassignClient",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventClientReassigned"],
} as const;

/**
 * Build command input for Event.reassignClient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventReassignClientInput(client: EventReassignClientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.reassignClient. */
export const EventReassignClientInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.reschedule ---
export interface EventRescheduleClientInput {
  /** Must not be "". */
  startsAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  endsAt: string & { readonly __nonEmpty?: true };
}

export const EventRescheduleCapability = {
  capabilityId: "Event.reschedule",
  entity: "Event",
  command: "reschedule",
  route: "/api/manifest/Event/commands/reschedule",
  instanceCommand: true,
  clientParameterNames: ["startsAt","endsAt"],
  serverParameterNames: [],
  emits: ["EventScheduleChanged"],
} as const;

/**
 * Build command input for Event.reschedule.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventRescheduleInput(client: EventRescheduleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.reschedule. */
export const EventRescheduleInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.returnToPlanning ---
export interface EventReturnToPlanningClientInput {
  reason: string;
}

export const EventReturnToPlanningCapability = {
  capabilityId: "Event.returnToPlanning",
  entity: "Event",
  command: "returnToPlanning",
  route: "/api/manifest/Event/commands/returnToPlanning",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EventReturnedToPlanning"],
} as const;

/**
 * Build command input for Event.returnToPlanning.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventReturnToPlanningInput(client: EventReturnToPlanningClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.returnToPlanning. */
export const EventReturnToPlanningInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Event.returnToPlanning. */
export const EventReturnToPlanningLifecycle = [
  {
    "property": "stage",
    "from": "pending_approval",
    "to": "planning",
    "proven": true
  },
  {
    "property": "stage",
    "from": "approved",
    "to": "planning",
    "proven": true
  }
] as const;

// --- Event.stageClientMerge ---
export interface EventStageClientMergeClientInput {
  clientMergeId: string;
  clientId: string;
}

export const EventStageClientMergeCapability = {
  capabilityId: "Event.stageClientMerge",
  entity: "Event",
  command: "stageClientMerge",
  route: "/api/manifest/Event/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","clientId"],
  serverParameterNames: [],
  emits: ["EventClientMergeStaged"],
} as const;

/**
 * Build command input for Event.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventStageClientMergeInput(client: EventStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.stageClientMerge. */
export const EventStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.stopRecurrence ---
export type EventStopRecurrenceClientInput = Record<string, never>;

export const EventStopRecurrenceCapability = {
  capabilityId: "Event.stopRecurrence",
  entity: "Event",
  command: "stopRecurrence",
  route: "/api/manifest/Event/commands/stopRecurrence",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventRecurrenceStopped"],
} as const;

/**
 * Build command input for Event.stopRecurrence.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventStopRecurrenceInput(client: EventStopRecurrenceClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.stopRecurrence. */
export const EventStopRecurrenceInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Event.submitForApproval ---
export type EventSubmitForApprovalClientInput = Record<string, never>;

export const EventSubmitForApprovalCapability = {
  capabilityId: "Event.submitForApproval",
  entity: "Event",
  command: "submitForApproval",
  route: "/api/manifest/Event/commands/submitForApproval",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventSubmittedForApproval"],
} as const;

/**
 * Build command input for Event.submitForApproval.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventSubmitForApprovalInput(client: EventSubmitForApprovalClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Event.submitForApproval. */
export const EventSubmitForApprovalInvalidation = [
  {
    "kind": "entityList",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Event",
    "queryKeyHint": "queryKeys.event.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Event.submitForApproval. */
export const EventSubmitForApprovalLifecycle = [
  {
    "property": "stage",
    "from": "planning",
    "to": "pending_approval",
    "proven": true
  }
] as const;

// --- EventAllergenCheck.record ---
export interface EventAllergenCheckRecordClientInput {
  eventId: string;
  /** Allowed: "pass" | "flagged" */
  result: "pass" | "flagged";
  eventDishId?: string;
  dishId?: string;
  /** Non-empty string required (static). */
  flaggedAllergens?: ("milk" | "eggs" | "fish" | "crustacean_shellfish" | "tree_nuts" | "peanuts" | "wheat" | "soybeans" | "sesame")[];
  notes?: string;
}

export const EventAllergenCheckRecordCapability = {
  capabilityId: "EventAllergenCheck.record",
  entity: "EventAllergenCheck",
  command: "record",
  route: "/api/manifest/EventAllergenCheck/commands/record",
  instanceCommand: true,
  clientParameterNames: ["eventId","result","eventDishId","dishId","flaggedAllergens","notes"],
  serverParameterNames: [],
  emits: ["EventAllergenCheckRecorded"],
} as const;

/**
 * Build command input for EventAllergenCheck.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventAllergenCheckRecordInput(client: EventAllergenCheckRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventAllergenCheck.record. */
export const EventAllergenCheckRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventAllergenCheck",
    "queryKeyHint": "queryKeys.eventAllergenCheck.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventAllergenCheck",
    "queryKeyHint": "queryKeys.eventAllergenCheck.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventAllergenCheck.record. */
export const EventAllergenCheckRecordLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "recorded",
    "proven": true
  }
] as const;

// --- EventAssignment.assign ---
export interface EventAssignmentAssignClientInput {
  eventId: string;
  personId: string;
  role: string;
  startsAt?: string;
  endsAt?: string;
  notes?: string;
}

export const EventAssignmentAssignCapability = {
  capabilityId: "EventAssignment.assign",
  entity: "EventAssignment",
  command: "assign",
  route: "/api/manifest/EventAssignment/commands/assign",
  instanceCommand: true,
  clientParameterNames: ["eventId","personId","role","startsAt","endsAt","notes"],
  serverParameterNames: [],
  emits: ["EventAssignmentAssigned"],
} as const;

/**
 * Build command input for EventAssignment.assign.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventAssignmentAssignInput(client: EventAssignmentAssignClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventAssignment.assign. */
export const EventAssignmentAssignInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventAssignment.checkIn ---
export type EventAssignmentCheckInClientInput = Record<string, never>;

export const EventAssignmentCheckInCapability = {
  capabilityId: "EventAssignment.checkIn",
  entity: "EventAssignment",
  command: "checkIn",
  route: "/api/manifest/EventAssignment/commands/checkIn",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventAssignmentCheckedIn"],
} as const;

/**
 * Build command input for EventAssignment.checkIn.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventAssignmentCheckInInput(client: EventAssignmentCheckInClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventAssignment.checkIn. */
export const EventAssignmentCheckInInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventAssignment.checkIn. */
export const EventAssignmentCheckInLifecycle = [
  {
    "property": "status",
    "from": "assigned",
    "to": "checked_in",
    "proven": true
  },
  {
    "property": "status",
    "from": "confirmed",
    "to": "checked_in",
    "proven": true
  }
] as const;

// --- EventAssignment.checkOut ---
export type EventAssignmentCheckOutClientInput = Record<string, never>;

export const EventAssignmentCheckOutCapability = {
  capabilityId: "EventAssignment.checkOut",
  entity: "EventAssignment",
  command: "checkOut",
  route: "/api/manifest/EventAssignment/commands/checkOut",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventAssignmentCheckedOut"],
} as const;

/**
 * Build command input for EventAssignment.checkOut.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventAssignmentCheckOutInput(client: EventAssignmentCheckOutClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventAssignment.checkOut. */
export const EventAssignmentCheckOutInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventAssignment.checkOut. */
export const EventAssignmentCheckOutLifecycle = [
  {
    "property": "status",
    "from": "checked_in",
    "to": "checked_out",
    "proven": true
  }
] as const;

// --- EventAssignment.confirm ---
export type EventAssignmentConfirmClientInput = Record<string, never>;

export const EventAssignmentConfirmCapability = {
  capabilityId: "EventAssignment.confirm",
  entity: "EventAssignment",
  command: "confirm",
  route: "/api/manifest/EventAssignment/commands/confirm",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventAssignmentConfirmed"],
} as const;

/**
 * Build command input for EventAssignment.confirm.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventAssignmentConfirmInput(client: EventAssignmentConfirmClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventAssignment.confirm. */
export const EventAssignmentConfirmInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventAssignment.confirm. */
export const EventAssignmentConfirmLifecycle = [
  {
    "property": "status",
    "from": "assigned",
    "to": "confirmed",
    "proven": true
  }
] as const;

// --- EventAssignment.markNoShow ---
export type EventAssignmentMarkNoShowClientInput = Record<string, never>;

export const EventAssignmentMarkNoShowCapability = {
  capabilityId: "EventAssignment.markNoShow",
  entity: "EventAssignment",
  command: "markNoShow",
  route: "/api/manifest/EventAssignment/commands/markNoShow",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventAssignmentNoShowMarked"],
} as const;

/**
 * Build command input for EventAssignment.markNoShow.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventAssignmentMarkNoShowInput(client: EventAssignmentMarkNoShowClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventAssignment.markNoShow. */
export const EventAssignmentMarkNoShowInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventAssignment.markNoShow. */
export const EventAssignmentMarkNoShowLifecycle = [
  {
    "property": "status",
    "from": "assigned",
    "to": "no_show",
    "proven": true
  },
  {
    "property": "status",
    "from": "confirmed",
    "to": "no_show",
    "proven": true
  }
] as const;

// --- EventAssignment.unassign ---
export type EventAssignmentUnassignClientInput = Record<string, never>;

export const EventAssignmentUnassignCapability = {
  capabilityId: "EventAssignment.unassign",
  entity: "EventAssignment",
  command: "unassign",
  route: "/api/manifest/EventAssignment/commands/unassign",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventAssignmentUnassigned"],
} as const;

/**
 * Build command input for EventAssignment.unassign.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventAssignmentUnassignInput(client: EventAssignmentUnassignClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventAssignment.unassign. */
export const EventAssignmentUnassignInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventAssignment",
    "queryKeyHint": "queryKeys.eventAssignment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventAssignment.unassign. */
export const EventAssignmentUnassignLifecycle = [
  {
    "property": "status",
    "from": "assigned",
    "to": "unassigned",
    "proven": true
  },
  {
    "property": "status",
    "from": "confirmed",
    "to": "unassigned",
    "proven": true
  }
] as const;

// --- EventCloseout.capture ---
export interface EventCloseoutCaptureClientInput {
  eventId: string;
  /** Bounds: 0..∞ */
  actualRevenue: number;
  /** Bounds: 0..∞ */
  budgetedRevenue: number;
  revenueVariance: number;
  /** Bounds: 0..∞ */
  actualIngredientCost: number;
  /** Bounds: 0..∞ */
  actualWasteCost: number;
  /** Bounds: 0..∞ */
  actualLaborCost: number;
  /** Bounds: 0..∞ */
  actualVendorCost: number;
  /** Bounds: 0..∞ */
  budgetedCost: number;
  /** Bounds: 0..∞ */
  totalActualCost: number;
  costVariance: number;
  grossProfit: number;
  /** Bounds: 0..∞ */
  expectedHeadcount: number;
  /** Bounds: 0..∞ */
  actualHeadcount: number;
  unresolvedIssues?: string;
  performanceNotes?: string;
  notes?: string;
}

export const EventCloseoutCaptureCapability = {
  capabilityId: "EventCloseout.capture",
  entity: "EventCloseout",
  command: "capture",
  route: "/api/manifest/EventCloseout/commands/capture",
  instanceCommand: true,
  clientParameterNames: ["eventId","actualRevenue","budgetedRevenue","revenueVariance","actualIngredientCost","actualWasteCost","actualLaborCost","actualVendorCost","budgetedCost","totalActualCost","costVariance","grossProfit","expectedHeadcount","actualHeadcount","unresolvedIssues","performanceNotes","notes"],
  serverParameterNames: [],
  emits: ["EventCloseoutCaptured"],
} as const;

/**
 * Build command input for EventCloseout.capture.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventCloseoutCaptureInput(client: EventCloseoutCaptureClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventCloseout.capture. */
export const EventCloseoutCaptureInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventCloseout",
    "queryKeyHint": "queryKeys.eventCloseout.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventCloseout",
    "queryKeyHint": "queryKeys.eventCloseout.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventCloseout.finalize ---
export type EventCloseoutFinalizeClientInput = Record<string, never>;

export const EventCloseoutFinalizeCapability = {
  capabilityId: "EventCloseout.finalize",
  entity: "EventCloseout",
  command: "finalize",
  route: "/api/manifest/EventCloseout/commands/finalize",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventCloseoutFinalized"],
} as const;

/**
 * Build command input for EventCloseout.finalize.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventCloseoutFinalizeInput(client: EventCloseoutFinalizeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventCloseout.finalize. */
export const EventCloseoutFinalizeInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventCloseout",
    "queryKeyHint": "queryKeys.eventCloseout.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventCloseout",
    "queryKeyHint": "queryKeys.eventCloseout.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventCloseout.finalize. */
export const EventCloseoutFinalizeLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "finalized",
    "proven": true
  }
] as const;

// --- EventDish.addToEvent ---
export interface EventDishAddToEventClientInput {
  eventId: string;
  dishId: string;
  /** Bounds: 0..∞ */
  quantityServings: number;
  course?: string;
  serviceStyle?: string;
  specialInstructions?: string;
}

export const EventDishAddToEventCapability = {
  capabilityId: "EventDish.addToEvent",
  entity: "EventDish",
  command: "addToEvent",
  route: "/api/manifest/EventDish/commands/addToEvent",
  instanceCommand: true,
  clientParameterNames: ["eventId","dishId","quantityServings","course","serviceStyle","specialInstructions"],
  serverParameterNames: [],
  emits: ["EventDishAdded"],
} as const;

/**
 * Build command input for EventDish.addToEvent.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventDishAddToEventInput(client: EventDishAddToEventClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventDish.addToEvent. */
export const EventDishAddToEventInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventDish.adjustServings ---
export interface EventDishAdjustServingsClientInput {
  /** Bounds: 0..∞ */
  quantityServings: number;
}

export const EventDishAdjustServingsCapability = {
  capabilityId: "EventDish.adjustServings",
  entity: "EventDish",
  command: "adjustServings",
  route: "/api/manifest/EventDish/commands/adjustServings",
  instanceCommand: true,
  clientParameterNames: ["quantityServings"],
  serverParameterNames: [],
  emits: ["EventDishServingsAdjusted"],
} as const;

/**
 * Build command input for EventDish.adjustServings.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventDishAdjustServingsInput(client: EventDishAdjustServingsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventDish.adjustServings. */
export const EventDishAdjustServingsInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventDish.changeCourse ---
export interface EventDishChangeCourseClientInput {
  course?: string;
  serviceStyle?: string;
}

export const EventDishChangeCourseCapability = {
  capabilityId: "EventDish.changeCourse",
  entity: "EventDish",
  command: "changeCourse",
  route: "/api/manifest/EventDish/commands/changeCourse",
  instanceCommand: true,
  clientParameterNames: ["course","serviceStyle"],
  serverParameterNames: [],
  emits: ["EventDishCourseChanged"],
} as const;

/**
 * Build command input for EventDish.changeCourse.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventDishChangeCourseInput(client: EventDishChangeCourseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventDish.changeCourse. */
export const EventDishChangeCourseInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventDish.remove ---
export interface EventDishRemoveClientInput {
  reason: string;
}

export const EventDishRemoveCapability = {
  capabilityId: "EventDish.remove",
  entity: "EventDish",
  command: "remove",
  route: "/api/manifest/EventDish/commands/remove",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EventDishRemoved"],
} as const;

/**
 * Build command input for EventDish.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventDishRemoveInput(client: EventDishRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventDish.remove. */
export const EventDishRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventDish.updateInstructions ---
export interface EventDishUpdateInstructionsClientInput {
  specialInstructions?: string;
}

export const EventDishUpdateInstructionsCapability = {
  capabilityId: "EventDish.updateInstructions",
  entity: "EventDish",
  command: "updateInstructions",
  route: "/api/manifest/EventDish/commands/updateInstructions",
  instanceCommand: true,
  clientParameterNames: ["specialInstructions"],
  serverParameterNames: [],
  emits: ["EventDishInstructionsUpdated"],
} as const;

/**
 * Build command input for EventDish.updateInstructions.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventDishUpdateInstructionsInput(client: EventDishUpdateInstructionsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventDish.updateInstructions. */
export const EventDishUpdateInstructionsInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventDish",
    "queryKeyHint": "queryKeys.eventDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventDishRecipeSeed.seed ---
export interface EventDishRecipeSeedSeedClientInput {
  eventId: string;
  eventDishId: string;
  dishId: string;
  recipeId: string;
  servings: number;
  yieldQuantity: number;
  batchMultiplier: number;
  purchasingWeekStart?: string;
}

export const EventDishRecipeSeedSeedCapability = {
  capabilityId: "EventDishRecipeSeed.seed",
  entity: "EventDishRecipeSeed",
  command: "seed",
  route: "/api/manifest/EventDishRecipeSeed/commands/seed",
  instanceCommand: true,
  clientParameterNames: ["eventId","eventDishId","dishId","recipeId","servings","yieldQuantity","batchMultiplier","purchasingWeekStart"],
  serverParameterNames: [],
  emits: ["EventDishRecipeSeeded"],
} as const;

/**
 * Build command input for EventDishRecipeSeed.seed.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventDishRecipeSeedSeedInput(client: EventDishRecipeSeedSeedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventDishRecipeSeed.seed. */
export const EventDishRecipeSeedSeedInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventDishRecipeSeed",
    "queryKeyHint": "queryKeys.eventDishRecipeSeed.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventDishRecipeSeed",
    "queryKeyHint": "queryKeys.eventDishRecipeSeed.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventGuest.assignTable ---
export interface EventGuestAssignTableClientInput {
  tableAssignment: string;
}

export const EventGuestAssignTableCapability = {
  capabilityId: "EventGuest.assignTable",
  entity: "EventGuest",
  command: "assignTable",
  route: "/api/manifest/EventGuest/commands/assignTable",
  instanceCommand: true,
  clientParameterNames: ["tableAssignment"],
  serverParameterNames: [],
  emits: ["EventGuestTableAssigned"],
} as const;

/**
 * Build command input for EventGuest.assignTable.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventGuestAssignTableInput(client: EventGuestAssignTableClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventGuest.assignTable. */
export const EventGuestAssignTableInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventGuest.checkIn ---
export type EventGuestCheckInClientInput = Record<string, never>;

export const EventGuestCheckInCapability = {
  capabilityId: "EventGuest.checkIn",
  entity: "EventGuest",
  command: "checkIn",
  route: "/api/manifest/EventGuest/commands/checkIn",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventGuestCheckedIn"],
} as const;

/**
 * Build command input for EventGuest.checkIn.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventGuestCheckInInput(client: EventGuestCheckInClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventGuest.checkIn. */
export const EventGuestCheckInInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventGuest.invite ---
export interface EventGuestInviteClientInput {
  eventId: string;
  name: string;
  email?: string;
  phone?: string;
  dietaryRestrictions?: string[];
  allergenRestrictions?: string[];
  accessibilityNeeds?: string[];
  specialMealRequired?: boolean;
}

export const EventGuestInviteCapability = {
  capabilityId: "EventGuest.invite",
  entity: "EventGuest",
  command: "invite",
  route: "/api/manifest/EventGuest/commands/invite",
  instanceCommand: true,
  clientParameterNames: ["eventId","name","email","phone","dietaryRestrictions","allergenRestrictions","accessibilityNeeds","specialMealRequired"],
  serverParameterNames: [],
  emits: ["EventGuestInvited"],
} as const;

/**
 * Build command input for EventGuest.invite.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventGuestInviteInput(client: EventGuestInviteClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventGuest.invite. */
export const EventGuestInviteInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventGuest.rsvpConfirm ---
export type EventGuestRsvpConfirmClientInput = Record<string, never>;

export const EventGuestRsvpConfirmCapability = {
  capabilityId: "EventGuest.rsvpConfirm",
  entity: "EventGuest",
  command: "rsvpConfirm",
  route: "/api/manifest/EventGuest/commands/rsvpConfirm",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventGuestRsvpConfirmed"],
} as const;

/**
 * Build command input for EventGuest.rsvpConfirm.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventGuestRsvpConfirmInput(client: EventGuestRsvpConfirmClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventGuest.rsvpConfirm. */
export const EventGuestRsvpConfirmInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventGuest.rsvpConfirm. */
export const EventGuestRsvpConfirmLifecycle = [
  {
    "property": "rsvpStatus",
    "from": "pending",
    "to": "confirmed",
    "proven": true
  },
  {
    "property": "rsvpStatus",
    "from": "confirmed",
    "to": "confirmed",
    "proven": true
  }
] as const;

// --- EventGuest.rsvpDecline ---
export interface EventGuestRsvpDeclineClientInput {
  reason?: string;
}

export const EventGuestRsvpDeclineCapability = {
  capabilityId: "EventGuest.rsvpDecline",
  entity: "EventGuest",
  command: "rsvpDecline",
  route: "/api/manifest/EventGuest/commands/rsvpDecline",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EventGuestRsvpDeclined"],
} as const;

/**
 * Build command input for EventGuest.rsvpDecline.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventGuestRsvpDeclineInput(client: EventGuestRsvpDeclineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventGuest.rsvpDecline. */
export const EventGuestRsvpDeclineInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventGuest.rsvpDecline. */
export const EventGuestRsvpDeclineLifecycle = [
  {
    "property": "rsvpStatus",
    "from": "pending",
    "to": "declined",
    "proven": true
  },
  {
    "property": "rsvpStatus",
    "from": "confirmed",
    "to": "declined",
    "proven": true
  }
] as const;

// --- EventGuest.withdraw ---
export interface EventGuestWithdrawClientInput {
  reason: string;
}

export const EventGuestWithdrawCapability = {
  capabilityId: "EventGuest.withdraw",
  entity: "EventGuest",
  command: "withdraw",
  route: "/api/manifest/EventGuest/commands/withdraw",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EventGuestWithdrawn"],
} as const;

/**
 * Build command input for EventGuest.withdraw.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventGuestWithdrawInput(client: EventGuestWithdrawClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventGuest.withdraw. */
export const EventGuestWithdrawInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventGuest",
    "queryKeyHint": "queryKeys.eventGuest.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventIngredientContribution.record ---
export interface EventIngredientContributionRecordClientInput {
  eventId: string;
  eventDishId: string;
  dishId: string;
  recipeId: string;
  ingredientId: string;
  /** Bounds: 1..∞ */
  quantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  servings: number;
  purchasingWeekStart?: string;
}

export const EventIngredientContributionRecordCapability = {
  capabilityId: "EventIngredientContribution.record",
  entity: "EventIngredientContribution",
  command: "record",
  route: "/api/manifest/EventIngredientContribution/commands/record",
  instanceCommand: true,
  clientParameterNames: ["eventId","eventDishId","dishId","recipeId","ingredientId","quantity","unit","servings","purchasingWeekStart"],
  serverParameterNames: [],
  emits: ["EventIngredientContributionRecorded"],
} as const;

/**
 * Build command input for EventIngredientContribution.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventIngredientContributionRecordInput(client: EventIngredientContributionRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventIngredientContribution.record. */
export const EventIngredientContributionRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventIngredientContribution",
    "queryKeyHint": "queryKeys.eventIngredientContribution.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventIngredientContribution",
    "queryKeyHint": "queryKeys.eventIngredientContribution.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventIngredientContribution.retire ---
export interface EventIngredientContributionRetireClientInput {
  reason: string;
}

export const EventIngredientContributionRetireCapability = {
  capabilityId: "EventIngredientContribution.retire",
  entity: "EventIngredientContribution",
  command: "retire",
  route: "/api/manifest/EventIngredientContribution/commands/retire",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EventIngredientContributionRecorded"],
} as const;

/**
 * Build command input for EventIngredientContribution.retire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventIngredientContributionRetireInput(client: EventIngredientContributionRetireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventIngredientContribution.retire. */
export const EventIngredientContributionRetireInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventIngredientContribution",
    "queryKeyHint": "queryKeys.eventIngredientContribution.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventIngredientContribution",
    "queryKeyHint": "queryKeys.eventIngredientContribution.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventIngredientContribution.revise ---
export interface EventIngredientContributionReviseClientInput {
  /** Bounds: 1..∞ */
  quantity: number;
  servings: number;
}

export const EventIngredientContributionReviseCapability = {
  capabilityId: "EventIngredientContribution.revise",
  entity: "EventIngredientContribution",
  command: "revise",
  route: "/api/manifest/EventIngredientContribution/commands/revise",
  instanceCommand: true,
  clientParameterNames: ["quantity","servings"],
  serverParameterNames: [],
  emits: ["EventIngredientContributionRecorded"],
} as const;

/**
 * Build command input for EventIngredientContribution.revise.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventIngredientContributionReviseInput(client: EventIngredientContributionReviseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventIngredientContribution.revise. */
export const EventIngredientContributionReviseInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventIngredientContribution",
    "queryKeyHint": "queryKeys.eventIngredientContribution.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventIngredientContribution",
    "queryKeyHint": "queryKeys.eventIngredientContribution.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventTemplate.archive ---
export interface EventTemplateArchiveClientInput {
  reason: string;
}

export const EventTemplateArchiveCapability = {
  capabilityId: "EventTemplate.archive",
  entity: "EventTemplate",
  command: "archive",
  route: "/api/manifest/EventTemplate/commands/archive",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["EventTemplateArchived"],
} as const;

/**
 * Build command input for EventTemplate.archive.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventTemplateArchiveInput(client: EventTemplateArchiveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventTemplate.archive. */
export const EventTemplateArchiveInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventTemplate",
    "queryKeyHint": "queryKeys.eventTemplate.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventTemplate",
    "queryKeyHint": "queryKeys.eventTemplate.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventTemplate.archive. */
export const EventTemplateArchiveLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "archived",
    "proven": true
  }
] as const;

// --- EventTemplate.define ---
export interface EventTemplateDefineClientInput {
  name: string;
  /** Allowed: "company" | "person" */
  clientType: "company" | "person";
  eventType: string;
  /** Bounds: 1..100000 */
  defaultHeadcount: number;
  menuId?: string;
  defaultStaffRoles?: string[];
  typicalEquipment?: string[];
  notes?: string;
  sourceEventId?: string;
}

export const EventTemplateDefineCapability = {
  capabilityId: "EventTemplate.define",
  entity: "EventTemplate",
  command: "define",
  route: "/api/manifest/EventTemplate/commands/define",
  instanceCommand: true,
  clientParameterNames: ["name","clientType","eventType","defaultHeadcount","menuId","defaultStaffRoles","typicalEquipment","notes","sourceEventId"],
  serverParameterNames: [],
  emits: ["EventTemplateDefined"],
} as const;

/**
 * Build command input for EventTemplate.define.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventTemplateDefineInput(client: EventTemplateDefineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventTemplate.define. */
export const EventTemplateDefineInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventTemplate",
    "queryKeyHint": "queryKeys.eventTemplate.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventTemplate",
    "queryKeyHint": "queryKeys.eventTemplate.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventTemplate.reactivate ---
export type EventTemplateReactivateClientInput = Record<string, never>;

export const EventTemplateReactivateCapability = {
  capabilityId: "EventTemplate.reactivate",
  entity: "EventTemplate",
  command: "reactivate",
  route: "/api/manifest/EventTemplate/commands/reactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventTemplateReactivated"],
} as const;

/**
 * Build command input for EventTemplate.reactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventTemplateReactivateInput(client: EventTemplateReactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventTemplate.reactivate. */
export const EventTemplateReactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventTemplate",
    "queryKeyHint": "queryKeys.eventTemplate.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventTemplate",
    "queryKeyHint": "queryKeys.eventTemplate.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for EventTemplate.reactivate. */
export const EventTemplateReactivateLifecycle = [
  {
    "property": "status",
    "from": "archived",
    "to": "active",
    "proven": true
  }
] as const;

// --- EventTemplate.revise ---
export interface EventTemplateReviseClientInput {
  name: string;
  /** Allowed: "company" | "person" */
  clientType: "company" | "person";
  eventType: string;
  /** Bounds: 1..100000 */
  defaultHeadcount: number;
  menuId?: string;
  defaultStaffRoles?: string[];
  typicalEquipment?: string[];
  notes?: string;
}

export const EventTemplateReviseCapability = {
  capabilityId: "EventTemplate.revise",
  entity: "EventTemplate",
  command: "revise",
  route: "/api/manifest/EventTemplate/commands/revise",
  instanceCommand: true,
  clientParameterNames: ["name","clientType","eventType","defaultHeadcount","menuId","defaultStaffRoles","typicalEquipment","notes"],
  serverParameterNames: [],
  emits: ["EventTemplateRevised"],
} as const;

/**
 * Build command input for EventTemplate.revise.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventTemplateReviseInput(client: EventTemplateReviseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventTemplate.revise. */
export const EventTemplateReviseInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventTemplate",
    "queryKeyHint": "queryKeys.eventTemplate.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventTemplate",
    "queryKeyHint": "queryKeys.eventTemplate.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventTimelineActivity.adjust ---
export interface EventTimelineActivityAdjustClientInput {
  name?: string;
  startsAt?: string;
  endsAt?: string;
  responsibleParty?: string;
  notes?: string;
}

export const EventTimelineActivityAdjustCapability = {
  capabilityId: "EventTimelineActivity.adjust",
  entity: "EventTimelineActivity",
  command: "adjust",
  route: "/api/manifest/EventTimelineActivity/commands/adjust",
  instanceCommand: true,
  clientParameterNames: ["name","startsAt","endsAt","responsibleParty","notes"],
  serverParameterNames: [],
  emits: ["EventTimelineActivityAdjusted"],
} as const;

/**
 * Build command input for EventTimelineActivity.adjust.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventTimelineActivityAdjustInput(client: EventTimelineActivityAdjustClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventTimelineActivity.adjust. */
export const EventTimelineActivityAdjustInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventTimelineActivity",
    "queryKeyHint": "queryKeys.eventTimelineActivity.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventTimelineActivity",
    "queryKeyHint": "queryKeys.eventTimelineActivity.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventTimelineActivity.remove ---
export type EventTimelineActivityRemoveClientInput = Record<string, never>;

export const EventTimelineActivityRemoveCapability = {
  capabilityId: "EventTimelineActivity.remove",
  entity: "EventTimelineActivity",
  command: "remove",
  route: "/api/manifest/EventTimelineActivity/commands/remove",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["EventTimelineActivityRemoved"],
} as const;

/**
 * Build command input for EventTimelineActivity.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventTimelineActivityRemoveInput(client: EventTimelineActivityRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventTimelineActivity.remove. */
export const EventTimelineActivityRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventTimelineActivity",
    "queryKeyHint": "queryKeys.eventTimelineActivity.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventTimelineActivity",
    "queryKeyHint": "queryKeys.eventTimelineActivity.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- EventTimelineActivity.schedule ---
export interface EventTimelineActivityScheduleClientInput {
  eventId: string;
  name: string;
  /** Must not be "". */
  startsAt: string & { readonly __nonEmpty?: true };
  endsAt?: string;
  responsibleParty?: string;
  notes?: string;
}

export const EventTimelineActivityScheduleCapability = {
  capabilityId: "EventTimelineActivity.schedule",
  entity: "EventTimelineActivity",
  command: "schedule",
  route: "/api/manifest/EventTimelineActivity/commands/schedule",
  instanceCommand: true,
  clientParameterNames: ["eventId","name","startsAt","endsAt","responsibleParty","notes"],
  serverParameterNames: [],
  emits: ["EventTimelineActivityScheduled"],
} as const;

/**
 * Build command input for EventTimelineActivity.schedule.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindEventTimelineActivityScheduleInput(client: EventTimelineActivityScheduleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful EventTimelineActivity.schedule. */
export const EventTimelineActivityScheduleInvalidation = [
  {
    "kind": "entityList",
    "entity": "EventTimelineActivity",
    "queryKeyHint": "queryKeys.eventTimelineActivity.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "EventTimelineActivity",
    "queryKeyHint": "queryKeys.eventTimelineActivity.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Incident.beginInvestigation ---
export type IncidentBeginInvestigationClientInput = Record<string, never>;

export const IncidentBeginInvestigationCapability = {
  capabilityId: "Incident.beginInvestigation",
  entity: "Incident",
  command: "beginInvestigation",
  route: "/api/manifest/Incident/commands/beginInvestigation",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["IncidentInvestigationStarted"],
} as const;

/**
 * Build command input for Incident.beginInvestigation.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIncidentBeginInvestigationInput(client: IncidentBeginInvestigationClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Incident.beginInvestigation. */
export const IncidentBeginInvestigationInvalidation = [
  {
    "kind": "entityList",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Incident.beginInvestigation. */
export const IncidentBeginInvestigationLifecycle = [
  {
    "property": "status",
    "from": "open",
    "to": "investigating",
    "proven": true
  }
] as const;

// --- Incident.clearCorrectiveActionLock ---
export type IncidentClearCorrectiveActionLockClientInput = Record<string, never>;

export const IncidentClearCorrectiveActionLockCapability = {
  capabilityId: "Incident.clearCorrectiveActionLock",
  entity: "Incident",
  command: "clearCorrectiveActionLock",
  route: "/api/manifest/Incident/commands/clearCorrectiveActionLock",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["IncidentCorrectiveActionCleared"],
} as const;

/**
 * Build command input for Incident.clearCorrectiveActionLock.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIncidentClearCorrectiveActionLockInput(client: IncidentClearCorrectiveActionLockClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Incident.clearCorrectiveActionLock. */
export const IncidentClearCorrectiveActionLockInvalidation = [
  {
    "kind": "entityList",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Incident.dismiss ---
export interface IncidentDismissClientInput {
  reason: string;
}

export const IncidentDismissCapability = {
  capabilityId: "Incident.dismiss",
  entity: "Incident",
  command: "dismiss",
  route: "/api/manifest/Incident/commands/dismiss",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["IncidentDismissed"],
} as const;

/**
 * Build command input for Incident.dismiss.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIncidentDismissInput(client: IncidentDismissClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Incident.dismiss. */
export const IncidentDismissInvalidation = [
  {
    "kind": "entityList",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Incident.dismiss. */
export const IncidentDismissLifecycle = [
  {
    "property": "status",
    "from": "open",
    "to": "dismissed",
    "proven": true
  },
  {
    "property": "status",
    "from": "investigating",
    "to": "dismissed",
    "proven": true
  }
] as const;

// --- Incident.markResolved ---
export interface IncidentMarkResolvedClientInput {
  resolution: string;
}

export const IncidentMarkResolvedCapability = {
  capabilityId: "Incident.markResolved",
  entity: "Incident",
  command: "markResolved",
  route: "/api/manifest/Incident/commands/markResolved",
  instanceCommand: true,
  clientParameterNames: ["resolution"],
  serverParameterNames: [],
  emits: ["IncidentResolved"],
} as const;

/**
 * Build command input for Incident.markResolved.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIncidentMarkResolvedInput(client: IncidentMarkResolvedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Incident.markResolved. */
export const IncidentMarkResolvedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Incident.markResolved. */
export const IncidentMarkResolvedLifecycle = [
  {
    "property": "status",
    "from": "open",
    "to": "resolved",
    "proven": true
  },
  {
    "property": "status",
    "from": "investigating",
    "to": "resolved",
    "proven": true
  }
] as const;

// --- Incident.report ---
export interface IncidentReportClientInput {
  eventId: string;
  /** Allowed: "low" | "medium" | "high" | "critical" */
  severity: "low" | "medium" | "high" | "critical";
  /** Allowed: "food_safety" | "allergen" | "injury" | "equipment" | "service" | "other" */
  category: "food_safety" | "allergen" | "injury" | "equipment" | "service" | "other";
  description: string;
  prepTaskId?: string;
  deliveryId?: string;
  shiftId?: string;
}

export const IncidentReportCapability = {
  capabilityId: "Incident.report",
  entity: "Incident",
  command: "report",
  route: "/api/manifest/Incident/commands/report",
  instanceCommand: true,
  clientParameterNames: ["eventId","severity","category","description","prepTaskId","deliveryId","shiftId"],
  serverParameterNames: [],
  emits: ["IncidentReported"],
} as const;

/**
 * Build command input for Incident.report.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIncidentReportInput(client: IncidentReportClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Incident.report. */
export const IncidentReportInvalidation = [
  {
    "kind": "entityList",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Incident",
    "queryKeyHint": "queryKeys.incident.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Ingredient.classifyAllergens ---
export interface IngredientClassifyAllergensClientInput {
  allergens: ("milk" | "eggs" | "fish" | "crustacean_shellfish" | "tree_nuts" | "peanuts" | "wheat" | "soybeans" | "sesame")[];
}

export const IngredientClassifyAllergensCapability = {
  capabilityId: "Ingredient.classifyAllergens",
  entity: "Ingredient",
  command: "classifyAllergens",
  route: "/api/manifest/Ingredient/commands/classifyAllergens",
  instanceCommand: true,
  clientParameterNames: ["allergens"],
  serverParameterNames: [],
  emits: ["IngredientAllergensClassified"],
} as const;

/**
 * Build command input for Ingredient.classifyAllergens.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientClassifyAllergensInput(client: IngredientClassifyAllergensClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.classifyAllergens. */
export const IngredientClassifyAllergensInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Ingredient.configureSubstitutes ---
export interface IngredientConfigureSubstitutesClientInput {
  substituteIngredientIds: string[];
}

export const IngredientConfigureSubstitutesCapability = {
  capabilityId: "Ingredient.configureSubstitutes",
  entity: "Ingredient",
  command: "configureSubstitutes",
  route: "/api/manifest/Ingredient/commands/configureSubstitutes",
  instanceCommand: true,
  clientParameterNames: ["substituteIngredientIds"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for Ingredient.configureSubstitutes.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientConfigureSubstitutesInput(client: IngredientConfigureSubstitutesClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.configureSubstitutes. */
export const IngredientConfigureSubstitutesInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Ingredient.discontinue ---
export interface IngredientDiscontinueClientInput {
  reason: string;
}

export const IngredientDiscontinueCapability = {
  capabilityId: "Ingredient.discontinue",
  entity: "Ingredient",
  command: "discontinue",
  route: "/api/manifest/Ingredient/commands/discontinue",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["IngredientDiscontinued"],
} as const;

/**
 * Build command input for Ingredient.discontinue.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDiscontinueInput(client: IngredientDiscontinueClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.discontinue. */
export const IngredientDiscontinueInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Ingredient.discontinue. */
export const IngredientDiscontinueLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "discontinued",
    "proven": true
  }
] as const;

// --- Ingredient.introduce ---
export interface IngredientIntroduceClientInput {
  name: string;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  costPerUnit: number;
  allergens?: ("milk" | "eggs" | "fish" | "crustacean_shellfish" | "tree_nuts" | "peanuts" | "wheat" | "soybeans" | "sesame")[];
  category?: string;
  preferredVendorId?: string;
}

export const IngredientIntroduceCapability = {
  capabilityId: "Ingredient.introduce",
  entity: "Ingredient",
  command: "introduce",
  route: "/api/manifest/Ingredient/commands/introduce",
  instanceCommand: true,
  clientParameterNames: ["name","unit","costPerUnit","allergens","category","preferredVendorId"],
  serverParameterNames: [],
  emits: ["IngredientIntroduced"],
} as const;

/**
 * Build command input for Ingredient.introduce.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientIntroduceInput(client: IngredientIntroduceClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.introduce. */
export const IngredientIntroduceInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Ingredient.reinstate ---
export type IngredientReinstateClientInput = Record<string, never>;

export const IngredientReinstateCapability = {
  capabilityId: "Ingredient.reinstate",
  entity: "Ingredient",
  command: "reinstate",
  route: "/api/manifest/Ingredient/commands/reinstate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["IngredientReinstated"],
} as const;

/**
 * Build command input for Ingredient.reinstate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientReinstateInput(client: IngredientReinstateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.reinstate. */
export const IngredientReinstateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Ingredient.reinstate. */
export const IngredientReinstateLifecycle = [
  {
    "property": "status",
    "from": "discontinued",
    "to": "active",
    "proven": true
  }
] as const;

// --- Ingredient.setPreferredVendor ---
export interface IngredientSetPreferredVendorClientInput {
  preferredVendorId?: string;
}

export const IngredientSetPreferredVendorCapability = {
  capabilityId: "Ingredient.setPreferredVendor",
  entity: "Ingredient",
  command: "setPreferredVendor",
  route: "/api/manifest/Ingredient/commands/setPreferredVendor",
  instanceCommand: true,
  clientParameterNames: ["preferredVendorId"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for Ingredient.setPreferredVendor.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientSetPreferredVendorInput(client: IngredientSetPreferredVendorClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.setPreferredVendor. */
export const IngredientSetPreferredVendorInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Ingredient.setPreferredVendors ---
export interface IngredientSetPreferredVendorsClientInput {
  preferredVendorIds: string[];
  preferredVendorId?: string;
}

export const IngredientSetPreferredVendorsCapability = {
  capabilityId: "Ingredient.setPreferredVendors",
  entity: "Ingredient",
  command: "setPreferredVendors",
  route: "/api/manifest/Ingredient/commands/setPreferredVendors",
  instanceCommand: true,
  clientParameterNames: ["preferredVendorIds","preferredVendorId"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for Ingredient.setPreferredVendors.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientSetPreferredVendorsInput(client: IngredientSetPreferredVendorsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.setPreferredVendors. */
export const IngredientSetPreferredVendorsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Ingredient.updateCosting ---
export interface IngredientUpdateCostingClientInput {
  /** Bounds: 0..∞ */
  costPerUnit: number;
}

export const IngredientUpdateCostingCapability = {
  capabilityId: "Ingredient.updateCosting",
  entity: "Ingredient",
  command: "updateCosting",
  route: "/api/manifest/Ingredient/commands/updateCosting",
  instanceCommand: true,
  clientParameterNames: ["costPerUnit"],
  serverParameterNames: [],
  emits: ["IngredientCostingUpdated"],
} as const;

/**
 * Build command input for Ingredient.updateCosting.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientUpdateCostingInput(client: IngredientUpdateCostingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.updateCosting. */
export const IngredientUpdateCostingInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Ingredient.updateDetails ---
export interface IngredientUpdateDetailsClientInput {
  name: string;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  category?: string;
}

export const IngredientUpdateDetailsCapability = {
  capabilityId: "Ingredient.updateDetails",
  entity: "Ingredient",
  command: "updateDetails",
  route: "/api/manifest/Ingredient/commands/updateDetails",
  instanceCommand: true,
  clientParameterNames: ["name","unit","category"],
  serverParameterNames: [],
  emits: ["IngredientDetailsUpdated"],
} as const;

/**
 * Build command input for Ingredient.updateDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientUpdateDetailsInput(client: IngredientUpdateDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Ingredient.updateDetails. */
export const IngredientUpdateDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Ingredient",
    "queryKeyHint": "queryKeys.ingredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- IngredientDemand.calculate ---
export interface IngredientDemandCalculateClientInput {
  eventId: string;
  ingredientId: string;
  /** Bounds: 1..∞ */
  requiredQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  servings?: number;
  dishId?: string;
  /** Bounds: 0..∞ */
  sourceRecipeLineQuantity?: number;
  /** Bounds: 0..∞ */
  sourceBatchMultiplier?: number;
  /** Bounds: 1..∞ */
  sourceYieldQuantity?: number;
}

export const IngredientDemandCalculateCapability = {
  capabilityId: "IngredientDemand.calculate",
  entity: "IngredientDemand",
  command: "calculate",
  route: "/api/manifest/IngredientDemand/commands/calculate",
  instanceCommand: true,
  clientParameterNames: ["eventId","ingredientId","requiredQuantity","unit","servings","dishId","sourceRecipeLineQuantity","sourceBatchMultiplier","sourceYieldQuantity"],
  serverParameterNames: [],
  emits: ["IngredientDemandCalculated"],
} as const;

/**
 * Build command input for IngredientDemand.calculate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDemandCalculateInput(client: IngredientDemandCalculateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientDemand.calculate. */
export const IngredientDemandCalculateInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for IngredientDemand.calculate. */
export const IngredientDemandCalculateLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "calculated",
    "proven": true
  }
] as const;

// --- IngredientDemand.confirm ---
export type IngredientDemandConfirmClientInput = Record<string, never>;

export const IngredientDemandConfirmCapability = {
  capabilityId: "IngredientDemand.confirm",
  entity: "IngredientDemand",
  command: "confirm",
  route: "/api/manifest/IngredientDemand/commands/confirm",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["IngredientDemandConfirmed"],
} as const;

/**
 * Build command input for IngredientDemand.confirm.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDemandConfirmInput(client: IngredientDemandConfirmClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientDemand.confirm. */
export const IngredientDemandConfirmInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for IngredientDemand.confirm. */
export const IngredientDemandConfirmLifecycle = [
  {
    "property": "status",
    "from": "calculated",
    "to": "confirmed",
    "proven": true
  }
] as const;

// --- IngredientDemand.ensurePurchaseEligible ---
export type IngredientDemandEnsurePurchaseEligibleClientInput = Record<string, never>;

export const IngredientDemandEnsurePurchaseEligibleCapability = {
  capabilityId: "IngredientDemand.ensurePurchaseEligible",
  entity: "IngredientDemand",
  command: "ensurePurchaseEligible",
  route: "/api/manifest/IngredientDemand/commands/ensurePurchaseEligible",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for IngredientDemand.ensurePurchaseEligible.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDemandEnsurePurchaseEligibleInput(client: IngredientDemandEnsurePurchaseEligibleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientDemand.ensurePurchaseEligible. */
export const IngredientDemandEnsurePurchaseEligibleInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- IngredientDemand.fulfill ---
export type IngredientDemandFulfillClientInput = Record<string, never>;

export const IngredientDemandFulfillCapability = {
  capabilityId: "IngredientDemand.fulfill",
  entity: "IngredientDemand",
  command: "fulfill",
  route: "/api/manifest/IngredientDemand/commands/fulfill",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["IngredientDemandFulfilled"],
} as const;

/**
 * Build command input for IngredientDemand.fulfill.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDemandFulfillInput(client: IngredientDemandFulfillClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientDemand.fulfill. */
export const IngredientDemandFulfillInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for IngredientDemand.fulfill. */
export const IngredientDemandFulfillLifecycle = [
  {
    "property": "status",
    "from": "confirmed",
    "to": "fulfilled",
    "proven": true
  }
] as const;

// --- IngredientDemand.markReleased ---
export type IngredientDemandMarkReleasedClientInput = Record<string, never>;

export const IngredientDemandMarkReleasedCapability = {
  capabilityId: "IngredientDemand.markReleased",
  entity: "IngredientDemand",
  command: "markReleased",
  route: "/api/manifest/IngredientDemand/commands/markReleased",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["IngredientDemandReleased"],
} as const;

/**
 * Build command input for IngredientDemand.markReleased.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDemandMarkReleasedInput(client: IngredientDemandMarkReleasedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientDemand.markReleased. */
export const IngredientDemandMarkReleasedInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- IngredientDemand.recalculate ---
export interface IngredientDemandRecalculateClientInput {
  /** Bounds: 1..∞ */
  newQuantity: number;
  reason: string;
}

export const IngredientDemandRecalculateCapability = {
  capabilityId: "IngredientDemand.recalculate",
  entity: "IngredientDemand",
  command: "recalculate",
  route: "/api/manifest/IngredientDemand/commands/recalculate",
  instanceCommand: true,
  clientParameterNames: ["newQuantity","reason"],
  serverParameterNames: [],
  emits: ["IngredientDemandRecalculated"],
} as const;

/**
 * Build command input for IngredientDemand.recalculate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDemandRecalculateInput(client: IngredientDemandRecalculateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientDemand.recalculate. */
export const IngredientDemandRecalculateInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- IngredientDemand.supersede ---
export interface IngredientDemandSupersedeClientInput {
  reason: string;
}

export const IngredientDemandSupersedeCapability = {
  capabilityId: "IngredientDemand.supersede",
  entity: "IngredientDemand",
  command: "supersede",
  route: "/api/manifest/IngredientDemand/commands/supersede",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["IngredientDemandSuperseded"],
} as const;

/**
 * Build command input for IngredientDemand.supersede.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDemandSupersedeInput(client: IngredientDemandSupersedeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientDemand.supersede. */
export const IngredientDemandSupersedeInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for IngredientDemand.supersede. */
export const IngredientDemandSupersedeLifecycle = [
  {
    "property": "status",
    "from": "calculated",
    "to": "superseded",
    "proven": true
  },
  {
    "property": "status",
    "from": "confirmed",
    "to": "superseded",
    "proven": true
  }
] as const;

// --- IngredientDemand.syncFromContributions ---
export interface IngredientDemandSyncFromContributionsClientInput {
  eventId: string;
  ingredientId: string;
  requiredQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  purchasingWeekStart?: string;
}

export const IngredientDemandSyncFromContributionsCapability = {
  capabilityId: "IngredientDemand.syncFromContributions",
  entity: "IngredientDemand",
  command: "syncFromContributions",
  route: "/api/manifest/IngredientDemand/commands/syncFromContributions",
  instanceCommand: true,
  clientParameterNames: ["eventId","ingredientId","requiredQuantity","unit","purchasingWeekStart"],
  serverParameterNames: [],
  emits: ["IngredientDemandCalculated"],
} as const;

/**
 * Build command input for IngredientDemand.syncFromContributions.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientDemandSyncFromContributionsInput(client: IngredientDemandSyncFromContributionsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientDemand.syncFromContributions. */
export const IngredientDemandSyncFromContributionsInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientDemand",
    "queryKeyHint": "queryKeys.ingredientDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- IngredientPriceObservation.record ---
export interface IngredientPriceObservationRecordClientInput {
  ingredientId: string;
  vendorId: string;
  vendorOrderId: string;
  vendorOrderLineId: string;
  /** Bounds: 1..∞ */
  receiptQuantity: number;
  /** Bounds: 1..∞ */
  cumulativeReceivedQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  unitPrice: number;
}

export const IngredientPriceObservationRecordCapability = {
  capabilityId: "IngredientPriceObservation.record",
  entity: "IngredientPriceObservation",
  command: "record",
  route: "/api/manifest/IngredientPriceObservation/commands/record",
  instanceCommand: true,
  clientParameterNames: ["ingredientId","vendorId","vendorOrderId","vendorOrderLineId","receiptQuantity","cumulativeReceivedQuantity","unit","unitPrice"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for IngredientPriceObservation.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindIngredientPriceObservationRecordInput(client: IngredientPriceObservationRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful IngredientPriceObservation.record. */
export const IngredientPriceObservationRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "IngredientPriceObservation",
    "queryKeyHint": "queryKeys.ingredientPriceObservation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "IngredientPriceObservation",
    "queryKeyHint": "queryKeys.ingredientPriceObservation.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.adjustQuantity ---
export interface InventoryItemAdjustQuantityClientInput {
  delta: number;
  reason: string;
}

export const InventoryItemAdjustQuantityCapability = {
  capabilityId: "InventoryItem.adjustQuantity",
  entity: "InventoryItem",
  command: "adjustQuantity",
  route: "/api/manifest/InventoryItem/commands/adjustQuantity",
  instanceCommand: true,
  clientParameterNames: ["delta","reason"],
  serverParameterNames: [],
  emits: ["InventoryQuantityAdjusted"],
} as const;

/**
 * Build command input for InventoryItem.adjustQuantity.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemAdjustQuantityInput(client: InventoryItemAdjustQuantityClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.adjustQuantity. */
export const InventoryItemAdjustQuantityInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.open ---
export interface InventoryItemOpenClientInput {
  ingredientId: string;
  locationId: string;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  quantityOnHand?: number;
  /** Bounds: 0..∞ */
  parLevel?: number;
  /** Bounds: 0..∞ */
  reorderThreshold?: number;
  /** Bounds: 0..∞ */
  unitCost?: number;
}

export const InventoryItemOpenCapability = {
  capabilityId: "InventoryItem.open",
  entity: "InventoryItem",
  command: "open",
  route: "/api/manifest/InventoryItem/commands/open",
  instanceCommand: true,
  clientParameterNames: ["ingredientId","locationId","unit","quantityOnHand","parLevel","reorderThreshold","unitCost"],
  serverParameterNames: [],
  emits: ["InventoryItemOpened"],
} as const;

/**
 * Build command input for InventoryItem.open.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemOpenInput(client: InventoryItemOpenClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.open. */
export const InventoryItemOpenInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.receiveStock ---
export interface InventoryItemReceiveStockClientInput {
  /** Bounds: 1..∞ */
  quantity: number;
  /** Bounds: 0..∞ */
  unitCost?: number;
}

export const InventoryItemReceiveStockCapability = {
  capabilityId: "InventoryItem.receiveStock",
  entity: "InventoryItem",
  command: "receiveStock",
  route: "/api/manifest/InventoryItem/commands/receiveStock",
  instanceCommand: true,
  clientParameterNames: ["quantity","unitCost"],
  serverParameterNames: [],
  emits: ["InventoryStockReceived"],
} as const;

/**
 * Build command input for InventoryItem.receiveStock.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemReceiveStockInput(client: InventoryItemReceiveStockClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.receiveStock. */
export const InventoryItemReceiveStockInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.recount ---
export interface InventoryItemRecountClientInput {
  /** Bounds: 0..∞ */
  actualQuantity: number;
}

export const InventoryItemRecountCapability = {
  capabilityId: "InventoryItem.recount",
  entity: "InventoryItem",
  command: "recount",
  route: "/api/manifest/InventoryItem/commands/recount",
  instanceCommand: true,
  clientParameterNames: ["actualQuantity"],
  serverParameterNames: [],
  emits: ["InventoryRecounted"],
} as const;

/**
 * Build command input for InventoryItem.recount.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemRecountInput(client: InventoryItemRecountClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.recount. */
export const InventoryItemRecountInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.remove ---
export interface InventoryItemRemoveClientInput {
  reason: string;
}

export const InventoryItemRemoveCapability = {
  capabilityId: "InventoryItem.remove",
  entity: "InventoryItem",
  command: "remove",
  route: "/api/manifest/InventoryItem/commands/remove",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["InventoryItemRemoved"],
} as const;

/**
 * Build command input for InventoryItem.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemRemoveInput(client: InventoryItemRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.remove. */
export const InventoryItemRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.setExpiry ---
export interface InventoryItemSetExpiryClientInput {
  bestBeforeAt?: string;
  useByAt?: string;
}

export const InventoryItemSetExpiryCapability = {
  capabilityId: "InventoryItem.setExpiry",
  entity: "InventoryItem",
  command: "setExpiry",
  route: "/api/manifest/InventoryItem/commands/setExpiry",
  instanceCommand: true,
  clientParameterNames: ["bestBeforeAt","useByAt"],
  serverParameterNames: [],
  emits: ["InventoryExpiryUpdated"],
} as const;

/**
 * Build command input for InventoryItem.setExpiry.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemSetExpiryInput(client: InventoryItemSetExpiryClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.setExpiry. */
export const InventoryItemSetExpiryInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.transferIn ---
export interface InventoryItemTransferInClientInput {
  /** Bounds: 1..∞ */
  quantity: number;
  sourceLocationId: string;
}

export const InventoryItemTransferInCapability = {
  capabilityId: "InventoryItem.transferIn",
  entity: "InventoryItem",
  command: "transferIn",
  route: "/api/manifest/InventoryItem/commands/transferIn",
  instanceCommand: true,
  clientParameterNames: ["quantity","sourceLocationId"],
  serverParameterNames: [],
  emits: ["InventoryTransferredIn"],
} as const;

/**
 * Build command input for InventoryItem.transferIn.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemTransferInInput(client: InventoryItemTransferInClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.transferIn. */
export const InventoryItemTransferInInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.transferOut ---
export interface InventoryItemTransferOutClientInput {
  /** Bounds: 1..∞ */
  quantity: number;
  destinationLocationId: string;
}

export const InventoryItemTransferOutCapability = {
  capabilityId: "InventoryItem.transferOut",
  entity: "InventoryItem",
  command: "transferOut",
  route: "/api/manifest/InventoryItem/commands/transferOut",
  instanceCommand: true,
  clientParameterNames: ["quantity","destinationLocationId"],
  serverParameterNames: [],
  emits: ["InventoryTransferredOut"],
} as const;

/**
 * Build command input for InventoryItem.transferOut.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemTransferOutInput(client: InventoryItemTransferOutClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.transferOut. */
export const InventoryItemTransferOutInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryItem.updateLevels ---
export interface InventoryItemUpdateLevelsClientInput {
  /** Bounds: 0..∞ */
  parLevel: number;
  /** Bounds: 0..∞ */
  reorderThreshold: number;
  /** Bounds: 0..∞ */
  unitCost?: number;
}

export const InventoryItemUpdateLevelsCapability = {
  capabilityId: "InventoryItem.updateLevels",
  entity: "InventoryItem",
  command: "updateLevels",
  route: "/api/manifest/InventoryItem/commands/updateLevels",
  instanceCommand: true,
  clientParameterNames: ["parLevel","reorderThreshold","unitCost"],
  serverParameterNames: [],
  emits: ["InventoryLevelsUpdated"],
} as const;

/**
 * Build command input for InventoryItem.updateLevels.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryItemUpdateLevelsInput(client: InventoryItemUpdateLevelsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryItem.updateLevels. */
export const InventoryItemUpdateLevelsInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryItem",
    "queryKeyHint": "queryKeys.inventoryItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryLot.record ---
export interface InventoryLotRecordClientInput {
  supplierLotNumber: string;
  vendorOrderLineId: string;
  vendorOrderId: string;
  vendorId: string;
  ingredientId: string;
  ingredientDemandId?: string;
  eventId?: string;
  locationId: string;
  /** Bounds: 1..∞ */
  receiptQuantity: number;
  /** Bounds: 1..∞ */
  cumulativeReceivedQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  unitCost: number;
}

export const InventoryLotRecordCapability = {
  capabilityId: "InventoryLot.record",
  entity: "InventoryLot",
  command: "record",
  route: "/api/manifest/InventoryLot/commands/record",
  instanceCommand: true,
  clientParameterNames: ["supplierLotNumber","vendorOrderLineId","vendorOrderId","vendorId","ingredientId","ingredientDemandId","eventId","locationId","receiptQuantity","cumulativeReceivedQuantity","unit","unitCost"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for InventoryLot.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryLotRecordInput(client: InventoryLotRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryLot.record. */
export const InventoryLotRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryLot",
    "queryKeyHint": "queryKeys.inventoryLot.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryLot",
    "queryKeyHint": "queryKeys.inventoryLot.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- InventoryReservation.consume ---
export type InventoryReservationConsumeClientInput = Record<string, never>;

export const InventoryReservationConsumeCapability = {
  capabilityId: "InventoryReservation.consume",
  entity: "InventoryReservation",
  command: "consume",
  route: "/api/manifest/InventoryReservation/commands/consume",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["InventoryReservationConsumed"],
} as const;

/**
 * Build command input for InventoryReservation.consume.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryReservationConsumeInput(client: InventoryReservationConsumeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryReservation.consume. */
export const InventoryReservationConsumeInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryReservation",
    "queryKeyHint": "queryKeys.inventoryReservation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryReservation",
    "queryKeyHint": "queryKeys.inventoryReservation.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for InventoryReservation.consume. */
export const InventoryReservationConsumeLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "consumed",
    "proven": true
  }
] as const;

// --- InventoryReservation.release ---
export interface InventoryReservationReleaseClientInput {
  reason: string;
}

export const InventoryReservationReleaseCapability = {
  capabilityId: "InventoryReservation.release",
  entity: "InventoryReservation",
  command: "release",
  route: "/api/manifest/InventoryReservation/commands/release",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["InventoryReservationReleased"],
} as const;

/**
 * Build command input for InventoryReservation.release.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryReservationReleaseInput(client: InventoryReservationReleaseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryReservation.release. */
export const InventoryReservationReleaseInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryReservation",
    "queryKeyHint": "queryKeys.inventoryReservation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryReservation",
    "queryKeyHint": "queryKeys.inventoryReservation.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for InventoryReservation.release. */
export const InventoryReservationReleaseLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "released",
    "proven": true
  }
] as const;

// --- InventoryReservation.reserve ---
export interface InventoryReservationReserveClientInput {
  inventoryItemId: string;
  eventId: string;
  ingredientId: string;
  /** Bounds: 1..∞ */
  quantity: number;
  inventoryLotId?: string;
}

export const InventoryReservationReserveCapability = {
  capabilityId: "InventoryReservation.reserve",
  entity: "InventoryReservation",
  command: "reserve",
  route: "/api/manifest/InventoryReservation/commands/reserve",
  instanceCommand: true,
  clientParameterNames: ["inventoryItemId","eventId","ingredientId","quantity","inventoryLotId"],
  serverParameterNames: [],
  emits: ["InventoryReserved"],
} as const;

/**
 * Build command input for InventoryReservation.reserve.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInventoryReservationReserveInput(client: InventoryReservationReserveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful InventoryReservation.reserve. */
export const InventoryReservationReserveInvalidation = [
  {
    "kind": "entityList",
    "entity": "InventoryReservation",
    "queryKeyHint": "queryKeys.inventoryReservation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "InventoryReservation",
    "queryKeyHint": "queryKeys.inventoryReservation.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for InventoryReservation.reserve. */
export const InventoryReservationReserveLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "active",
    "proven": true
  }
] as const;

// --- Invoice.applyCredit ---
export interface InvoiceApplyCreditClientInput {
  /** Bounds: 1..∞ */
  creditAmount: number;
  creditMemoId: string;
}

export const InvoiceApplyCreditCapability = {
  capabilityId: "Invoice.applyCredit",
  entity: "Invoice",
  command: "applyCredit",
  route: "/api/manifest/Invoice/commands/applyCredit",
  instanceCommand: true,
  clientParameterNames: ["creditAmount","creditMemoId"],
  serverParameterNames: [],
  emits: ["InvoiceCreditApplied"],
} as const;

/**
 * Build command input for Invoice.applyCredit.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceApplyCreditInput(client: InvoiceApplyCreditClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.applyCredit. */
export const InvoiceApplyCreditInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.applyPayment ---
export interface InvoiceApplyPaymentClientInput {
  /** Bounds: 1..∞ */
  paymentAmount: number;
  paymentId?: string;
}

export const InvoiceApplyPaymentCapability = {
  capabilityId: "Invoice.applyPayment",
  entity: "Invoice",
  command: "applyPayment",
  route: "/api/manifest/Invoice/commands/applyPayment",
  instanceCommand: true,
  clientParameterNames: ["paymentAmount","paymentId"],
  serverParameterNames: [],
  emits: ["InvoicePaymentApplied"],
} as const;

/**
 * Build command input for Invoice.applyPayment.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceApplyPaymentInput(client: InvoiceApplyPaymentClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.applyPayment. */
export const InvoiceApplyPaymentInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.issue ---
export interface InvoiceIssueClientInput {
  clientId: string;
  invoiceNumber: string;
  /** Bounds: 0..∞ */
  subtotal: number;
  /** Bounds: 0..∞ */
  taxAmount: number;
  /** Bounds: 0..∞ */
  discountAmount: number;
  /** Bounds: 0..∞ */
  total: number;
  eventId?: string;
  paymentTermsDays?: number;
  dueDate?: string;
  notes?: string;
  lineItems?: unknown;
  taxBreakdown?: unknown;
}

export const InvoiceIssueCapability = {
  capabilityId: "Invoice.issue",
  entity: "Invoice",
  command: "issue",
  route: "/api/manifest/Invoice/commands/issue",
  instanceCommand: true,
  clientParameterNames: ["clientId","invoiceNumber","subtotal","taxAmount","discountAmount","total","eventId","paymentTermsDays","dueDate","notes","lineItems","taxBreakdown"],
  serverParameterNames: [],
  emits: ["InvoiceIssued"],
} as const;

/**
 * Build command input for Invoice.issue.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceIssueInput(client: InvoiceIssueClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.issue. */
export const InvoiceIssueInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.markDepositPaid ---
export type InvoiceMarkDepositPaidClientInput = Record<string, never>;

export const InvoiceMarkDepositPaidCapability = {
  capabilityId: "Invoice.markDepositPaid",
  entity: "Invoice",
  command: "markDepositPaid",
  route: "/api/manifest/Invoice/commands/markDepositPaid",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["InvoiceDepositPaid"],
} as const;

/**
 * Build command input for Invoice.markDepositPaid.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceMarkDepositPaidInput(client: InvoiceMarkDepositPaidClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.markDepositPaid. */
export const InvoiceMarkDepositPaidInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.markOverdue ---
export type InvoiceMarkOverdueClientInput = Record<string, never>;

export const InvoiceMarkOverdueCapability = {
  capabilityId: "Invoice.markOverdue",
  entity: "Invoice",
  command: "markOverdue",
  route: "/api/manifest/Invoice/commands/markOverdue",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["InvoiceMarkedOverdue"],
} as const;

/**
 * Build command input for Invoice.markOverdue.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceMarkOverdueInput(client: InvoiceMarkOverdueClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.markOverdue. */
export const InvoiceMarkOverdueInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Invoice.markOverdue. */
export const InvoiceMarkOverdueLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "overdue",
    "proven": true
  },
  {
    "property": "status",
    "from": "viewed",
    "to": "overdue",
    "proven": true
  },
  {
    "property": "status",
    "from": "partial",
    "to": "overdue",
    "proven": true
  }
] as const;

// --- Invoice.markViewed ---
export type InvoiceMarkViewedClientInput = Record<string, never>;

export const InvoiceMarkViewedCapability = {
  capabilityId: "Invoice.markViewed",
  entity: "Invoice",
  command: "markViewed",
  route: "/api/manifest/Invoice/commands/markViewed",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["InvoiceViewed"],
} as const;

/**
 * Build command input for Invoice.markViewed.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceMarkViewedInput(client: InvoiceMarkViewedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.markViewed. */
export const InvoiceMarkViewedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Invoice.markViewed. */
export const InvoiceMarkViewedLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "viewed",
    "proven": true
  }
] as const;

// --- Invoice.markVoided ---
export interface InvoiceMarkVoidedClientInput {
  reason: string;
}

export const InvoiceMarkVoidedCapability = {
  capabilityId: "Invoice.markVoided",
  entity: "Invoice",
  command: "markVoided",
  route: "/api/manifest/Invoice/commands/markVoided",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["InvoiceVoided"],
} as const;

/**
 * Build command input for Invoice.markVoided.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceMarkVoidedInput(client: InvoiceMarkVoidedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.markVoided. */
export const InvoiceMarkVoidedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Invoice.markVoided. */
export const InvoiceMarkVoidedLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "voided",
    "proven": true
  },
  {
    "property": "status",
    "from": "sent",
    "to": "voided",
    "proven": true
  },
  {
    "property": "status",
    "from": "viewed",
    "to": "voided",
    "proven": true
  },
  {
    "property": "status",
    "from": "overdue",
    "to": "voided",
    "proven": true
  }
] as const;

// --- Invoice.reassignClient ---
export type InvoiceReassignClientClientInput = Record<string, never>;

export const InvoiceReassignClientCapability = {
  capabilityId: "Invoice.reassignClient",
  entity: "Invoice",
  command: "reassignClient",
  route: "/api/manifest/Invoice/commands/reassignClient",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["InvoiceClientReassigned"],
} as const;

/**
 * Build command input for Invoice.reassignClient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceReassignClientInput(client: InvoiceReassignClientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.reassignClient. */
export const InvoiceReassignClientInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.recordCreditMemo ---
export interface InvoiceRecordCreditMemoClientInput {
  /** Bounds: 1..∞ */
  creditAmount: number;
  creditMemoId: string;
}

export const InvoiceRecordCreditMemoCapability = {
  capabilityId: "Invoice.recordCreditMemo",
  entity: "Invoice",
  command: "recordCreditMemo",
  route: "/api/manifest/Invoice/commands/recordCreditMemo",
  instanceCommand: true,
  clientParameterNames: ["creditAmount","creditMemoId"],
  serverParameterNames: [],
  emits: ["InvoiceCreditMemoRecorded"],
} as const;

/**
 * Build command input for Invoice.recordCreditMemo.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceRecordCreditMemoInput(client: InvoiceRecordCreditMemoClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.recordCreditMemo. */
export const InvoiceRecordCreditMemoInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.recordRefund ---
export interface InvoiceRecordRefundClientInput {
  /** Bounds: 1..∞ */
  refundAmount: number;
  paymentId: string;
}

export const InvoiceRecordRefundCapability = {
  capabilityId: "Invoice.recordRefund",
  entity: "Invoice",
  command: "recordRefund",
  route: "/api/manifest/Invoice/commands/recordRefund",
  instanceCommand: true,
  clientParameterNames: ["refundAmount","paymentId"],
  serverParameterNames: [],
  emits: ["InvoiceRefundRecorded"],
} as const;

/**
 * Build command input for Invoice.recordRefund.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceRecordRefundInput(client: InvoiceRecordRefundClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.recordRefund. */
export const InvoiceRecordRefundInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Invoice.recordRefund. */
export const InvoiceRecordRefundLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "partial",
    "proven": true
  },
  {
    "property": "status",
    "from": "viewed",
    "to": "partial",
    "proven": true
  },
  {
    "property": "status",
    "from": "overdue",
    "to": "partial",
    "proven": true
  },
  {
    "property": "status",
    "from": "partial",
    "to": "partial",
    "proven": true
  },
  {
    "property": "status",
    "from": "paid",
    "to": "partial",
    "proven": true
  }
] as const;

// --- Invoice.send ---
export type InvoiceSendClientInput = Record<string, never>;

export const InvoiceSendCapability = {
  capabilityId: "Invoice.send",
  entity: "Invoice",
  command: "send",
  route: "/api/manifest/Invoice/commands/send",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["InvoiceSent"],
} as const;

/**
 * Build command input for Invoice.send.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceSendInput(client: InvoiceSendClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.send. */
export const InvoiceSendInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Invoice.send. */
export const InvoiceSendLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "sent",
    "proven": true
  }
] as const;

// --- Invoice.sendBalanceReminder ---
export type InvoiceSendBalanceReminderClientInput = Record<string, never>;

export const InvoiceSendBalanceReminderCapability = {
  capabilityId: "Invoice.sendBalanceReminder",
  entity: "Invoice",
  command: "sendBalanceReminder",
  route: "/api/manifest/Invoice/commands/sendBalanceReminder",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["InvoiceBalanceReminderSent"],
} as const;

/**
 * Build command input for Invoice.sendBalanceReminder.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceSendBalanceReminderInput(client: InvoiceSendBalanceReminderClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.sendBalanceReminder. */
export const InvoiceSendBalanceReminderInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.setDeposit ---
export interface InvoiceSetDepositClientInput {
  /** Bounds: 0..∞ */
  depositAmount: number;
  /** Bounds: 0..∞ */
  balanceReminderLeadDays?: number;
}

export const InvoiceSetDepositCapability = {
  capabilityId: "Invoice.setDeposit",
  entity: "Invoice",
  command: "setDeposit",
  route: "/api/manifest/Invoice/commands/setDeposit",
  instanceCommand: true,
  clientParameterNames: ["depositAmount","balanceReminderLeadDays"],
  serverParameterNames: [],
  emits: ["InvoiceDepositSet"],
} as const;

/**
 * Build command input for Invoice.setDeposit.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceSetDepositInput(client: InvoiceSetDepositClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.setDeposit. */
export const InvoiceSetDepositInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.stageClientMerge ---
export interface InvoiceStageClientMergeClientInput {
  clientMergeId: string;
  clientId: string;
}

export const InvoiceStageClientMergeCapability = {
  capabilityId: "Invoice.stageClientMerge",
  entity: "Invoice",
  command: "stageClientMerge",
  route: "/api/manifest/Invoice/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","clientId"],
  serverParameterNames: [],
  emits: ["InvoiceClientMergeStaged"],
} as const;

/**
 * Build command input for Invoice.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceStageClientMergeInput(client: InvoiceStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.stageClientMerge. */
export const InvoiceStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Invoice.writeOff ---
export interface InvoiceWriteOffClientInput {
  reason: string;
  /** Bounds: 1..∞ */
  writeOffAmount: number;
}

export const InvoiceWriteOffCapability = {
  capabilityId: "Invoice.writeOff",
  entity: "Invoice",
  command: "writeOff",
  route: "/api/manifest/Invoice/commands/writeOff",
  instanceCommand: true,
  clientParameterNames: ["reason","writeOffAmount"],
  serverParameterNames: [],
  emits: ["InvoiceWrittenOff"],
} as const;

/**
 * Build command input for Invoice.writeOff.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindInvoiceWriteOffInput(client: InvoiceWriteOffClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Invoice.writeOff. */
export const InvoiceWriteOffInvalidation = [
  {
    "kind": "entityList",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Invoice",
    "queryKeyHint": "queryKeys.invoice.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Invoice.writeOff. */
export const InvoiceWriteOffLifecycle = [
  {
    "property": "status",
    "from": "overdue",
    "to": "written_off",
    "proven": true
  },
  {
    "property": "status",
    "from": "partial",
    "to": "written_off",
    "proven": true
  }
] as const;

// --- Lead.capture ---
export interface LeadCaptureClientInput {
  /** Allowed: "company" | "person" */
  leadType: "company" | "person";
  source: string;
  /** Bounds: 0..∞ */
  estimatedValue: number;
  companyName?: string;
  givenName?: string;
  familyName?: string;
  email?: string;
  phone?: string;
  /** Bounds: 0..100 */
  probability?: number;
  notes?: string;
}

export const LeadCaptureCapability = {
  capabilityId: "Lead.capture",
  entity: "Lead",
  command: "capture",
  route: "/api/manifest/Lead/commands/capture",
  instanceCommand: true,
  clientParameterNames: ["leadType","source","estimatedValue","companyName","givenName","familyName","email","phone","probability","notes"],
  serverParameterNames: [],
  emits: ["LeadCaptured"],
} as const;

/**
 * Build command input for Lead.capture.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindLeadCaptureInput(client: LeadCaptureClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Lead.capture. */
export const LeadCaptureInvalidation = [
  {
    "kind": "entityList",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Lead.confirmConversion ---
export type LeadConfirmConversionClientInput = Record<string, never>;

export const LeadConfirmConversionCapability = {
  capabilityId: "Lead.confirmConversion",
  entity: "Lead",
  command: "confirmConversion",
  route: "/api/manifest/Lead/commands/confirmConversion",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["LeadConverted"],
} as const;

/**
 * Build command input for Lead.confirmConversion.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindLeadConfirmConversionInput(client: LeadConfirmConversionClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Lead.confirmConversion. */
export const LeadConfirmConversionInvalidation = [
  {
    "kind": "entityList",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Lead.confirmProposalSent ---
export type LeadConfirmProposalSentClientInput = Record<string, never>;

export const LeadConfirmProposalSentCapability = {
  capabilityId: "Lead.confirmProposalSent",
  entity: "Lead",
  command: "confirmProposalSent",
  route: "/api/manifest/Lead/commands/confirmProposalSent",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["LeadProposalLinked"],
} as const;

/**
 * Build command input for Lead.confirmProposalSent.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindLeadConfirmProposalSentInput(client: LeadConfirmProposalSentClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Lead.confirmProposalSent. */
export const LeadConfirmProposalSentInvalidation = [
  {
    "kind": "entityList",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Lead.reviseDetails ---
export interface LeadReviseDetailsClientInput {
  /** Allowed: "company" | "person" */
  leadType: "company" | "person";
  source: string;
  companyName?: string;
  givenName?: string;
  familyName?: string;
  email?: string;
  phone?: string;
  notes?: string;
}

export const LeadReviseDetailsCapability = {
  capabilityId: "Lead.reviseDetails",
  entity: "Lead",
  command: "reviseDetails",
  route: "/api/manifest/Lead/commands/reviseDetails",
  instanceCommand: true,
  clientParameterNames: ["leadType","source","companyName","givenName","familyName","email","phone","notes"],
  serverParameterNames: [],
  emits: ["LeadDetailsRevised"],
} as const;

/**
 * Build command input for Lead.reviseDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindLeadReviseDetailsInput(client: LeadReviseDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Lead.reviseDetails. */
export const LeadReviseDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Lead.stageConversion ---
export interface LeadStageConversionClientInput {
  clientId: string;
  clientContactId?: string;
}

export const LeadStageConversionCapability = {
  capabilityId: "Lead.stageConversion",
  entity: "Lead",
  command: "stageConversion",
  route: "/api/manifest/Lead/commands/stageConversion",
  instanceCommand: true,
  clientParameterNames: ["clientId","clientContactId"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for Lead.stageConversion.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindLeadStageConversionInput(client: LeadStageConversionClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Lead.stageConversion. */
export const LeadStageConversionInvalidation = [
  {
    "kind": "entityList",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Lead.stageProposal ---
export interface LeadStageProposalClientInput {
  proposalId: string;
}

export const LeadStageProposalCapability = {
  capabilityId: "Lead.stageProposal",
  entity: "Lead",
  command: "stageProposal",
  route: "/api/manifest/Lead/commands/stageProposal",
  instanceCommand: true,
  clientParameterNames: ["proposalId"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for Lead.stageProposal.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindLeadStageProposalInput(client: LeadStageProposalClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Lead.stageProposal. */
export const LeadStageProposalInvalidation = [
  {
    "kind": "entityList",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Lead.updatePipeline ---
export interface LeadUpdatePipelineClientInput {
  /** Allowed: "new" | "qualified" | "proposalSent" | "negotiating" */
  stage: "new" | "qualified" | "proposalSent" | "negotiating";
  /** Bounds: 0..∞ */
  estimatedValue: number;
  /** Bounds: 0..100 */
  probability: number;
}

export const LeadUpdatePipelineCapability = {
  capabilityId: "Lead.updatePipeline",
  entity: "Lead",
  command: "updatePipeline",
  route: "/api/manifest/Lead/commands/updatePipeline",
  instanceCommand: true,
  clientParameterNames: ["stage","estimatedValue","probability"],
  serverParameterNames: [],
  emits: ["LeadPipelineUpdated"],
} as const;

/**
 * Build command input for Lead.updatePipeline.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindLeadUpdatePipelineInput(client: LeadUpdatePipelineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Lead.updatePipeline. */
export const LeadUpdatePipelineInvalidation = [
  {
    "kind": "entityList",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Lead",
    "queryKeyHint": "queryKeys.lead.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Menu.archive ---
export interface MenuArchiveClientInput {
  reason: string;
}

export const MenuArchiveCapability = {
  capabilityId: "Menu.archive",
  entity: "Menu",
  command: "archive",
  route: "/api/manifest/Menu/commands/archive",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["MenuArchived"],
} as const;

/**
 * Build command input for Menu.archive.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuArchiveInput(client: MenuArchiveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Menu.archive. */
export const MenuArchiveInvalidation = [
  {
    "kind": "entityList",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Menu.archive. */
export const MenuArchiveLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "archived",
    "proven": true
  },
  {
    "property": "status",
    "from": "published",
    "to": "archived",
    "proven": true
  }
] as const;

// --- Menu.draft ---
export interface MenuDraftClientInput {
  name: string;
  description?: string;
  category?: string;
  isTemplate?: boolean;
  /** Bounds: 0..∞ */
  basePrice?: number;
  /** Bounds: 0..∞ */
  pricePerPerson?: number;
  /** Bounds: 0..∞ */
  minGuests?: number;
  /** Bounds: 0..∞ */
  maxGuests?: number;
}

export const MenuDraftCapability = {
  capabilityId: "Menu.draft",
  entity: "Menu",
  command: "draft",
  route: "/api/manifest/Menu/commands/draft",
  instanceCommand: true,
  clientParameterNames: ["name","description","category","isTemplate","basePrice","pricePerPerson","minGuests","maxGuests"],
  serverParameterNames: [],
  emits: ["MenuDrafted"],
} as const;

/**
 * Build command input for Menu.draft.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuDraftInput(client: MenuDraftClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Menu.draft. */
export const MenuDraftInvalidation = [
  {
    "kind": "entityList",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Menu.markPublished ---
export type MenuMarkPublishedClientInput = Record<string, never>;

export const MenuMarkPublishedCapability = {
  capabilityId: "Menu.markPublished",
  entity: "Menu",
  command: "markPublished",
  route: "/api/manifest/Menu/commands/markPublished",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["MenuPublished"],
} as const;

/**
 * Build command input for Menu.markPublished.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuMarkPublishedInput(client: MenuMarkPublishedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Menu.markPublished. */
export const MenuMarkPublishedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Menu.markPublished. */
export const MenuMarkPublishedLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "published",
    "proven": true
  }
] as const;

// --- Menu.restore ---
export type MenuRestoreClientInput = Record<string, never>;

export const MenuRestoreCapability = {
  capabilityId: "Menu.restore",
  entity: "Menu",
  command: "restore",
  route: "/api/manifest/Menu/commands/restore",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["MenuRestored"],
} as const;

/**
 * Build command input for Menu.restore.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuRestoreInput(client: MenuRestoreClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Menu.restore. */
export const MenuRestoreInvalidation = [
  {
    "kind": "entityList",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Menu.restore. */
export const MenuRestoreLifecycle = [
  {
    "property": "status",
    "from": "published",
    "to": "draft",
    "proven": true
  },
  {
    "property": "status",
    "from": "archived",
    "to": "draft",
    "proven": true
  }
] as const;

// --- Menu.reviseDetails ---
export interface MenuReviseDetailsClientInput {
  name: string;
  description?: string;
  category?: string;
  isTemplate?: boolean;
}

export const MenuReviseDetailsCapability = {
  capabilityId: "Menu.reviseDetails",
  entity: "Menu",
  command: "reviseDetails",
  route: "/api/manifest/Menu/commands/reviseDetails",
  instanceCommand: true,
  clientParameterNames: ["name","description","category","isTemplate"],
  serverParameterNames: [],
  emits: ["MenuDetailsRevised"],
} as const;

/**
 * Build command input for Menu.reviseDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuReviseDetailsInput(client: MenuReviseDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Menu.reviseDetails. */
export const MenuReviseDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Menu.unpublish ---
export interface MenuUnpublishClientInput {
  reason: string;
}

export const MenuUnpublishCapability = {
  capabilityId: "Menu.unpublish",
  entity: "Menu",
  command: "unpublish",
  route: "/api/manifest/Menu/commands/unpublish",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["MenuUnpublished"],
} as const;

/**
 * Build command input for Menu.unpublish.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuUnpublishInput(client: MenuUnpublishClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Menu.unpublish. */
export const MenuUnpublishInvalidation = [
  {
    "kind": "entityList",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Menu.unpublish. */
export const MenuUnpublishLifecycle = [
  {
    "property": "status",
    "from": "published",
    "to": "draft",
    "proven": true
  },
  {
    "property": "status",
    "from": "archived",
    "to": "draft",
    "proven": true
  }
] as const;

// --- Menu.updatePricing ---
export interface MenuUpdatePricingClientInput {
  /** Bounds: 0..∞ */
  basePrice: number;
  /** Bounds: 0..∞ */
  pricePerPerson: number;
  /** Bounds: 0..∞ */
  minGuests: number;
  /** Bounds: 0..∞ */
  maxGuests: number;
}

export const MenuUpdatePricingCapability = {
  capabilityId: "Menu.updatePricing",
  entity: "Menu",
  command: "updatePricing",
  route: "/api/manifest/Menu/commands/updatePricing",
  instanceCommand: true,
  clientParameterNames: ["basePrice","pricePerPerson","minGuests","maxGuests"],
  serverParameterNames: [],
  emits: ["MenuPricingUpdated"],
} as const;

/**
 * Build command input for Menu.updatePricing.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuUpdatePricingInput(client: MenuUpdatePricingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Menu.updatePricing. */
export const MenuUpdatePricingInvalidation = [
  {
    "kind": "entityList",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Menu",
    "queryKeyHint": "queryKeys.menu.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- MenuDish.add ---
export interface MenuDishAddClientInput {
  menuId: string;
  dishId: string;
  sortOrder?: number;
  /** Bounds: 0..∞ */
  sellingPrice?: number;
  course?: string;
  serviceStyle?: string;
  specialInstructions?: string;
}

export const MenuDishAddCapability = {
  capabilityId: "MenuDish.add",
  entity: "MenuDish",
  command: "add",
  route: "/api/manifest/MenuDish/commands/add",
  instanceCommand: true,
  clientParameterNames: ["menuId","dishId","sortOrder","sellingPrice","course","serviceStyle","specialInstructions"],
  serverParameterNames: [],
  emits: ["MenuDishAdded"],
} as const;

/**
 * Build command input for MenuDish.add.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuDishAddInput(client: MenuDishAddClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful MenuDish.add. */
export const MenuDishAddInvalidation = [
  {
    "kind": "entityList",
    "entity": "MenuDish",
    "queryKeyHint": "queryKeys.menuDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "MenuDish",
    "queryKeyHint": "queryKeys.menuDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- MenuDish.remove ---
export interface MenuDishRemoveClientInput {
  reason: string;
}

export const MenuDishRemoveCapability = {
  capabilityId: "MenuDish.remove",
  entity: "MenuDish",
  command: "remove",
  route: "/api/manifest/MenuDish/commands/remove",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["MenuDishRemoved"],
} as const;

/**
 * Build command input for MenuDish.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuDishRemoveInput(client: MenuDishRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful MenuDish.remove. */
export const MenuDishRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "MenuDish",
    "queryKeyHint": "queryKeys.menuDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "MenuDish",
    "queryKeyHint": "queryKeys.menuDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- MenuDish.updateDetails ---
export interface MenuDishUpdateDetailsClientInput {
  sortOrder?: number;
  course?: string;
  serviceStyle?: string;
  specialInstructions?: string;
}

export const MenuDishUpdateDetailsCapability = {
  capabilityId: "MenuDish.updateDetails",
  entity: "MenuDish",
  command: "updateDetails",
  route: "/api/manifest/MenuDish/commands/updateDetails",
  instanceCommand: true,
  clientParameterNames: ["sortOrder","course","serviceStyle","specialInstructions"],
  serverParameterNames: [],
  emits: ["MenuDishDetailsUpdated"],
} as const;

/**
 * Build command input for MenuDish.updateDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuDishUpdateDetailsInput(client: MenuDishUpdateDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful MenuDish.updateDetails. */
export const MenuDishUpdateDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "MenuDish",
    "queryKeyHint": "queryKeys.menuDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "MenuDish",
    "queryKeyHint": "queryKeys.menuDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- MenuDish.updateSellingPrice ---
export interface MenuDishUpdateSellingPriceClientInput {
  /** Bounds: 0..∞ */
  sellingPrice: number;
}

export const MenuDishUpdateSellingPriceCapability = {
  capabilityId: "MenuDish.updateSellingPrice",
  entity: "MenuDish",
  command: "updateSellingPrice",
  route: "/api/manifest/MenuDish/commands/updateSellingPrice",
  instanceCommand: true,
  clientParameterNames: ["sellingPrice"],
  serverParameterNames: [],
  emits: ["MenuDishSellingPriceUpdated"],
} as const;

/**
 * Build command input for MenuDish.updateSellingPrice.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindMenuDishUpdateSellingPriceInput(client: MenuDishUpdateSellingPriceClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful MenuDish.updateSellingPrice. */
export const MenuDishUpdateSellingPriceInvalidation = [
  {
    "kind": "entityList",
    "entity": "MenuDish",
    "queryKeyHint": "queryKeys.menuDish.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "MenuDish",
    "queryKeyHint": "queryKeys.menuDish.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Organization.configureBranding ---
export interface OrganizationConfigureBrandingClientInput {
  displayName: string;
  address: string;
  primaryColor: string;
  accentColor: string;
}

export const OrganizationConfigureBrandingCapability = {
  capabilityId: "Organization.configureBranding",
  entity: "Organization",
  command: "configureBranding",
  route: "/api/manifest/Organization/commands/configureBranding",
  instanceCommand: true,
  clientParameterNames: ["displayName","address","primaryColor","accentColor"],
  serverParameterNames: [],
  emits: ["OrganizationBrandingConfigured"],
} as const;

/**
 * Build command input for Organization.configureBranding.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindOrganizationConfigureBrandingInput(client: OrganizationConfigureBrandingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Organization.configureBranding. */
export const OrganizationConfigureBrandingInvalidation = [
  {
    "kind": "entityList",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Organization.deactivate ---
export type OrganizationDeactivateClientInput = Record<string, never>;

export const OrganizationDeactivateCapability = {
  capabilityId: "Organization.deactivate",
  entity: "Organization",
  command: "deactivate",
  route: "/api/manifest/Organization/commands/deactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["OrganizationDeactivated"],
} as const;

/**
 * Build command input for Organization.deactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindOrganizationDeactivateInput(client: OrganizationDeactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Organization.deactivate. */
export const OrganizationDeactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Organization.deactivate. */
export const OrganizationDeactivateLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "deactivated",
    "proven": true
  },
  {
    "property": "status",
    "from": "suspended",
    "to": "deactivated",
    "proven": true
  }
] as const;

// --- Organization.reactivate ---
export type OrganizationReactivateClientInput = Record<string, never>;

export const OrganizationReactivateCapability = {
  capabilityId: "Organization.reactivate",
  entity: "Organization",
  command: "reactivate",
  route: "/api/manifest/Organization/commands/reactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["OrganizationReactivated"],
} as const;

/**
 * Build command input for Organization.reactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindOrganizationReactivateInput(client: OrganizationReactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Organization.reactivate. */
export const OrganizationReactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Organization.reactivate. */
export const OrganizationReactivateLifecycle = [
  {
    "property": "status",
    "from": "suspended",
    "to": "active",
    "proven": true
  }
] as const;

// --- Organization.register ---
export interface OrganizationRegisterClientInput {
  name: string;
  brandDisplayName?: string;
  brandAddress?: string;
  brandPrimaryColor?: string;
  brandAccentColor?: string;
}

export const OrganizationRegisterCapability = {
  capabilityId: "Organization.register",
  entity: "Organization",
  command: "register",
  route: "/api/manifest/Organization/commands/register",
  instanceCommand: true,
  clientParameterNames: ["name","brandDisplayName","brandAddress","brandPrimaryColor","brandAccentColor"],
  serverParameterNames: [],
  emits: ["OrganizationRegistered"],
} as const;

/**
 * Build command input for Organization.register.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindOrganizationRegisterInput(client: OrganizationRegisterClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Organization.register. */
export const OrganizationRegisterInvalidation = [
  {
    "kind": "entityList",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Organization.rename ---
export interface OrganizationRenameClientInput {
  name: string;
}

export const OrganizationRenameCapability = {
  capabilityId: "Organization.rename",
  entity: "Organization",
  command: "rename",
  route: "/api/manifest/Organization/commands/rename",
  instanceCommand: true,
  clientParameterNames: ["name"],
  serverParameterNames: [],
  emits: ["OrganizationRenamed"],
} as const;

/**
 * Build command input for Organization.rename.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindOrganizationRenameInput(client: OrganizationRenameClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Organization.rename. */
export const OrganizationRenameInvalidation = [
  {
    "kind": "entityList",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Organization.suspend ---
export interface OrganizationSuspendClientInput {
  reason?: string;
}

export const OrganizationSuspendCapability = {
  capabilityId: "Organization.suspend",
  entity: "Organization",
  command: "suspend",
  route: "/api/manifest/Organization/commands/suspend",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["OrganizationSuspended"],
} as const;

/**
 * Build command input for Organization.suspend.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindOrganizationSuspendInput(client: OrganizationSuspendClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Organization.suspend. */
export const OrganizationSuspendInvalidation = [
  {
    "kind": "entityList",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Organization",
    "queryKeyHint": "queryKeys.organization.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Organization.suspend. */
export const OrganizationSuspendLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "suspended",
    "proven": true
  }
] as const;

// --- OrganizationCapabilitySetting.register ---
export interface OrganizationCapabilitySettingRegisterClientInput {
  /** Allowed: "kitchen" | "inventory" | "procurement" | "events" | "sales" | "logistics" | "workforce" | "finance" | "reports" | "administration" */
  capability: "kitchen" | "inventory" | "procurement" | "events" | "sales" | "logistics" | "workforce" | "finance" | "reports" | "administration";
  enabled: boolean;
  updatedBy?: string;
}

export const OrganizationCapabilitySettingRegisterCapability = {
  capabilityId: "OrganizationCapabilitySetting.register",
  entity: "OrganizationCapabilitySetting",
  command: "register",
  route: "/api/manifest/OrganizationCapabilitySetting/commands/register",
  instanceCommand: true,
  clientParameterNames: ["capability","enabled","updatedBy"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for OrganizationCapabilitySetting.register.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindOrganizationCapabilitySettingRegisterInput(client: OrganizationCapabilitySettingRegisterClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful OrganizationCapabilitySetting.register. */
export const OrganizationCapabilitySettingRegisterInvalidation = [
  {
    "kind": "entityList",
    "entity": "OrganizationCapabilitySetting",
    "queryKeyHint": "queryKeys.organizationCapabilitySetting.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "OrganizationCapabilitySetting",
    "queryKeyHint": "queryKeys.organizationCapabilitySetting.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- OrganizationCapabilitySetting.setEnabled ---
export interface OrganizationCapabilitySettingSetEnabledClientInput {
  enabled: boolean;
  updatedBy?: string;
}

export const OrganizationCapabilitySettingSetEnabledCapability = {
  capabilityId: "OrganizationCapabilitySetting.setEnabled",
  entity: "OrganizationCapabilitySetting",
  command: "setEnabled",
  route: "/api/manifest/OrganizationCapabilitySetting/commands/setEnabled",
  instanceCommand: true,
  clientParameterNames: ["enabled","updatedBy"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for OrganizationCapabilitySetting.setEnabled.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindOrganizationCapabilitySettingSetEnabledInput(client: OrganizationCapabilitySettingSetEnabledClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful OrganizationCapabilitySetting.setEnabled. */
export const OrganizationCapabilitySettingSetEnabledInvalidation = [
  {
    "kind": "entityList",
    "entity": "OrganizationCapabilitySetting",
    "queryKeyHint": "queryKeys.organizationCapabilitySetting.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "OrganizationCapabilitySetting",
    "queryKeyHint": "queryKeys.organizationCapabilitySetting.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PackList.cancel ---
export interface PackListCancelClientInput {
  reason: string;
}

export const PackListCancelCapability = {
  capabilityId: "PackList.cancel",
  entity: "PackList",
  command: "cancel",
  route: "/api/manifest/PackList/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PackListCancelled"],
} as const;

/**
 * Build command input for PackList.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListCancelInput(client: PackListCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackList.cancel. */
export const PackListCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PackList.cancel. */
export const PackListCancelLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "packing",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "packed",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "loaded",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- PackList.dispatch ---
export type PackListDispatchClientInput = Record<string, never>;

export const PackListDispatchCapability = {
  capabilityId: "PackList.dispatch",
  entity: "PackList",
  command: "dispatch",
  route: "/api/manifest/PackList/commands/dispatch",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PackListDispatched"],
} as const;

/**
 * Build command input for PackList.dispatch.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListDispatchInput(client: PackListDispatchClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackList.dispatch. */
export const PackListDispatchInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PackList.dispatch. */
export const PackListDispatchLifecycle = [
  {
    "property": "status",
    "from": "loaded",
    "to": "dispatched",
    "proven": true
  }
] as const;

// --- PackList.markLoaded ---
export type PackListMarkLoadedClientInput = Record<string, never>;

export const PackListMarkLoadedCapability = {
  capabilityId: "PackList.markLoaded",
  entity: "PackList",
  command: "markLoaded",
  route: "/api/manifest/PackList/commands/markLoaded",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PackListLoaded"],
} as const;

/**
 * Build command input for PackList.markLoaded.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListMarkLoadedInput(client: PackListMarkLoadedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackList.markLoaded. */
export const PackListMarkLoadedInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PackList.markLoaded. */
export const PackListMarkLoadedLifecycle = [
  {
    "property": "status",
    "from": "packed",
    "to": "loaded",
    "proven": true
  }
] as const;

// --- PackList.markPacked ---
export type PackListMarkPackedClientInput = Record<string, never>;

export const PackListMarkPackedCapability = {
  capabilityId: "PackList.markPacked",
  entity: "PackList",
  command: "markPacked",
  route: "/api/manifest/PackList/commands/markPacked",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PackListPacked"],
} as const;

/**
 * Build command input for PackList.markPacked.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListMarkPackedInput(client: PackListMarkPackedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackList.markPacked. */
export const PackListMarkPackedInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PackList.markPacked. */
export const PackListMarkPackedLifecycle = [
  {
    "property": "status",
    "from": "packing",
    "to": "packed",
    "proven": true
  }
] as const;

// --- PackList.open ---
export interface PackListOpenClientInput {
  eventId: string;
  name: string;
  purpose?: string;
  notes?: string;
}

export const PackListOpenCapability = {
  capabilityId: "PackList.open",
  entity: "PackList",
  command: "open",
  route: "/api/manifest/PackList/commands/open",
  instanceCommand: true,
  clientParameterNames: ["eventId","name","purpose","notes"],
  serverParameterNames: [],
  emits: ["PackListOpened"],
} as const;

/**
 * Build command input for PackList.open.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListOpenInput(client: PackListOpenClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackList.open. */
export const PackListOpenInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PackList.startPacking ---
export type PackListStartPackingClientInput = Record<string, never>;

export const PackListStartPackingCapability = {
  capabilityId: "PackList.startPacking",
  entity: "PackList",
  command: "startPacking",
  route: "/api/manifest/PackList/commands/startPacking",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PackListPackingStarted"],
} as const;

/**
 * Build command input for PackList.startPacking.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListStartPackingInput(client: PackListStartPackingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackList.startPacking. */
export const PackListStartPackingInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackList",
    "queryKeyHint": "queryKeys.packList.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PackList.startPacking. */
export const PackListStartPackingLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "packing",
    "proven": true
  }
] as const;

// --- PackListItem.addItem ---
export interface PackListItemAddItemClientInput {
  packListId: string;
  description: string;
  /** Bounds: 1..∞ */
  requiredQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  dishId?: string;
  productionBatchId?: string;
}

export const PackListItemAddItemCapability = {
  capabilityId: "PackListItem.addItem",
  entity: "PackListItem",
  command: "addItem",
  route: "/api/manifest/PackListItem/commands/addItem",
  instanceCommand: true,
  clientParameterNames: ["packListId","description","requiredQuantity","unit","dishId","productionBatchId"],
  serverParameterNames: [],
  emits: ["PackListItemAdded"],
} as const;

/**
 * Build command input for PackListItem.addItem.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListItemAddItemInput(client: PackListItemAddItemClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackListItem.addItem. */
export const PackListItemAddItemInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackListItem",
    "queryKeyHint": "queryKeys.packListItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackListItem",
    "queryKeyHint": "queryKeys.packListItem.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PackListItem.addItem. */
export const PackListItemAddItemLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "listed",
    "proven": true
  }
] as const;

// --- PackListItem.adjustQuantity ---
export interface PackListItemAdjustQuantityClientInput {
  /** Bounds: 1..∞ */
  requiredQuantity: number;
}

export const PackListItemAdjustQuantityCapability = {
  capabilityId: "PackListItem.adjustQuantity",
  entity: "PackListItem",
  command: "adjustQuantity",
  route: "/api/manifest/PackListItem/commands/adjustQuantity",
  instanceCommand: true,
  clientParameterNames: ["requiredQuantity"],
  serverParameterNames: [],
  emits: ["PackListItemQuantityAdjusted"],
} as const;

/**
 * Build command input for PackListItem.adjustQuantity.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListItemAdjustQuantityInput(client: PackListItemAdjustQuantityClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackListItem.adjustQuantity. */
export const PackListItemAdjustQuantityInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackListItem",
    "queryKeyHint": "queryKeys.packListItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackListItem",
    "queryKeyHint": "queryKeys.packListItem.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PackListItem.markMissing ---
export type PackListItemMarkMissingClientInput = Record<string, never>;

export const PackListItemMarkMissingCapability = {
  capabilityId: "PackListItem.markMissing",
  entity: "PackListItem",
  command: "markMissing",
  route: "/api/manifest/PackListItem/commands/markMissing",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PackListItemMissing"],
} as const;

/**
 * Build command input for PackListItem.markMissing.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListItemMarkMissingInput(client: PackListItemMarkMissingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackListItem.markMissing. */
export const PackListItemMarkMissingInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackListItem",
    "queryKeyHint": "queryKeys.packListItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackListItem",
    "queryKeyHint": "queryKeys.packListItem.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PackListItem.markMissing. */
export const PackListItemMarkMissingLifecycle = [
  {
    "property": "status",
    "from": "listed",
    "to": "missing",
    "proven": true
  }
] as const;

// --- PackListItem.markPacked ---
export interface PackListItemMarkPackedClientInput {
  /** Bounds: 1..∞ */
  packedQuantity: number;
}

export const PackListItemMarkPackedCapability = {
  capabilityId: "PackListItem.markPacked",
  entity: "PackListItem",
  command: "markPacked",
  route: "/api/manifest/PackListItem/commands/markPacked",
  instanceCommand: true,
  clientParameterNames: ["packedQuantity"],
  serverParameterNames: [],
  emits: ["PackListItemPacked"],
} as const;

/**
 * Build command input for PackListItem.markPacked.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPackListItemMarkPackedInput(client: PackListItemMarkPackedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PackListItem.markPacked. */
export const PackListItemMarkPackedInvalidation = [
  {
    "kind": "entityList",
    "entity": "PackListItem",
    "queryKeyHint": "queryKeys.packListItem.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PackListItem",
    "queryKeyHint": "queryKeys.packListItem.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PackListItem.markPacked. */
export const PackListItemMarkPackedLifecycle = [
  {
    "property": "status",
    "from": "listed",
    "to": "packed",
    "proven": true
  }
] as const;

// --- Payment.beginProcessing ---
export type PaymentBeginProcessingClientInput = Record<string, never>;

export const PaymentBeginProcessingCapability = {
  capabilityId: "Payment.beginProcessing",
  entity: "Payment",
  command: "beginProcessing",
  route: "/api/manifest/Payment/commands/beginProcessing",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentProcessingStarted"],
} as const;

/**
 * Build command input for Payment.beginProcessing.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentBeginProcessingInput(client: PaymentBeginProcessingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Payment.beginProcessing. */
export const PaymentBeginProcessingInvalidation = [
  {
    "kind": "entityList",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Payment.beginProcessing. */
export const PaymentBeginProcessingLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "processing",
    "proven": true
  }
] as const;

// --- Payment.fail ---
export interface PaymentFailClientInput {
  reason: string;
}

export const PaymentFailCapability = {
  capabilityId: "Payment.fail",
  entity: "Payment",
  command: "fail",
  route: "/api/manifest/Payment/commands/fail",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PaymentFailed"],
} as const;

/**
 * Build command input for Payment.fail.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentFailInput(client: PaymentFailClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Payment.fail. */
export const PaymentFailInvalidation = [
  {
    "kind": "entityList",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Payment.fail. */
export const PaymentFailLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "failed",
    "proven": true
  },
  {
    "property": "status",
    "from": "processing",
    "to": "failed",
    "proven": true
  }
] as const;

// --- Payment.reassignClient ---
export type PaymentReassignClientClientInput = Record<string, never>;

export const PaymentReassignClientCapability = {
  capabilityId: "Payment.reassignClient",
  entity: "Payment",
  command: "reassignClient",
  route: "/api/manifest/Payment/commands/reassignClient",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentClientReassigned"],
} as const;

/**
 * Build command input for Payment.reassignClient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentReassignClientInput(client: PaymentReassignClientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Payment.reassignClient. */
export const PaymentReassignClientInvalidation = [
  {
    "kind": "entityList",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Payment.record ---
export interface PaymentRecordClientInput {
  invoiceId: string;
  clientId: string;
  /** Bounds: 1..∞ */
  amount: number;
  /** Allowed: "card" | "check" | "cash" | "ach" | "other" */
  method: "card" | "check" | "cash" | "ach" | "other";
  eventId?: string;
  paymentMethodId?: string;
  notes?: string;
}

export const PaymentRecordCapability = {
  capabilityId: "Payment.record",
  entity: "Payment",
  command: "record",
  route: "/api/manifest/Payment/commands/record",
  instanceCommand: true,
  clientParameterNames: ["invoiceId","clientId","amount","method","eventId","paymentMethodId","notes"],
  serverParameterNames: [],
  emits: ["PaymentRecorded"],
} as const;

/**
 * Build command input for Payment.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentRecordInput(client: PaymentRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Payment.record. */
export const PaymentRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Payment.refund ---
export interface PaymentRefundClientInput {
  reason: string;
}

export const PaymentRefundCapability = {
  capabilityId: "Payment.refund",
  entity: "Payment",
  command: "refund",
  route: "/api/manifest/Payment/commands/refund",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PaymentRefunded"],
} as const;

/**
 * Build command input for Payment.refund.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentRefundInput(client: PaymentRefundClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Payment.refund. */
export const PaymentRefundInvalidation = [
  {
    "kind": "entityList",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Payment.refund. */
export const PaymentRefundLifecycle = [
  {
    "property": "status",
    "from": "completed",
    "to": "refunded",
    "proven": true
  }
] as const;

// --- Payment.settle ---
export type PaymentSettleClientInput = Record<string, never>;

export const PaymentSettleCapability = {
  capabilityId: "Payment.settle",
  entity: "Payment",
  command: "settle",
  route: "/api/manifest/Payment/commands/settle",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentSettled"],
} as const;

/**
 * Build command input for Payment.settle.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentSettleInput(client: PaymentSettleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Payment.settle. */
export const PaymentSettleInvalidation = [
  {
    "kind": "entityList",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Payment.settle. */
export const PaymentSettleLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "completed",
    "proven": true
  },
  {
    "property": "status",
    "from": "processing",
    "to": "completed",
    "proven": true
  }
] as const;

// --- Payment.stageClientMerge ---
export interface PaymentStageClientMergeClientInput {
  clientMergeId: string;
  clientId: string;
}

export const PaymentStageClientMergeCapability = {
  capabilityId: "Payment.stageClientMerge",
  entity: "Payment",
  command: "stageClientMerge",
  route: "/api/manifest/Payment/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","clientId"],
  serverParameterNames: [],
  emits: ["PaymentClientMergeStaged"],
} as const;

/**
 * Build command input for Payment.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentStageClientMergeInput(client: PaymentStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Payment.stageClientMerge. */
export const PaymentStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Payment",
    "queryKeyHint": "queryKeys.payment.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PaymentMethod.clearDefault ---
export type PaymentMethodClearDefaultClientInput = Record<string, never>;

export const PaymentMethodClearDefaultCapability = {
  capabilityId: "PaymentMethod.clearDefault",
  entity: "PaymentMethod",
  command: "clearDefault",
  route: "/api/manifest/PaymentMethod/commands/clearDefault",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentMethodDefaultCleared"],
} as const;

/**
 * Build command input for PaymentMethod.clearDefault.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodClearDefaultInput(client: PaymentMethodClearDefaultClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.clearDefault. */
export const PaymentMethodClearDefaultInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PaymentMethod.expire ---
export type PaymentMethodExpireClientInput = Record<string, never>;

export const PaymentMethodExpireCapability = {
  capabilityId: "PaymentMethod.expire",
  entity: "PaymentMethod",
  command: "expire",
  route: "/api/manifest/PaymentMethod/commands/expire",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentMethodExpired"],
} as const;

/**
 * Build command input for PaymentMethod.expire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodExpireInput(client: PaymentMethodExpireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.expire. */
export const PaymentMethodExpireInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PaymentMethod.expire. */
export const PaymentMethodExpireLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "expired",
    "proven": true
  }
] as const;

// --- PaymentMethod.invalidate ---
export interface PaymentMethodInvalidateClientInput {
  reason: string;
}

export const PaymentMethodInvalidateCapability = {
  capabilityId: "PaymentMethod.invalidate",
  entity: "PaymentMethod",
  command: "invalidate",
  route: "/api/manifest/PaymentMethod/commands/invalidate",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PaymentMethodInvalidated"],
} as const;

/**
 * Build command input for PaymentMethod.invalidate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodInvalidateInput(client: PaymentMethodInvalidateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.invalidate. */
export const PaymentMethodInvalidateInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PaymentMethod.invalidate. */
export const PaymentMethodInvalidateLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "invalid",
    "proven": true
  }
] as const;

// --- PaymentMethod.makeDefault ---
export type PaymentMethodMakeDefaultClientInput = Record<string, never>;

export const PaymentMethodMakeDefaultCapability = {
  capabilityId: "PaymentMethod.makeDefault",
  entity: "PaymentMethod",
  command: "makeDefault",
  route: "/api/manifest/PaymentMethod/commands/makeDefault",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentMethodDefaultSet"],
} as const;

/**
 * Build command input for PaymentMethod.makeDefault.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodMakeDefaultInput(client: PaymentMethodMakeDefaultClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.makeDefault. */
export const PaymentMethodMakeDefaultInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PaymentMethod.reactivate ---
export type PaymentMethodReactivateClientInput = Record<string, never>;

export const PaymentMethodReactivateCapability = {
  capabilityId: "PaymentMethod.reactivate",
  entity: "PaymentMethod",
  command: "reactivate",
  route: "/api/manifest/PaymentMethod/commands/reactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentMethodReactivated"],
} as const;

/**
 * Build command input for PaymentMethod.reactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodReactivateInput(client: PaymentMethodReactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.reactivate. */
export const PaymentMethodReactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PaymentMethod.reactivate. */
export const PaymentMethodReactivateLifecycle = [
  {
    "property": "status",
    "from": "expired",
    "to": "active",
    "proven": true
  }
] as const;

// --- PaymentMethod.reassignClient ---
export type PaymentMethodReassignClientClientInput = Record<string, never>;

export const PaymentMethodReassignClientCapability = {
  capabilityId: "PaymentMethod.reassignClient",
  entity: "PaymentMethod",
  command: "reassignClient",
  route: "/api/manifest/PaymentMethod/commands/reassignClient",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentMethodClientReassigned"],
} as const;

/**
 * Build command input for PaymentMethod.reassignClient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodReassignClientInput(client: PaymentMethodReassignClientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.reassignClient. */
export const PaymentMethodReassignClientInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PaymentMethod.register ---
export interface PaymentMethodRegisterClientInput {
  clientId: string;
  /** Allowed: "card" | "check" | "cash" | "ach" | "other" */
  methodType: "card" | "check" | "cash" | "ach" | "other";
  provider?: string;
  lastFour?: string;
  isDefault?: boolean;
  notes?: string;
}

export const PaymentMethodRegisterCapability = {
  capabilityId: "PaymentMethod.register",
  entity: "PaymentMethod",
  command: "register",
  route: "/api/manifest/PaymentMethod/commands/register",
  instanceCommand: true,
  clientParameterNames: ["clientId","methodType","provider","lastFour","isDefault","notes"],
  serverParameterNames: [],
  emits: ["PaymentMethodRegistered"],
} as const;

/**
 * Build command input for PaymentMethod.register.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodRegisterInput(client: PaymentMethodRegisterClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.register. */
export const PaymentMethodRegisterInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PaymentMethod.remove ---
export type PaymentMethodRemoveClientInput = Record<string, never>;

export const PaymentMethodRemoveCapability = {
  capabilityId: "PaymentMethod.remove",
  entity: "PaymentMethod",
  command: "remove",
  route: "/api/manifest/PaymentMethod/commands/remove",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PaymentMethodRemoved"],
} as const;

/**
 * Build command input for PaymentMethod.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodRemoveInput(client: PaymentMethodRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.remove. */
export const PaymentMethodRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PaymentMethod.remove. */
export const PaymentMethodRemoveLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "removed",
    "proven": true
  }
] as const;

// --- PaymentMethod.stageClientMerge ---
export interface PaymentMethodStageClientMergeClientInput {
  clientMergeId: string;
  clientId: string;
}

export const PaymentMethodStageClientMergeCapability = {
  capabilityId: "PaymentMethod.stageClientMerge",
  entity: "PaymentMethod",
  command: "stageClientMerge",
  route: "/api/manifest/PaymentMethod/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","clientId"],
  serverParameterNames: [],
  emits: ["PaymentMethodClientMergeStaged"],
} as const;

/**
 * Build command input for PaymentMethod.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPaymentMethodStageClientMergeInput(client: PaymentMethodStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PaymentMethod.stageClientMerge. */
export const PaymentMethodStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PaymentMethod",
    "queryKeyHint": "queryKeys.paymentMethod.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PayrollInput.finalize ---
export type PayrollInputFinalizeClientInput = Record<string, never>;

export const PayrollInputFinalizeCapability = {
  capabilityId: "PayrollInput.finalize",
  entity: "PayrollInput",
  command: "finalize",
  route: "/api/manifest/PayrollInput/commands/finalize",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PayrollInputFinalized"],
} as const;

/**
 * Build command input for PayrollInput.finalize.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPayrollInputFinalizeInput(client: PayrollInputFinalizeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PayrollInput.finalize. */
export const PayrollInputFinalizeInvalidation = [
  {
    "kind": "entityList",
    "entity": "PayrollInput",
    "queryKeyHint": "queryKeys.payrollInput.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PayrollInput",
    "queryKeyHint": "queryKeys.payrollInput.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PayrollInput.finalize. */
export const PayrollInputFinalizeLifecycle = [
  {
    "property": "status",
    "from": "prepared",
    "to": "finalized",
    "proven": true
  }
] as const;

// --- PayrollInput.markVoided ---
export interface PayrollInputMarkVoidedClientInput {
  reason: string;
}

export const PayrollInputMarkVoidedCapability = {
  capabilityId: "PayrollInput.markVoided",
  entity: "PayrollInput",
  command: "markVoided",
  route: "/api/manifest/PayrollInput/commands/markVoided",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PayrollInputVoided"],
} as const;

/**
 * Build command input for PayrollInput.markVoided.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPayrollInputMarkVoidedInput(client: PayrollInputMarkVoidedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PayrollInput.markVoided. */
export const PayrollInputMarkVoidedInvalidation = [
  {
    "kind": "entityList",
    "entity": "PayrollInput",
    "queryKeyHint": "queryKeys.payrollInput.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PayrollInput",
    "queryKeyHint": "queryKeys.payrollInput.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PayrollInput.markVoided. */
export const PayrollInputMarkVoidedLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "voided",
    "proven": true
  },
  {
    "property": "status",
    "from": "prepared",
    "to": "voided",
    "proven": true
  },
  {
    "property": "status",
    "from": "finalized",
    "to": "voided",
    "proven": true
  }
] as const;

// --- PayrollInput.prepare ---
export interface PayrollInputPrepareClientInput {
  personId: string;
  /** Must not be "". */
  periodStart: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  periodEnd: string & { readonly __nonEmpty?: true };
  /** Bounds: 0..∞ */
  regularMinutes: number;
  /** Bounds: 0..∞ */
  overtimeMinutes: number;
  /** Bounds: 0..∞ */
  totalMinutes: number;
  eventId?: string;
  shiftId?: string;
  /** Bounds: 0..∞ */
  hourlyRate?: number;
  /** Bounds: 0..∞ */
  overtimeRate?: number;
  /** Bounds: 0..∞ */
  grossAmount?: number;
  notes?: string;
}

export const PayrollInputPrepareCapability = {
  capabilityId: "PayrollInput.prepare",
  entity: "PayrollInput",
  command: "prepare",
  route: "/api/manifest/PayrollInput/commands/prepare",
  instanceCommand: true,
  clientParameterNames: ["personId","periodStart","periodEnd","regularMinutes","overtimeMinutes","totalMinutes","eventId","shiftId","hourlyRate","overtimeRate","grossAmount","notes"],
  serverParameterNames: [],
  emits: ["PayrollInputPrepared"],
} as const;

/**
 * Build command input for PayrollInput.prepare.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPayrollInputPrepareInput(client: PayrollInputPrepareClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PayrollInput.prepare. */
export const PayrollInputPrepareInvalidation = [
  {
    "kind": "entityList",
    "entity": "PayrollInput",
    "queryKeyHint": "queryKeys.payrollInput.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PayrollInput",
    "queryKeyHint": "queryKeys.payrollInput.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PayrollInput.prepare. */
export const PayrollInputPrepareLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "prepared",
    "proven": true
  }
] as const;

// --- Person.assignRole ---
export interface PersonAssignRoleClientInput {
  /** Allowed: "staff" | "kitchen_staff" | "kitchen_lead" | "sales_staff" | "event_staff" | "inventory_staff" | "procurement_staff" | "logistics_staff" | "driver" | "workforce_staff" | "finance_staff" | "manager" | "kitchen_manager" | "sales_manager" | "event_manager" | "inventory_manager" | "logistics_manager" | "workforce_manager" | "finance_manager" | "admin" | "owner" | "system" */
  role: "staff" | "kitchen_staff" | "kitchen_lead" | "sales_staff" | "event_staff" | "inventory_staff" | "procurement_staff" | "logistics_staff" | "driver" | "workforce_staff" | "finance_staff" | "manager" | "kitchen_manager" | "sales_manager" | "event_manager" | "inventory_manager" | "logistics_manager" | "workforce_manager" | "finance_manager" | "admin" | "owner" | "system";
}

export const PersonAssignRoleCapability = {
  capabilityId: "Person.assignRole",
  entity: "Person",
  command: "assignRole",
  route: "/api/manifest/Person/commands/assignRole",
  instanceCommand: true,
  clientParameterNames: ["role"],
  serverParameterNames: [],
  emits: ["PersonRoleAssigned"],
} as const;

/**
 * Build command input for Person.assignRole.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPersonAssignRoleInput(client: PersonAssignRoleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Person.assignRole. */
export const PersonAssignRoleInvalidation = [
  {
    "kind": "entityList",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Person.correctIdentity ---
export interface PersonCorrectIdentityClientInput {
  givenName: string;
  familyName: string;
  phone?: string;
}

export const PersonCorrectIdentityCapability = {
  capabilityId: "Person.correctIdentity",
  entity: "Person",
  command: "correctIdentity",
  route: "/api/manifest/Person/commands/correctIdentity",
  instanceCommand: true,
  clientParameterNames: ["givenName","familyName","phone"],
  serverParameterNames: [],
  emits: ["PersonIdentityCorrected"],
} as const;

/**
 * Build command input for Person.correctIdentity.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPersonCorrectIdentityInput(client: PersonCorrectIdentityClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Person.correctIdentity. */
export const PersonCorrectIdentityInvalidation = [
  {
    "kind": "entityList",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Person.deactivate ---
export type PersonDeactivateClientInput = Record<string, never>;

export const PersonDeactivateCapability = {
  capabilityId: "Person.deactivate",
  entity: "Person",
  command: "deactivate",
  route: "/api/manifest/Person/commands/deactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PersonDeactivated"],
} as const;

/**
 * Build command input for Person.deactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPersonDeactivateInput(client: PersonDeactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Person.deactivate. */
export const PersonDeactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Person.deactivate. */
export const PersonDeactivateLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "inactive",
    "proven": true
  }
] as const;

// --- Person.hire ---
export interface PersonHireClientInput {
  givenName: string;
  familyName: string;
  email: string;
  phone?: string;
  /** Allowed: "staff" | "kitchen_staff" | "kitchen_lead" | "sales_staff" | "event_staff" | "inventory_staff" | "procurement_staff" | "logistics_staff" | "driver" | "workforce_staff" | "finance_staff" | "manager" | "kitchen_manager" | "sales_manager" | "event_manager" | "inventory_manager" | "logistics_manager" | "workforce_manager" | "finance_manager" | "admin" | "owner" | "system" */
  role?: "staff" | "kitchen_staff" | "kitchen_lead" | "sales_staff" | "event_staff" | "inventory_staff" | "procurement_staff" | "logistics_staff" | "driver" | "workforce_staff" | "finance_staff" | "manager" | "kitchen_manager" | "sales_manager" | "event_manager" | "inventory_manager" | "logistics_manager" | "workforce_manager" | "finance_manager" | "admin" | "owner" | "system";
  /** Allowed: "full_time" | "part_time" | "contractor" | "temporary" */
  employmentType?: "full_time" | "part_time" | "contractor" | "temporary";
  employeeNumber?: string;
  authSubjectId?: string;
}

export const PersonHireCapability = {
  capabilityId: "Person.hire",
  entity: "Person",
  command: "hire",
  route: "/api/manifest/Person/commands/hire",
  instanceCommand: true,
  clientParameterNames: ["givenName","familyName","email","phone","role","employmentType","employeeNumber","authSubjectId"],
  serverParameterNames: [],
  emits: ["PersonHired"],
} as const;

/**
 * Build command input for Person.hire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPersonHireInput(client: PersonHireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Person.hire. */
export const PersonHireInvalidation = [
  {
    "kind": "entityList",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Person.reactivate ---
export type PersonReactivateClientInput = Record<string, never>;

export const PersonReactivateCapability = {
  capabilityId: "Person.reactivate",
  entity: "Person",
  command: "reactivate",
  route: "/api/manifest/Person/commands/reactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PersonReactivated"],
} as const;

/**
 * Build command input for Person.reactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPersonReactivateInput(client: PersonReactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Person.reactivate. */
export const PersonReactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Person.reactivate. */
export const PersonReactivateLifecycle = [
  {
    "property": "status",
    "from": "inactive",
    "to": "active",
    "proven": true
  }
] as const;

// --- Person.terminate ---
export interface PersonTerminateClientInput {
  reason?: string;
}

export const PersonTerminateCapability = {
  capabilityId: "Person.terminate",
  entity: "Person",
  command: "terminate",
  route: "/api/manifest/Person/commands/terminate",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PersonTerminated"],
} as const;

/**
 * Build command input for Person.terminate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPersonTerminateInput(client: PersonTerminateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Person.terminate. */
export const PersonTerminateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Person",
    "queryKeyHint": "queryKeys.person.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Person.terminate. */
export const PersonTerminateLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "terminated",
    "proven": true
  },
  {
    "property": "status",
    "from": "inactive",
    "to": "terminated",
    "proven": true
  }
] as const;

// --- PrepTask.cancel ---
export interface PrepTaskCancelClientInput {
  reason: string;
}

export const PrepTaskCancelCapability = {
  capabilityId: "PrepTask.cancel",
  entity: "PrepTask",
  command: "cancel",
  route: "/api/manifest/PrepTask/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PrepTaskCancelled"],
} as const;

/**
 * Build command input for PrepTask.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskCancelInput(client: PrepTaskCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.cancel. */
export const PrepTaskCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PrepTask.cancel. */
export const PrepTaskCancelLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "claimed",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "in_progress",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "blocked",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- PrepTask.claim ---
export type PrepTaskClaimClientInput = Record<string, never>;

export const PrepTaskClaimCapability = {
  capabilityId: "PrepTask.claim",
  entity: "PrepTask",
  command: "claim",
  route: "/api/manifest/PrepTask/commands/claim",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PrepTaskClaimed"],
} as const;

/**
 * Build command input for PrepTask.claim.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskClaimInput(client: PrepTaskClaimClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.claim. */
export const PrepTaskClaimInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PrepTask.claim. */
export const PrepTaskClaimLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "claimed",
    "proven": true
  }
] as const;

// --- PrepTask.complete ---
export interface PrepTaskCompleteClientInput {
  /** Bounds: 0..∞ */
  completedQuantity?: number;
}

export const PrepTaskCompleteCapability = {
  capabilityId: "PrepTask.complete",
  entity: "PrepTask",
  command: "complete",
  route: "/api/manifest/PrepTask/commands/complete",
  instanceCommand: true,
  clientParameterNames: ["completedQuantity"],
  serverParameterNames: [],
  emits: ["PrepTaskCompleted"],
} as const;

/**
 * Build command input for PrepTask.complete.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskCompleteInput(client: PrepTaskCompleteClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.complete. */
export const PrepTaskCompleteInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PrepTask.complete. */
export const PrepTaskCompleteLifecycle = [
  {
    "property": "status",
    "from": "in_progress",
    "to": "completed",
    "proven": true
  }
] as const;

// --- PrepTask.markBlocked ---
export interface PrepTaskMarkBlockedClientInput {
  reason: string;
}

export const PrepTaskMarkBlockedCapability = {
  capabilityId: "PrepTask.markBlocked",
  entity: "PrepTask",
  command: "markBlocked",
  route: "/api/manifest/PrepTask/commands/markBlocked",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PrepTaskBlocked"],
} as const;

/**
 * Build command input for PrepTask.markBlocked.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskMarkBlockedInput(client: PrepTaskMarkBlockedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.markBlocked. */
export const PrepTaskMarkBlockedInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PrepTask.markBlocked. */
export const PrepTaskMarkBlockedLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "blocked",
    "proven": true
  },
  {
    "property": "status",
    "from": "claimed",
    "to": "blocked",
    "proven": true
  },
  {
    "property": "status",
    "from": "in_progress",
    "to": "blocked",
    "proven": true
  }
] as const;

// --- PrepTask.open ---
export interface PrepTaskOpenClientInput {
  eventDishId: string;
  eventId: string;
  name: string;
  /** Bounds: 1..∞ */
  quantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  ingredientId?: string;
  ingredientDemandId?: string;
  recipeId?: string;
  dishTaskId?: string;
  dishId?: string;
  category?: string;
  taskType?: string;
  specialInstructions?: string;
  isGenerated?: boolean;
  station?: string;
  dueAt?: string;
  notes?: string;
}

export const PrepTaskOpenCapability = {
  capabilityId: "PrepTask.open",
  entity: "PrepTask",
  command: "open",
  route: "/api/manifest/PrepTask/commands/open",
  instanceCommand: true,
  clientParameterNames: ["eventDishId","eventId","name","quantity","unit","ingredientId","ingredientDemandId","recipeId","dishTaskId","dishId","category","taskType","specialInstructions","isGenerated","station","dueAt","notes"],
  serverParameterNames: [],
  emits: ["PrepTaskOpened"],
} as const;

/**
 * Build command input for PrepTask.open.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskOpenInput(client: PrepTaskOpenClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.open. */
export const PrepTaskOpenInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PrepTask.refreshGenerated ---
export interface PrepTaskRefreshGeneratedClientInput {
  /** Bounds: 1..∞ */
  quantity: number;
  specialInstructions?: string;
}

export const PrepTaskRefreshGeneratedCapability = {
  capabilityId: "PrepTask.refreshGenerated",
  entity: "PrepTask",
  command: "refreshGenerated",
  route: "/api/manifest/PrepTask/commands/refreshGenerated",
  instanceCommand: true,
  clientParameterNames: ["quantity","specialInstructions"],
  serverParameterNames: [],
  emits: ["PrepTaskGeneratedRefreshed"],
} as const;

/**
 * Build command input for PrepTask.refreshGenerated.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskRefreshGeneratedInput(client: PrepTaskRefreshGeneratedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.refreshGenerated. */
export const PrepTaskRefreshGeneratedInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PrepTask.release ---
export type PrepTaskReleaseClientInput = Record<string, never>;

export const PrepTaskReleaseCapability = {
  capabilityId: "PrepTask.release",
  entity: "PrepTask",
  command: "release",
  route: "/api/manifest/PrepTask/commands/release",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PrepTaskReleased"],
} as const;

/**
 * Build command input for PrepTask.release.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskReleaseInput(client: PrepTaskReleaseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.release. */
export const PrepTaskReleaseInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PrepTask.release. */
export const PrepTaskReleaseLifecycle = [
  {
    "property": "status",
    "from": "claimed",
    "to": "pending",
    "proven": true
  },
  {
    "property": "status",
    "from": "blocked",
    "to": "pending",
    "proven": true
  }
] as const;

// --- PrepTask.revise ---
export interface PrepTaskReviseClientInput {
  name?: string;
  /** Bounds: 1..∞ */
  quantity?: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit?: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  category?: string;
  taskType?: string;
  specialInstructions?: string;
  ingredientId?: string;
  recipeId?: string;
}

export const PrepTaskReviseCapability = {
  capabilityId: "PrepTask.revise",
  entity: "PrepTask",
  command: "revise",
  route: "/api/manifest/PrepTask/commands/revise",
  instanceCommand: true,
  clientParameterNames: ["name","quantity","unit","category","taskType","specialInstructions","ingredientId","recipeId"],
  serverParameterNames: [],
  emits: ["PrepTaskRevised"],
} as const;

/**
 * Build command input for PrepTask.revise.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskReviseInput(client: PrepTaskReviseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.revise. */
export const PrepTaskReviseInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PrepTask.start ---
export type PrepTaskStartClientInput = Record<string, never>;

export const PrepTaskStartCapability = {
  capabilityId: "PrepTask.start",
  entity: "PrepTask",
  command: "start",
  route: "/api/manifest/PrepTask/commands/start",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PrepTaskStarted"],
} as const;

/**
 * Build command input for PrepTask.start.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskStartInput(client: PrepTaskStartClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.start. */
export const PrepTaskStartInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PrepTask.start. */
export const PrepTaskStartLifecycle = [
  {
    "property": "status",
    "from": "claimed",
    "to": "in_progress",
    "proven": true
  }
] as const;

// --- PrepTask.unblock ---
export type PrepTaskUnblockClientInput = Record<string, never>;

export const PrepTaskUnblockCapability = {
  capabilityId: "PrepTask.unblock",
  entity: "PrepTask",
  command: "unblock",
  route: "/api/manifest/PrepTask/commands/unblock",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PrepTaskUnblocked"],
} as const;

/**
 * Build command input for PrepTask.unblock.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskUnblockInput(client: PrepTaskUnblockClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTask.unblock. */
export const PrepTaskUnblockInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTask",
    "queryKeyHint": "queryKeys.prepTask.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PrepTask.unblock. */
export const PrepTaskUnblockLifecycle = [
  {
    "property": "status",
    "from": "claimed",
    "to": "pending",
    "proven": true
  },
  {
    "property": "status",
    "from": "blocked",
    "to": "pending",
    "proven": true
  }
] as const;

// --- PrepTaskDependency.declare ---
export interface PrepTaskDependencyDeclareClientInput {
  dependentTaskId: string;
  predecessorTaskId: string;
}

export const PrepTaskDependencyDeclareCapability = {
  capabilityId: "PrepTaskDependency.declare",
  entity: "PrepTaskDependency",
  command: "declare",
  route: "/api/manifest/PrepTaskDependency/commands/declare",
  instanceCommand: true,
  clientParameterNames: ["dependentTaskId","predecessorTaskId"],
  serverParameterNames: [],
  emits: ["PrepTaskDependencyDeclared"],
} as const;

/**
 * Build command input for PrepTaskDependency.declare.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskDependencyDeclareInput(client: PrepTaskDependencyDeclareClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTaskDependency.declare. */
export const PrepTaskDependencyDeclareInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTaskDependency",
    "queryKeyHint": "queryKeys.prepTaskDependency.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTaskDependency",
    "queryKeyHint": "queryKeys.prepTaskDependency.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PrepTaskDependency.satisfy ---
export type PrepTaskDependencySatisfyClientInput = Record<string, never>;

export const PrepTaskDependencySatisfyCapability = {
  capabilityId: "PrepTaskDependency.satisfy",
  entity: "PrepTaskDependency",
  command: "satisfy",
  route: "/api/manifest/PrepTaskDependency/commands/satisfy",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PrepTaskDependencySatisfied"],
} as const;

/**
 * Build command input for PrepTaskDependency.satisfy.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPrepTaskDependencySatisfyInput(client: PrepTaskDependencySatisfyClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PrepTaskDependency.satisfy. */
export const PrepTaskDependencySatisfyInvalidation = [
  {
    "kind": "entityList",
    "entity": "PrepTaskDependency",
    "queryKeyHint": "queryKeys.prepTaskDependency.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PrepTaskDependency",
    "queryKeyHint": "queryKeys.prepTaskDependency.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ProductionBatch.cancel ---
export interface ProductionBatchCancelClientInput {
  reason: string;
}

export const ProductionBatchCancelCapability = {
  capabilityId: "ProductionBatch.cancel",
  entity: "ProductionBatch",
  command: "cancel",
  route: "/api/manifest/ProductionBatch/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["ProductionBatchCancelled"],
} as const;

/**
 * Build command input for ProductionBatch.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProductionBatchCancelInput(client: ProductionBatchCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ProductionBatch.cancel. */
export const ProductionBatchCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "ProductionBatch",
    "queryKeyHint": "queryKeys.productionBatch.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ProductionBatch",
    "queryKeyHint": "queryKeys.productionBatch.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ProductionBatch.cancel. */
export const ProductionBatchCancelLifecycle = [
  {
    "property": "status",
    "from": "planned",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "in_progress",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- ProductionBatch.complete ---
export interface ProductionBatchCompleteClientInput {
  /** Bounds: 0..∞ */
  actualYield: number;
}

export const ProductionBatchCompleteCapability = {
  capabilityId: "ProductionBatch.complete",
  entity: "ProductionBatch",
  command: "complete",
  route: "/api/manifest/ProductionBatch/commands/complete",
  instanceCommand: true,
  clientParameterNames: ["actualYield"],
  serverParameterNames: [],
  emits: ["ProductionBatchCompleted"],
} as const;

/**
 * Build command input for ProductionBatch.complete.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProductionBatchCompleteInput(client: ProductionBatchCompleteClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ProductionBatch.complete. */
export const ProductionBatchCompleteInvalidation = [
  {
    "kind": "entityList",
    "entity": "ProductionBatch",
    "queryKeyHint": "queryKeys.productionBatch.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ProductionBatch",
    "queryKeyHint": "queryKeys.productionBatch.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ProductionBatch.complete. */
export const ProductionBatchCompleteLifecycle = [
  {
    "property": "status",
    "from": "in_progress",
    "to": "completed",
    "proven": true
  }
] as const;

// --- ProductionBatch.plan ---
export interface ProductionBatchPlanClientInput {
  recipeId: string;
  /** Bounds: 1..∞ */
  plannedYield: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  yieldUnit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  eventId?: string;
  notes?: string;
}

export const ProductionBatchPlanCapability = {
  capabilityId: "ProductionBatch.plan",
  entity: "ProductionBatch",
  command: "plan",
  route: "/api/manifest/ProductionBatch/commands/plan",
  instanceCommand: true,
  clientParameterNames: ["recipeId","plannedYield","yieldUnit","eventId","notes"],
  serverParameterNames: [],
  emits: ["ProductionBatchPlanned"],
} as const;

/**
 * Build command input for ProductionBatch.plan.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProductionBatchPlanInput(client: ProductionBatchPlanClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ProductionBatch.plan. */
export const ProductionBatchPlanInvalidation = [
  {
    "kind": "entityList",
    "entity": "ProductionBatch",
    "queryKeyHint": "queryKeys.productionBatch.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ProductionBatch",
    "queryKeyHint": "queryKeys.productionBatch.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ProductionBatch.start ---
export type ProductionBatchStartClientInput = Record<string, never>;

export const ProductionBatchStartCapability = {
  capabilityId: "ProductionBatch.start",
  entity: "ProductionBatch",
  command: "start",
  route: "/api/manifest/ProductionBatch/commands/start",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ProductionBatchStarted"],
} as const;

/**
 * Build command input for ProductionBatch.start.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProductionBatchStartInput(client: ProductionBatchStartClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ProductionBatch.start. */
export const ProductionBatchStartInvalidation = [
  {
    "kind": "entityList",
    "entity": "ProductionBatch",
    "queryKeyHint": "queryKeys.productionBatch.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ProductionBatch",
    "queryKeyHint": "queryKeys.productionBatch.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ProductionBatch.start. */
export const ProductionBatchStartLifecycle = [
  {
    "property": "status",
    "from": "planned",
    "to": "in_progress",
    "proven": true
  }
] as const;

// --- Proposal.accept ---
export interface ProposalAcceptClientInput {
  eventId?: string;
}

export const ProposalAcceptCapability = {
  capabilityId: "Proposal.accept",
  entity: "Proposal",
  command: "accept",
  route: "/api/manifest/Proposal/commands/accept",
  instanceCommand: true,
  clientParameterNames: ["eventId"],
  serverParameterNames: [],
  emits: ["ProposalAccepted"],
} as const;

/**
 * Build command input for Proposal.accept.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProposalAcceptInput(client: ProposalAcceptClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Proposal.accept. */
export const ProposalAcceptInvalidation = [
  {
    "kind": "entityList",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Proposal.accept. */
export const ProposalAcceptLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "accepted",
    "proven": true
  },
  {
    "property": "status",
    "from": "viewed",
    "to": "accepted",
    "proven": true
  }
] as const;

// --- Proposal.decline ---
export type ProposalDeclineClientInput = Record<string, never>;

export const ProposalDeclineCapability = {
  capabilityId: "Proposal.decline",
  entity: "Proposal",
  command: "decline",
  route: "/api/manifest/Proposal/commands/decline",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ProposalDeclined"],
} as const;

/**
 * Build command input for Proposal.decline.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProposalDeclineInput(client: ProposalDeclineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Proposal.decline. */
export const ProposalDeclineInvalidation = [
  {
    "kind": "entityList",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Proposal.decline. */
export const ProposalDeclineLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "declined",
    "proven": true
  },
  {
    "property": "status",
    "from": "viewed",
    "to": "declined",
    "proven": true
  }
] as const;

// --- Proposal.draft ---
export interface ProposalDraftClientInput {
  clientId: string;
  title: string;
  /** Bounds: 0..∞ */
  subtotal: number;
  /** Bounds: 0..∞ */
  taxAmount: number;
  /** Bounds: 0..∞ */
  discountAmount: number;
  /** Bounds: 0..∞ */
  total: number;
  proposalNumber?: string;
  eventDate?: string;
  eventType?: string;
  /** Bounds: 0..∞ */
  guestCount?: number;
  venueName?: string;
  venueAddress?: string;
  expiresAt?: string;
  notes?: string;
  terms?: string;
}

export const ProposalDraftCapability = {
  capabilityId: "Proposal.draft",
  entity: "Proposal",
  command: "draft",
  route: "/api/manifest/Proposal/commands/draft",
  instanceCommand: true,
  clientParameterNames: ["clientId","title","subtotal","taxAmount","discountAmount","total","proposalNumber","eventDate","eventType","guestCount","venueName","venueAddress","expiresAt","notes","terms"],
  serverParameterNames: [],
  emits: ["ProposalDrafted"],
} as const;

/**
 * Build command input for Proposal.draft.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProposalDraftInput(client: ProposalDraftClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Proposal.draft. */
export const ProposalDraftInvalidation = [
  {
    "kind": "entityList",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Proposal.expire ---
export type ProposalExpireClientInput = Record<string, never>;

export const ProposalExpireCapability = {
  capabilityId: "Proposal.expire",
  entity: "Proposal",
  command: "expire",
  route: "/api/manifest/Proposal/commands/expire",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ProposalExpired"],
} as const;

/**
 * Build command input for Proposal.expire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProposalExpireInput(client: ProposalExpireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Proposal.expire. */
export const ProposalExpireInvalidation = [
  {
    "kind": "entityList",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Proposal.expire. */
export const ProposalExpireLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "expired",
    "proven": true
  },
  {
    "property": "status",
    "from": "viewed",
    "to": "expired",
    "proven": true
  }
] as const;

// --- Proposal.markViewed ---
export type ProposalMarkViewedClientInput = Record<string, never>;

export const ProposalMarkViewedCapability = {
  capabilityId: "Proposal.markViewed",
  entity: "Proposal",
  command: "markViewed",
  route: "/api/manifest/Proposal/commands/markViewed",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ProposalViewed"],
} as const;

/**
 * Build command input for Proposal.markViewed.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProposalMarkViewedInput(client: ProposalMarkViewedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Proposal.markViewed. */
export const ProposalMarkViewedInvalidation = [
  {
    "kind": "entityList",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Proposal.markViewed. */
export const ProposalMarkViewedLifecycle = [
  {
    "property": "status",
    "from": "sent",
    "to": "viewed",
    "proven": true
  }
] as const;

// --- Proposal.reassignClient ---
export type ProposalReassignClientClientInput = Record<string, never>;

export const ProposalReassignClientCapability = {
  capabilityId: "Proposal.reassignClient",
  entity: "Proposal",
  command: "reassignClient",
  route: "/api/manifest/Proposal/commands/reassignClient",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ProposalClientReassigned"],
} as const;

/**
 * Build command input for Proposal.reassignClient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProposalReassignClientInput(client: ProposalReassignClientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Proposal.reassignClient. */
export const ProposalReassignClientInvalidation = [
  {
    "kind": "entityList",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Proposal.send ---
export type ProposalSendClientInput = Record<string, never>;

export const ProposalSendCapability = {
  capabilityId: "Proposal.send",
  entity: "Proposal",
  command: "send",
  route: "/api/manifest/Proposal/commands/send",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ProposalSent"],
} as const;

/**
 * Build command input for Proposal.send.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProposalSendInput(client: ProposalSendClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Proposal.send. */
export const ProposalSendInvalidation = [
  {
    "kind": "entityList",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Proposal.send. */
export const ProposalSendLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "sent",
    "proven": true
  }
] as const;

// --- Proposal.stageClientMerge ---
export interface ProposalStageClientMergeClientInput {
  clientMergeId: string;
  clientId: string;
}

export const ProposalStageClientMergeCapability = {
  capabilityId: "Proposal.stageClientMerge",
  entity: "Proposal",
  command: "stageClientMerge",
  route: "/api/manifest/Proposal/commands/stageClientMerge",
  instanceCommand: true,
  clientParameterNames: ["clientMergeId","clientId"],
  serverParameterNames: [],
  emits: ["ProposalClientMergeStaged"],
} as const;

/**
 * Build command input for Proposal.stageClientMerge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindProposalStageClientMergeInput(client: ProposalStageClientMergeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Proposal.stageClientMerge. */
export const ProposalStageClientMergeInvalidation = [
  {
    "kind": "entityList",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Proposal",
    "queryKeyHint": "queryKeys.proposal.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PurchaseNeed.assignToDraft ---
export interface PurchaseNeedAssignToDraftClientInput {
  vendorOrderId: string;
  vendorOrderLineId: string;
}

export const PurchaseNeedAssignToDraftCapability = {
  capabilityId: "PurchaseNeed.assignToDraft",
  entity: "PurchaseNeed",
  command: "assignToDraft",
  route: "/api/manifest/PurchaseNeed/commands/assignToDraft",
  instanceCommand: true,
  clientParameterNames: ["vendorOrderId","vendorOrderLineId"],
  serverParameterNames: [],
  emits: ["PurchaseNeedDraftAssigned"],
} as const;

/**
 * Build command input for PurchaseNeed.assignToDraft.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPurchaseNeedAssignToDraftInput(client: PurchaseNeedAssignToDraftClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PurchaseNeed.assignToDraft. */
export const PurchaseNeedAssignToDraftInvalidation = [
  {
    "kind": "entityList",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PurchaseNeed.cancel ---
export interface PurchaseNeedCancelClientInput {
  reason: string;
}

export const PurchaseNeedCancelCapability = {
  capabilityId: "PurchaseNeed.cancel",
  entity: "PurchaseNeed",
  command: "cancel",
  route: "/api/manifest/PurchaseNeed/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["PurchaseNeedCancelled"],
} as const;

/**
 * Build command input for PurchaseNeed.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPurchaseNeedCancelInput(client: PurchaseNeedCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PurchaseNeed.cancel. */
export const PurchaseNeedCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PurchaseNeed.cancel. */
export const PurchaseNeedCancelLifecycle = [
  {
    "property": "status",
    "from": "open",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "ordered",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- PurchaseNeed.create ---
export interface PurchaseNeedCreateClientInput {
  eventId: string;
  ingredientDemandId: string;
  ingredientId: string;
  /** Bounds: 1..∞ */
  requiredQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  purchasingWeekStart?: string;
  preferredVendorId?: string;
}

export const PurchaseNeedCreateCapability = {
  capabilityId: "PurchaseNeed.create",
  entity: "PurchaseNeed",
  command: "create",
  route: "/api/manifest/PurchaseNeed/commands/create",
  instanceCommand: false,
  clientParameterNames: ["eventId","ingredientDemandId","ingredientId","requiredQuantity","unit","purchasingWeekStart","preferredVendorId"],
  serverParameterNames: [],
  emits: ["PurchaseNeedOpened"],
} as const;

/**
 * Build command input for PurchaseNeed.create.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPurchaseNeedCreateInput(client: PurchaseNeedCreateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PurchaseNeed.create. */
export const PurchaseNeedCreateInvalidation = [
  {
    "kind": "entityList",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- PurchaseNeed.markDraftOrdered ---
export type PurchaseNeedMarkDraftOrderedClientInput = Record<string, never>;

export const PurchaseNeedMarkDraftOrderedCapability = {
  capabilityId: "PurchaseNeed.markDraftOrdered",
  entity: "PurchaseNeed",
  command: "markDraftOrdered",
  route: "/api/manifest/PurchaseNeed/commands/markDraftOrdered",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PurchaseNeedOrdered"],
} as const;

/**
 * Build command input for PurchaseNeed.markDraftOrdered.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPurchaseNeedMarkDraftOrderedInput(client: PurchaseNeedMarkDraftOrderedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PurchaseNeed.markDraftOrdered. */
export const PurchaseNeedMarkDraftOrderedInvalidation = [
  {
    "kind": "entityList",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PurchaseNeed.markDraftOrdered. */
export const PurchaseNeedMarkDraftOrderedLifecycle = [
  {
    "property": "status",
    "from": "open",
    "to": "ordered",
    "proven": true
  }
] as const;

// --- PurchaseNeed.markFulfilled ---
export type PurchaseNeedMarkFulfilledClientInput = Record<string, never>;

export const PurchaseNeedMarkFulfilledCapability = {
  capabilityId: "PurchaseNeed.markFulfilled",
  entity: "PurchaseNeed",
  command: "markFulfilled",
  route: "/api/manifest/PurchaseNeed/commands/markFulfilled",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["PurchaseNeedFulfilled"],
} as const;

/**
 * Build command input for PurchaseNeed.markFulfilled.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPurchaseNeedMarkFulfilledInput(client: PurchaseNeedMarkFulfilledClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PurchaseNeed.markFulfilled. */
export const PurchaseNeedMarkFulfilledInvalidation = [
  {
    "kind": "entityList",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PurchaseNeed.markFulfilled. */
export const PurchaseNeedMarkFulfilledLifecycle = [
  {
    "property": "status",
    "from": "ordered",
    "to": "fulfilled",
    "proven": true
  }
] as const;

// --- PurchaseNeed.markOrdered ---
export interface PurchaseNeedMarkOrderedClientInput {
  vendorOrderId: string;
  vendorOrderLineId: string;
}

export const PurchaseNeedMarkOrderedCapability = {
  capabilityId: "PurchaseNeed.markOrdered",
  entity: "PurchaseNeed",
  command: "markOrdered",
  route: "/api/manifest/PurchaseNeed/commands/markOrdered",
  instanceCommand: true,
  clientParameterNames: ["vendorOrderId","vendorOrderLineId"],
  serverParameterNames: [],
  emits: ["PurchaseNeedOrdered"],
} as const;

/**
 * Build command input for PurchaseNeed.markOrdered.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPurchaseNeedMarkOrderedInput(client: PurchaseNeedMarkOrderedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PurchaseNeed.markOrdered. */
export const PurchaseNeedMarkOrderedInvalidation = [
  {
    "kind": "entityList",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for PurchaseNeed.markOrdered. */
export const PurchaseNeedMarkOrderedLifecycle = [
  {
    "property": "status",
    "from": "open",
    "to": "ordered",
    "proven": true
  }
] as const;

// --- PurchaseNeed.reviseRequired ---
export interface PurchaseNeedReviseRequiredClientInput {
  /** Bounds: 1..∞ */
  requiredQuantity: number;
}

export const PurchaseNeedReviseRequiredCapability = {
  capabilityId: "PurchaseNeed.reviseRequired",
  entity: "PurchaseNeed",
  command: "reviseRequired",
  route: "/api/manifest/PurchaseNeed/commands/reviseRequired",
  instanceCommand: true,
  clientParameterNames: ["requiredQuantity"],
  serverParameterNames: [],
  emits: ["PurchaseNeedOpened"],
} as const;

/**
 * Build command input for PurchaseNeed.reviseRequired.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindPurchaseNeedReviseRequiredInput(client: PurchaseNeedReviseRequiredClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful PurchaseNeed.reviseRequired. */
export const PurchaseNeedReviseRequiredInvalidation = [
  {
    "kind": "entityList",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "PurchaseNeed",
    "queryKeyHint": "queryKeys.purchaseNeed.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Qualification.expire ---
export type QualificationExpireClientInput = Record<string, never>;

export const QualificationExpireCapability = {
  capabilityId: "Qualification.expire",
  entity: "Qualification",
  command: "expire",
  route: "/api/manifest/Qualification/commands/expire",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["QualificationExpired"],
} as const;

/**
 * Build command input for Qualification.expire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindQualificationExpireInput(client: QualificationExpireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Qualification.expire. */
export const QualificationExpireInvalidation = [
  {
    "kind": "entityList",
    "entity": "Qualification",
    "queryKeyHint": "queryKeys.qualification.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Qualification",
    "queryKeyHint": "queryKeys.qualification.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Qualification.expire. */
export const QualificationExpireLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "expired",
    "proven": true
  }
] as const;

// --- Qualification.grant ---
export interface QualificationGrantClientInput {
  personId: string;
  name: string;
  /** Must not be "". */
  issuedAt: string & { readonly __nonEmpty?: true };
  certificationType: string;
  issuingBody: string;
  expiresAt?: string;
  documentRef?: string;
  notes?: string;
}

export const QualificationGrantCapability = {
  capabilityId: "Qualification.grant",
  entity: "Qualification",
  command: "grant",
  route: "/api/manifest/Qualification/commands/grant",
  instanceCommand: true,
  clientParameterNames: ["personId","name","issuedAt","certificationType","issuingBody","expiresAt","documentRef","notes"],
  serverParameterNames: [],
  emits: ["QualificationGranted"],
} as const;

/**
 * Build command input for Qualification.grant.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindQualificationGrantInput(client: QualificationGrantClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Qualification.grant. */
export const QualificationGrantInvalidation = [
  {
    "kind": "entityList",
    "entity": "Qualification",
    "queryKeyHint": "queryKeys.qualification.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Qualification",
    "queryKeyHint": "queryKeys.qualification.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Qualification.revoke ---
export interface QualificationRevokeClientInput {
  notes?: string;
}

export const QualificationRevokeCapability = {
  capabilityId: "Qualification.revoke",
  entity: "Qualification",
  command: "revoke",
  route: "/api/manifest/Qualification/commands/revoke",
  instanceCommand: true,
  clientParameterNames: ["notes"],
  serverParameterNames: [],
  emits: ["QualificationRevoked"],
} as const;

/**
 * Build command input for Qualification.revoke.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindQualificationRevokeInput(client: QualificationRevokeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Qualification.revoke. */
export const QualificationRevokeInvalidation = [
  {
    "kind": "entityList",
    "entity": "Qualification",
    "queryKeyHint": "queryKeys.qualification.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Qualification",
    "queryKeyHint": "queryKeys.qualification.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Qualification.revoke. */
export const QualificationRevokeLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "revoked",
    "proven": true
  }
] as const;

// --- QualityCheck.fail ---
export interface QualityCheckFailClientInput {
  notes?: string;
}

export const QualityCheckFailCapability = {
  capabilityId: "QualityCheck.fail",
  entity: "QualityCheck",
  command: "fail",
  route: "/api/manifest/QualityCheck/commands/fail",
  instanceCommand: true,
  clientParameterNames: ["notes"],
  serverParameterNames: [],
  emits: ["QualityCheckFailed"],
} as const;

/**
 * Build command input for QualityCheck.fail.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindQualityCheckFailInput(client: QualityCheckFailClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful QualityCheck.fail. */
export const QualityCheckFailInvalidation = [
  {
    "kind": "entityList",
    "entity": "QualityCheck",
    "queryKeyHint": "queryKeys.qualityCheck.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "QualityCheck",
    "queryKeyHint": "queryKeys.qualityCheck.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for QualityCheck.fail. */
export const QualityCheckFailLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "failed",
    "proven": true
  }
] as const;

// --- QualityCheck.open ---
export interface QualityCheckOpenClientInput {
  prepTaskId?: string;
  productionBatchId?: string;
  notes?: string;
}

export const QualityCheckOpenCapability = {
  capabilityId: "QualityCheck.open",
  entity: "QualityCheck",
  command: "open",
  route: "/api/manifest/QualityCheck/commands/open",
  instanceCommand: true,
  clientParameterNames: ["prepTaskId","productionBatchId","notes"],
  serverParameterNames: [],
  emits: ["QualityCheckOpened"],
} as const;

/**
 * Build command input for QualityCheck.open.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindQualityCheckOpenInput(client: QualityCheckOpenClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful QualityCheck.open. */
export const QualityCheckOpenInvalidation = [
  {
    "kind": "entityList",
    "entity": "QualityCheck",
    "queryKeyHint": "queryKeys.qualityCheck.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "QualityCheck",
    "queryKeyHint": "queryKeys.qualityCheck.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- QualityCheck.pass ---
export interface QualityCheckPassClientInput {
  notes?: string;
}

export const QualityCheckPassCapability = {
  capabilityId: "QualityCheck.pass",
  entity: "QualityCheck",
  command: "pass",
  route: "/api/manifest/QualityCheck/commands/pass",
  instanceCommand: true,
  clientParameterNames: ["notes"],
  serverParameterNames: [],
  emits: ["QualityCheckPassed"],
} as const;

/**
 * Build command input for QualityCheck.pass.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindQualityCheckPassInput(client: QualityCheckPassClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful QualityCheck.pass. */
export const QualityCheckPassInvalidation = [
  {
    "kind": "entityList",
    "entity": "QualityCheck",
    "queryKeyHint": "queryKeys.qualityCheck.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "QualityCheck",
    "queryKeyHint": "queryKeys.qualityCheck.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for QualityCheck.pass. */
export const QualityCheckPassLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "passed",
    "proven": true
  }
] as const;

// --- QualityCheck.reinspect ---
export type QualityCheckReinspectClientInput = Record<string, never>;

export const QualityCheckReinspectCapability = {
  capabilityId: "QualityCheck.reinspect",
  entity: "QualityCheck",
  command: "reinspect",
  route: "/api/manifest/QualityCheck/commands/reinspect",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["QualityCheckReopened"],
} as const;

/**
 * Build command input for QualityCheck.reinspect.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindQualityCheckReinspectInput(client: QualityCheckReinspectClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful QualityCheck.reinspect. */
export const QualityCheckReinspectInvalidation = [
  {
    "kind": "entityList",
    "entity": "QualityCheck",
    "queryKeyHint": "queryKeys.qualityCheck.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "QualityCheck",
    "queryKeyHint": "queryKeys.qualityCheck.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for QualityCheck.reinspect. */
export const QualityCheckReinspectLifecycle = [
  {
    "property": "status",
    "from": "passed",
    "to": "pending",
    "proven": true
  },
  {
    "property": "status",
    "from": "failed",
    "to": "pending",
    "proven": true
  }
] as const;

// --- Recipe.draft ---
export interface RecipeDraftClientInput {
  name: string;
  /** Bounds: 1..∞ */
  yieldQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  yieldUnit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 1..∞ */
  batchMultiplier?: number;
  category?: string;
  cuisine?: string;
  description?: string;
  instructions?: string;
}

export const RecipeDraftCapability = {
  capabilityId: "Recipe.draft",
  entity: "Recipe",
  command: "draft",
  route: "/api/manifest/Recipe/commands/draft",
  instanceCommand: true,
  clientParameterNames: ["name","yieldQuantity","yieldUnit","batchMultiplier","category","cuisine","description","instructions"],
  serverParameterNames: [],
  emits: ["RecipeDrafted"],
} as const;

/**
 * Build command input for Recipe.draft.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeDraftInput(client: RecipeDraftClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Recipe.draft. */
export const RecipeDraftInvalidation = [
  {
    "kind": "entityList",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Recipe.publishVersion ---
export type RecipePublishVersionClientInput = Record<string, never>;

export const RecipePublishVersionCapability = {
  capabilityId: "Recipe.publishVersion",
  entity: "Recipe",
  command: "publishVersion",
  route: "/api/manifest/Recipe/commands/publishVersion",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeVersionPublished"],
} as const;

/**
 * Build command input for Recipe.publishVersion.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipePublishVersionInput(client: RecipePublishVersionClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Recipe.publishVersion. */
export const RecipePublishVersionInvalidation = [
  {
    "kind": "entityList",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Recipe.publishVersion. */
export const RecipePublishVersionLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "published",
    "proven": true
  }
] as const;

// --- Recipe.retire ---
export interface RecipeRetireClientInput {
  reason: string;
}

export const RecipeRetireCapability = {
  capabilityId: "Recipe.retire",
  entity: "Recipe",
  command: "retire",
  route: "/api/manifest/Recipe/commands/retire",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["RecipeRetired"],
} as const;

/**
 * Build command input for Recipe.retire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeRetireInput(client: RecipeRetireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Recipe.retire. */
export const RecipeRetireInvalidation = [
  {
    "kind": "entityList",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Recipe.retire. */
export const RecipeRetireLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "retired",
    "proven": true
  },
  {
    "property": "status",
    "from": "published",
    "to": "retired",
    "proven": true
  }
] as const;

// --- Recipe.retract ---
export type RecipeRetractClientInput = Record<string, never>;

export const RecipeRetractCapability = {
  capabilityId: "Recipe.retract",
  entity: "Recipe",
  command: "retract",
  route: "/api/manifest/Recipe/commands/retract",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeVersionRetracted"],
} as const;

/**
 * Build command input for Recipe.retract.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeRetractInput(client: RecipeRetractClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Recipe.retract. */
export const RecipeRetractInvalidation = [
  {
    "kind": "entityList",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Recipe.retract. */
export const RecipeRetractLifecycle = [
  {
    "property": "status",
    "from": "published",
    "to": "draft",
    "proven": true
  }
] as const;

// --- Recipe.reviseDraft ---
export interface RecipeReviseDraftClientInput {
  name: string;
  /** Bounds: 1..∞ */
  yieldQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  yieldUnit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 1..∞ */
  batchMultiplier: number;
  category?: string;
  cuisine?: string;
  description?: string;
  instructions?: string;
}

export const RecipeReviseDraftCapability = {
  capabilityId: "Recipe.reviseDraft",
  entity: "Recipe",
  command: "reviseDraft",
  route: "/api/manifest/Recipe/commands/reviseDraft",
  instanceCommand: true,
  clientParameterNames: ["name","yieldQuantity","yieldUnit","batchMultiplier","category","cuisine","description","instructions"],
  serverParameterNames: [],
  emits: ["RecipeDraftRevised"],
} as const;

/**
 * Build command input for Recipe.reviseDraft.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeReviseDraftInput(client: RecipeReviseDraftClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Recipe.reviseDraft. */
export const RecipeReviseDraftInvalidation = [
  {
    "kind": "entityList",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Recipe",
    "queryKeyHint": "queryKeys.recipe.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImport.approveReview ---
export type RecipeImportApproveReviewClientInput = Record<string, never>;

export const RecipeImportApproveReviewCapability = {
  capabilityId: "RecipeImport.approveReview",
  entity: "RecipeImport",
  command: "approveReview",
  route: "/api/manifest/RecipeImport/commands/approveReview",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeImportReviewApproved"],
} as const;

/**
 * Build command input for RecipeImport.approveReview.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportApproveReviewInput(client: RecipeImportApproveReviewClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.approveReview. */
export const RecipeImportApproveReviewInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecipeImport.approveReview. */
export const RecipeImportApproveReviewLifecycle = [
  {
    "property": "status",
    "from": "reviewing",
    "to": "ready",
    "proven": true
  }
] as const;

// --- RecipeImport.beginFinalization ---
export type RecipeImportBeginFinalizationClientInput = Record<string, never>;

export const RecipeImportBeginFinalizationCapability = {
  capabilityId: "RecipeImport.beginFinalization",
  entity: "RecipeImport",
  command: "beginFinalization",
  route: "/api/manifest/RecipeImport/commands/beginFinalization",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeImportFinalizationStarted"],
} as const;

/**
 * Build command input for RecipeImport.beginFinalization.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportBeginFinalizationInput(client: RecipeImportBeginFinalizationClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.beginFinalization. */
export const RecipeImportBeginFinalizationInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecipeImport.beginFinalization. */
export const RecipeImportBeginFinalizationLifecycle = [
  {
    "property": "status",
    "from": "ready",
    "to": "finalizing",
    "proven": true
  }
] as const;

// --- RecipeImport.beginReview ---
export type RecipeImportBeginReviewClientInput = Record<string, never>;

export const RecipeImportBeginReviewCapability = {
  capabilityId: "RecipeImport.beginReview",
  entity: "RecipeImport",
  command: "beginReview",
  route: "/api/manifest/RecipeImport/commands/beginReview",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeImportReviewStarted"],
} as const;

/**
 * Build command input for RecipeImport.beginReview.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportBeginReviewInput(client: RecipeImportBeginReviewClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.beginReview. */
export const RecipeImportBeginReviewInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecipeImport.beginReview. */
export const RecipeImportBeginReviewLifecycle = [
  {
    "property": "status",
    "from": "parsed",
    "to": "reviewing",
    "proven": true
  },
  {
    "property": "status",
    "from": "ready",
    "to": "reviewing",
    "proven": true
  },
  {
    "property": "status",
    "from": "finalizing",
    "to": "reviewing",
    "proven": true
  },
  {
    "property": "status",
    "from": "failed",
    "to": "reviewing",
    "proven": true
  }
] as const;

// --- RecipeImport.cancel ---
export interface RecipeImportCancelClientInput {
  reason: string;
}

export const RecipeImportCancelCapability = {
  capabilityId: "RecipeImport.cancel",
  entity: "RecipeImport",
  command: "cancel",
  route: "/api/manifest/RecipeImport/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["RecipeImportCancelled"],
} as const;

/**
 * Build command input for RecipeImport.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportCancelInput(client: RecipeImportCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.cancel. */
export const RecipeImportCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecipeImport.cancel. */
export const RecipeImportCancelLifecycle = [
  {
    "property": "status",
    "from": "uploaded",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "parsed",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "reviewing",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "ready",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "finalizing",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "failed",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- RecipeImport.complete ---
export type RecipeImportCompleteClientInput = Record<string, never>;

export const RecipeImportCompleteCapability = {
  capabilityId: "RecipeImport.complete",
  entity: "RecipeImport",
  command: "complete",
  route: "/api/manifest/RecipeImport/commands/complete",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeImportCompleted"],
} as const;

/**
 * Build command input for RecipeImport.complete.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportCompleteInput(client: RecipeImportCompleteClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.complete. */
export const RecipeImportCompleteInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecipeImport.complete. */
export const RecipeImportCompleteLifecycle = [
  {
    "property": "status",
    "from": "finalizing",
    "to": "completed",
    "proven": true
  }
] as const;

// --- RecipeImport.markFailed ---
export interface RecipeImportMarkFailedClientInput {
  failureDetail: string;
  duringParsing?: boolean;
}

export const RecipeImportMarkFailedCapability = {
  capabilityId: "RecipeImport.markFailed",
  entity: "RecipeImport",
  command: "markFailed",
  route: "/api/manifest/RecipeImport/commands/markFailed",
  instanceCommand: true,
  clientParameterNames: ["failureDetail","duringParsing"],
  serverParameterNames: [],
  emits: ["RecipeImportFailed"],
} as const;

/**
 * Build command input for RecipeImport.markFailed.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportMarkFailedInput(client: RecipeImportMarkFailedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.markFailed. */
export const RecipeImportMarkFailedInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecipeImport.markFailed. */
export const RecipeImportMarkFailedLifecycle = [
  {
    "property": "status",
    "from": "uploaded",
    "to": "failed",
    "proven": true
  },
  {
    "property": "status",
    "from": "parsed",
    "to": "failed",
    "proven": true
  },
  {
    "property": "status",
    "from": "reviewing",
    "to": "failed",
    "proven": true
  },
  {
    "property": "status",
    "from": "ready",
    "to": "failed",
    "proven": true
  },
  {
    "property": "status",
    "from": "finalizing",
    "to": "failed",
    "proven": true
  }
] as const;

// --- RecipeImport.recordParse ---
export interface RecipeImportRecordParseClientInput {
  parsedName: string;
  /** Bounds: 0..∞ */
  parsedLineCount: number;
  parsedDescription?: string;
  parsedCategory?: string;
  parsedCuisine?: string;
  parsedInstructions?: string;
  /** Bounds: 1..∞ */
  parsedYieldQuantity?: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  parsedYieldUnit?: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 1..∞ */
  parsedBatchMultiplier?: number;
}

export const RecipeImportRecordParseCapability = {
  capabilityId: "RecipeImport.recordParse",
  entity: "RecipeImport",
  command: "recordParse",
  route: "/api/manifest/RecipeImport/commands/recordParse",
  instanceCommand: true,
  clientParameterNames: ["parsedName","parsedLineCount","parsedDescription","parsedCategory","parsedCuisine","parsedInstructions","parsedYieldQuantity","parsedYieldUnit","parsedBatchMultiplier"],
  serverParameterNames: [],
  emits: ["RecipeImportParsed"],
} as const;

/**
 * Build command input for RecipeImport.recordParse.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportRecordParseInput(client: RecipeImportRecordParseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.recordParse. */
export const RecipeImportRecordParseInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecipeImport.recordParse. */
export const RecipeImportRecordParseLifecycle = [
  {
    "property": "status",
    "from": "uploaded",
    "to": "parsed",
    "proven": true
  }
] as const;

// --- RecipeImport.recordRecipe ---
export interface RecipeImportRecordRecipeClientInput {
  resultingRecipeId: string;
}

export const RecipeImportRecordRecipeCapability = {
  capabilityId: "RecipeImport.recordRecipe",
  entity: "RecipeImport",
  command: "recordRecipe",
  route: "/api/manifest/RecipeImport/commands/recordRecipe",
  instanceCommand: true,
  clientParameterNames: ["resultingRecipeId"],
  serverParameterNames: [],
  emits: ["RecipeImportRecipeRecorded"],
} as const;

/**
 * Build command input for RecipeImport.recordRecipe.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportRecordRecipeInput(client: RecipeImportRecordRecipeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.recordRecipe. */
export const RecipeImportRecordRecipeInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImport.recordResolutionProgress ---
export interface RecipeImportRecordResolutionProgressClientInput {
  /** Bounds: 0..∞ */
  resolvedLineCount: number;
}

export const RecipeImportRecordResolutionProgressCapability = {
  capabilityId: "RecipeImport.recordResolutionProgress",
  entity: "RecipeImport",
  command: "recordResolutionProgress",
  route: "/api/manifest/RecipeImport/commands/recordResolutionProgress",
  instanceCommand: true,
  clientParameterNames: ["resolvedLineCount"],
  serverParameterNames: [],
  emits: ["RecipeImportResolutionProgressRecorded"],
} as const;

/**
 * Build command input for RecipeImport.recordResolutionProgress.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportRecordResolutionProgressInput(client: RecipeImportRecordResolutionProgressClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.recordResolutionProgress. */
export const RecipeImportRecordResolutionProgressInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImport.resumeReview ---
export type RecipeImportResumeReviewClientInput = Record<string, never>;

export const RecipeImportResumeReviewCapability = {
  capabilityId: "RecipeImport.resumeReview",
  entity: "RecipeImport",
  command: "resumeReview",
  route: "/api/manifest/RecipeImport/commands/resumeReview",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeImportReviewResumed"],
} as const;

/**
 * Build command input for RecipeImport.resumeReview.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportResumeReviewInput(client: RecipeImportResumeReviewClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.resumeReview. */
export const RecipeImportResumeReviewInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecipeImport.resumeReview. */
export const RecipeImportResumeReviewLifecycle = [
  {
    "property": "status",
    "from": "parsed",
    "to": "reviewing",
    "proven": true
  },
  {
    "property": "status",
    "from": "ready",
    "to": "reviewing",
    "proven": true
  },
  {
    "property": "status",
    "from": "finalizing",
    "to": "reviewing",
    "proven": true
  },
  {
    "property": "status",
    "from": "failed",
    "to": "reviewing",
    "proven": true
  }
] as const;

// --- RecipeImport.upload ---
export interface RecipeImportUploadClientInput {
  /** Allowed: "pasted_text" | "text_file" | "csv_bundle" */
  sourceKind: "pasted_text" | "text_file" | "csv_bundle";
  rawSourceText: string;
  /** Bounds: 0..∞ */
  sourceByteCount: number;
  sourceFingerprint: string;
  sourceFilename?: string;
}

export const RecipeImportUploadCapability = {
  capabilityId: "RecipeImport.upload",
  entity: "RecipeImport",
  command: "upload",
  route: "/api/manifest/RecipeImport/commands/upload",
  instanceCommand: true,
  clientParameterNames: ["sourceKind","rawSourceText","sourceByteCount","sourceFingerprint","sourceFilename"],
  serverParameterNames: [],
  emits: ["RecipeImportUploaded"],
} as const;

/**
 * Build command input for RecipeImport.upload.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportUploadInput(client: RecipeImportUploadClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImport.upload. */
export const RecipeImportUploadInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImport",
    "queryKeyHint": "queryKeys.recipeImport.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.attachCreatedIngredient ---
export interface RecipeImportLineAttachCreatedIngredientClientInput {
  matchedIngredientId: string;
}

export const RecipeImportLineAttachCreatedIngredientCapability = {
  capabilityId: "RecipeImportLine.attachCreatedIngredient",
  entity: "RecipeImportLine",
  command: "attachCreatedIngredient",
  route: "/api/manifest/RecipeImportLine/commands/attachCreatedIngredient",
  instanceCommand: true,
  clientParameterNames: ["matchedIngredientId"],
  serverParameterNames: [],
  emits: ["RecipeImportLineCreatedIngredientAttached"],
} as const;

/**
 * Build command input for RecipeImportLine.attachCreatedIngredient.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineAttachCreatedIngredientInput(client: RecipeImportLineAttachCreatedIngredientClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.attachCreatedIngredient. */
export const RecipeImportLineAttachCreatedIngredientInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.confirmExisting ---
export interface RecipeImportLineConfirmExistingClientInput {
  matchedIngredientId: string;
}

export const RecipeImportLineConfirmExistingCapability = {
  capabilityId: "RecipeImportLine.confirmExisting",
  entity: "RecipeImportLine",
  command: "confirmExisting",
  route: "/api/manifest/RecipeImportLine/commands/confirmExisting",
  instanceCommand: true,
  clientParameterNames: ["matchedIngredientId"],
  serverParameterNames: [],
  emits: ["RecipeImportLineExistingConfirmed"],
} as const;

/**
 * Build command input for RecipeImportLine.confirmExisting.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineConfirmExistingInput(client: RecipeImportLineConfirmExistingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.confirmExisting. */
export const RecipeImportLineConfirmExistingInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.confirmNew ---
export type RecipeImportLineConfirmNewClientInput = Record<string, never>;

export const RecipeImportLineConfirmNewCapability = {
  capabilityId: "RecipeImportLine.confirmNew",
  entity: "RecipeImportLine",
  command: "confirmNew",
  route: "/api/manifest/RecipeImportLine/commands/confirmNew",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeImportLineNewConfirmed"],
} as const;

/**
 * Build command input for RecipeImportLine.confirmNew.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineConfirmNewInput(client: RecipeImportLineConfirmNewClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.confirmNew. */
export const RecipeImportLineConfirmNewInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.discard ---
export interface RecipeImportLineDiscardClientInput {
  reason: string;
}

export const RecipeImportLineDiscardCapability = {
  capabilityId: "RecipeImportLine.discard",
  entity: "RecipeImportLine",
  command: "discard",
  route: "/api/manifest/RecipeImportLine/commands/discard",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["RecipeImportLineDiscarded"],
} as const;

/**
 * Build command input for RecipeImportLine.discard.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineDiscardInput(client: RecipeImportLineDiscardClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.discard. */
export const RecipeImportLineDiscardInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.markNew ---
export type RecipeImportLineMarkNewClientInput = Record<string, never>;

export const RecipeImportLineMarkNewCapability = {
  capabilityId: "RecipeImportLine.markNew",
  entity: "RecipeImportLine",
  command: "markNew",
  route: "/api/manifest/RecipeImportLine/commands/markNew",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeImportLineMarkedNew"],
} as const;

/**
 * Build command input for RecipeImportLine.markNew.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineMarkNewInput(client: RecipeImportLineMarkNewClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.markNew. */
export const RecipeImportLineMarkNewInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.resetResolution ---
export type RecipeImportLineResetResolutionClientInput = Record<string, never>;

export const RecipeImportLineResetResolutionCapability = {
  capabilityId: "RecipeImportLine.resetResolution",
  entity: "RecipeImportLine",
  command: "resetResolution",
  route: "/api/manifest/RecipeImportLine/commands/resetResolution",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecipeImportLineResolutionReset"],
} as const;

/**
 * Build command input for RecipeImportLine.resetResolution.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineResetResolutionInput(client: RecipeImportLineResetResolutionClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.resetResolution. */
export const RecipeImportLineResetResolutionInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.stage ---
export interface RecipeImportLineStageClientInput {
  importId: string;
  /** Bounds: 0..∞ */
  sourceOrder: number;
  sourceLine: string;
  parsedQuantity?: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  parsedUnit?: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  parsedIngredientName?: string;
  preparationNote?: string;
}

export const RecipeImportLineStageCapability = {
  capabilityId: "RecipeImportLine.stage",
  entity: "RecipeImportLine",
  command: "stage",
  route: "/api/manifest/RecipeImportLine/commands/stage",
  instanceCommand: true,
  clientParameterNames: ["importId","sourceOrder","sourceLine","parsedQuantity","parsedUnit","parsedIngredientName","preparationNote"],
  serverParameterNames: [],
  emits: ["RecipeImportLineStaged"],
} as const;

/**
 * Build command input for RecipeImportLine.stage.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineStageInput(client: RecipeImportLineStageClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.stage. */
export const RecipeImportLineStageInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.suggestExactMatch ---
export interface RecipeImportLineSuggestExactMatchClientInput {
  matchedIngredientId: string;
}

export const RecipeImportLineSuggestExactMatchCapability = {
  capabilityId: "RecipeImportLine.suggestExactMatch",
  entity: "RecipeImportLine",
  command: "suggestExactMatch",
  route: "/api/manifest/RecipeImportLine/commands/suggestExactMatch",
  instanceCommand: true,
  clientParameterNames: ["matchedIngredientId"],
  serverParameterNames: [],
  emits: ["RecipeImportLineExactMatchSuggested"],
} as const;

/**
 * Build command input for RecipeImportLine.suggestExactMatch.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineSuggestExactMatchInput(client: RecipeImportLineSuggestExactMatchClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.suggestExactMatch. */
export const RecipeImportLineSuggestExactMatchInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeImportLine.suggestPossibleMatches ---
export interface RecipeImportLineSuggestPossibleMatchesClientInput {
  possibleMatchIngredientIds: string[];
}

export const RecipeImportLineSuggestPossibleMatchesCapability = {
  capabilityId: "RecipeImportLine.suggestPossibleMatches",
  entity: "RecipeImportLine",
  command: "suggestPossibleMatches",
  route: "/api/manifest/RecipeImportLine/commands/suggestPossibleMatches",
  instanceCommand: true,
  clientParameterNames: ["possibleMatchIngredientIds"],
  serverParameterNames: [],
  emits: ["RecipeImportLinePossibleMatchesSuggested"],
} as const;

/**
 * Build command input for RecipeImportLine.suggestPossibleMatches.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeImportLineSuggestPossibleMatchesInput(client: RecipeImportLineSuggestPossibleMatchesClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeImportLine.suggestPossibleMatches. */
export const RecipeImportLineSuggestPossibleMatchesInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeImportLine",
    "queryKeyHint": "queryKeys.recipeImportLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeIngredient.add ---
export interface RecipeIngredientAddClientInput {
  recipeId: string;
  ingredientId: string;
  /** Bounds: 1..∞ */
  quantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  sortOrder?: number;
  prepNotes?: string;
}

export const RecipeIngredientAddCapability = {
  capabilityId: "RecipeIngredient.add",
  entity: "RecipeIngredient",
  command: "add",
  route: "/api/manifest/RecipeIngredient/commands/add",
  instanceCommand: true,
  clientParameterNames: ["recipeId","ingredientId","quantity","unit","sortOrder","prepNotes"],
  serverParameterNames: [],
  emits: ["RecipeIngredientAdded"],
} as const;

/**
 * Build command input for RecipeIngredient.add.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeIngredientAddInput(client: RecipeIngredientAddClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeIngredient.add. */
export const RecipeIngredientAddInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeIngredient",
    "queryKeyHint": "queryKeys.recipeIngredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeIngredient",
    "queryKeyHint": "queryKeys.recipeIngredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeIngredient.adjustQuantity ---
export interface RecipeIngredientAdjustQuantityClientInput {
  /** Bounds: 1..∞ */
  quantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
}

export const RecipeIngredientAdjustQuantityCapability = {
  capabilityId: "RecipeIngredient.adjustQuantity",
  entity: "RecipeIngredient",
  command: "adjustQuantity",
  route: "/api/manifest/RecipeIngredient/commands/adjustQuantity",
  instanceCommand: true,
  clientParameterNames: ["quantity","unit"],
  serverParameterNames: [],
  emits: ["RecipeIngredientQuantityAdjusted"],
} as const;

/**
 * Build command input for RecipeIngredient.adjustQuantity.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeIngredientAdjustQuantityInput(client: RecipeIngredientAdjustQuantityClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeIngredient.adjustQuantity. */
export const RecipeIngredientAdjustQuantityInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeIngredient",
    "queryKeyHint": "queryKeys.recipeIngredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeIngredient",
    "queryKeyHint": "queryKeys.recipeIngredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeIngredient.remove ---
export interface RecipeIngredientRemoveClientInput {
  reason: string;
}

export const RecipeIngredientRemoveCapability = {
  capabilityId: "RecipeIngredient.remove",
  entity: "RecipeIngredient",
  command: "remove",
  route: "/api/manifest/RecipeIngredient/commands/remove",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["RecipeIngredientRemoved"],
} as const;

/**
 * Build command input for RecipeIngredient.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeIngredientRemoveInput(client: RecipeIngredientRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeIngredient.remove. */
export const RecipeIngredientRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeIngredient",
    "queryKeyHint": "queryKeys.recipeIngredient.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeIngredient",
    "queryKeyHint": "queryKeys.recipeIngredient.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeStep.add ---
export interface RecipeStepAddClientInput {
  recipeId: string;
  instruction: string;
  sortOrder?: number;
  /** Bounds: 0..∞ */
  durationMinutes?: number;
}

export const RecipeStepAddCapability = {
  capabilityId: "RecipeStep.add",
  entity: "RecipeStep",
  command: "add",
  route: "/api/manifest/RecipeStep/commands/add",
  instanceCommand: true,
  clientParameterNames: ["recipeId","instruction","sortOrder","durationMinutes"],
  serverParameterNames: [],
  emits: ["RecipeStepAdded"],
} as const;

/**
 * Build command input for RecipeStep.add.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeStepAddInput(client: RecipeStepAddClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeStep.add. */
export const RecipeStepAddInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeStep",
    "queryKeyHint": "queryKeys.recipeStep.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeStep",
    "queryKeyHint": "queryKeys.recipeStep.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeStep.remove ---
export interface RecipeStepRemoveClientInput {
  reason: string;
}

export const RecipeStepRemoveCapability = {
  capabilityId: "RecipeStep.remove",
  entity: "RecipeStep",
  command: "remove",
  route: "/api/manifest/RecipeStep/commands/remove",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["RecipeStepRemoved"],
} as const;

/**
 * Build command input for RecipeStep.remove.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeStepRemoveInput(client: RecipeStepRemoveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeStep.remove. */
export const RecipeStepRemoveInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeStep",
    "queryKeyHint": "queryKeys.recipeStep.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeStep",
    "queryKeyHint": "queryKeys.recipeStep.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecipeStep.revise ---
export interface RecipeStepReviseClientInput {
  instruction: string;
  sortOrder?: number;
  /** Bounds: 0..∞ */
  durationMinutes?: number;
}

export const RecipeStepReviseCapability = {
  capabilityId: "RecipeStep.revise",
  entity: "RecipeStep",
  command: "revise",
  route: "/api/manifest/RecipeStep/commands/revise",
  instanceCommand: true,
  clientParameterNames: ["instruction","sortOrder","durationMinutes"],
  serverParameterNames: [],
  emits: ["RecipeStepRevised"],
} as const;

/**
 * Build command input for RecipeStep.revise.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecipeStepReviseInput(client: RecipeStepReviseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecipeStep.revise. */
export const RecipeStepReviseInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecipeStep",
    "queryKeyHint": "queryKeys.recipeStep.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecipeStep",
    "queryKeyHint": "queryKeys.recipeStep.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecurringAvailability.declare ---
export interface RecurringAvailabilityDeclareClientInput {
  personId: string;
  /** Bounds: 0..6 */
  dayOfWeek: number;
  /** Bounds: 0..∞ */
  startMinute: number;
  /** Bounds: -∞..1440 */
  endMinute: number;
  notes?: string;
}

export const RecurringAvailabilityDeclareCapability = {
  capabilityId: "RecurringAvailability.declare",
  entity: "RecurringAvailability",
  command: "declare",
  route: "/api/manifest/RecurringAvailability/commands/declare",
  instanceCommand: true,
  clientParameterNames: ["personId","dayOfWeek","startMinute","endMinute","notes"],
  serverParameterNames: [],
  emits: ["RecurringAvailabilityDeclared"],
} as const;

/**
 * Build command input for RecurringAvailability.declare.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecurringAvailabilityDeclareInput(client: RecurringAvailabilityDeclareClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecurringAvailability.declare. */
export const RecurringAvailabilityDeclareInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecurringAvailability",
    "queryKeyHint": "queryKeys.recurringAvailability.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecurringAvailability",
    "queryKeyHint": "queryKeys.recurringAvailability.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- RecurringAvailability.withdraw ---
export type RecurringAvailabilityWithdrawClientInput = Record<string, never>;

export const RecurringAvailabilityWithdrawCapability = {
  capabilityId: "RecurringAvailability.withdraw",
  entity: "RecurringAvailability",
  command: "withdraw",
  route: "/api/manifest/RecurringAvailability/commands/withdraw",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["RecurringAvailabilityWithdrawn"],
} as const;

/**
 * Build command input for RecurringAvailability.withdraw.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindRecurringAvailabilityWithdrawInput(client: RecurringAvailabilityWithdrawClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful RecurringAvailability.withdraw. */
export const RecurringAvailabilityWithdrawInvalidation = [
  {
    "kind": "entityList",
    "entity": "RecurringAvailability",
    "queryKeyHint": "queryKeys.recurringAvailability.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "RecurringAvailability",
    "queryKeyHint": "queryKeys.recurringAvailability.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for RecurringAvailability.withdraw. */
export const RecurringAvailabilityWithdrawLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "withdrawn",
    "proven": true
  }
] as const;

// --- SavedReportDefinition.archive ---
export type SavedReportDefinitionArchiveClientInput = Record<string, never>;

export const SavedReportDefinitionArchiveCapability = {
  capabilityId: "SavedReportDefinition.archive",
  entity: "SavedReportDefinition",
  command: "archive",
  route: "/api/manifest/SavedReportDefinition/commands/archive",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["SavedReportArchived"],
} as const;

/**
 * Build command input for SavedReportDefinition.archive.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindSavedReportDefinitionArchiveInput(client: SavedReportDefinitionArchiveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful SavedReportDefinition.archive. */
export const SavedReportDefinitionArchiveInvalidation = [
  {
    "kind": "entityList",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for SavedReportDefinition.archive. */
export const SavedReportDefinitionArchiveLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "archived",
    "proven": true
  }
] as const;

// --- SavedReportDefinition.changeSharing ---
export interface SavedReportDefinitionChangeSharingClientInput {
  /** Allowed: "owner_only" | "team" | "tenant_wide" */
  sharingScope: "owner_only" | "team" | "tenant_wide";
}

export const SavedReportDefinitionChangeSharingCapability = {
  capabilityId: "SavedReportDefinition.changeSharing",
  entity: "SavedReportDefinition",
  command: "changeSharing",
  route: "/api/manifest/SavedReportDefinition/commands/changeSharing",
  instanceCommand: true,
  clientParameterNames: ["sharingScope"],
  serverParameterNames: [],
  emits: ["SavedReportSharingChanged"],
} as const;

/**
 * Build command input for SavedReportDefinition.changeSharing.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindSavedReportDefinitionChangeSharingInput(client: SavedReportDefinitionChangeSharingClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful SavedReportDefinition.changeSharing. */
export const SavedReportDefinitionChangeSharingInvalidation = [
  {
    "kind": "entityList",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- SavedReportDefinition.createDefinition ---
export interface SavedReportDefinitionCreateDefinitionClientInput {
  name: string;
  /** Allowed: "events" | "sales" | "inventory" | "production" | "workforce" | "logistics" | "finance" */
  subjectArea: "events" | "sales" | "inventory" | "production" | "workforce" | "logistics" | "finance";
  chartType: string;
  definition: unknown;
  /** Allowed: "owner_only" | "team" | "tenant_wide" */
  sharingScope?: "owner_only" | "team" | "tenant_wide";
}

export const SavedReportDefinitionCreateDefinitionCapability = {
  capabilityId: "SavedReportDefinition.createDefinition",
  entity: "SavedReportDefinition",
  command: "createDefinition",
  route: "/api/manifest/SavedReportDefinition/commands/createDefinition",
  instanceCommand: true,
  clientParameterNames: ["name","subjectArea","chartType","definition","sharingScope"],
  serverParameterNames: [],
  emits: ["SavedReportDefinitionCreated"],
} as const;

/**
 * Build command input for SavedReportDefinition.createDefinition.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindSavedReportDefinitionCreateDefinitionInput(client: SavedReportDefinitionCreateDefinitionClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful SavedReportDefinition.createDefinition. */
export const SavedReportDefinitionCreateDefinitionInvalidation = [
  {
    "kind": "entityList",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- SavedReportDefinition.rename ---
export interface SavedReportDefinitionRenameClientInput {
  name: string;
}

export const SavedReportDefinitionRenameCapability = {
  capabilityId: "SavedReportDefinition.rename",
  entity: "SavedReportDefinition",
  command: "rename",
  route: "/api/manifest/SavedReportDefinition/commands/rename",
  instanceCommand: true,
  clientParameterNames: ["name"],
  serverParameterNames: [],
  emits: ["SavedReportRenamed"],
} as const;

/**
 * Build command input for SavedReportDefinition.rename.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindSavedReportDefinitionRenameInput(client: SavedReportDefinitionRenameClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful SavedReportDefinition.rename. */
export const SavedReportDefinitionRenameInvalidation = [
  {
    "kind": "entityList",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- SavedReportDefinition.restore ---
export type SavedReportDefinitionRestoreClientInput = Record<string, never>;

export const SavedReportDefinitionRestoreCapability = {
  capabilityId: "SavedReportDefinition.restore",
  entity: "SavedReportDefinition",
  command: "restore",
  route: "/api/manifest/SavedReportDefinition/commands/restore",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["SavedReportRestored"],
} as const;

/**
 * Build command input for SavedReportDefinition.restore.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindSavedReportDefinitionRestoreInput(client: SavedReportDefinitionRestoreClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful SavedReportDefinition.restore. */
export const SavedReportDefinitionRestoreInvalidation = [
  {
    "kind": "entityList",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for SavedReportDefinition.restore. */
export const SavedReportDefinitionRestoreLifecycle = [
  {
    "property": "status",
    "from": "archived",
    "to": "active",
    "proven": true
  }
] as const;

// --- SavedReportDefinition.updateDefinition ---
export interface SavedReportDefinitionUpdateDefinitionClientInput {
  chartType?: string;
  definition?: unknown;
  /** Allowed: "events" | "sales" | "inventory" | "production" | "workforce" | "logistics" | "finance" */
  subjectArea?: "events" | "sales" | "inventory" | "production" | "workforce" | "logistics" | "finance";
}

export const SavedReportDefinitionUpdateDefinitionCapability = {
  capabilityId: "SavedReportDefinition.updateDefinition",
  entity: "SavedReportDefinition",
  command: "updateDefinition",
  route: "/api/manifest/SavedReportDefinition/commands/updateDefinition",
  instanceCommand: true,
  clientParameterNames: ["chartType","definition","subjectArea"],
  serverParameterNames: [],
  emits: ["SavedReportDefinitionUpdated"],
} as const;

/**
 * Build command input for SavedReportDefinition.updateDefinition.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindSavedReportDefinitionUpdateDefinitionInput(client: SavedReportDefinitionUpdateDefinitionClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful SavedReportDefinition.updateDefinition. */
export const SavedReportDefinitionUpdateDefinitionInvalidation = [
  {
    "kind": "entityList",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "SavedReportDefinition",
    "queryKeyHint": "queryKeys.savedReportDefinition.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Shift.applyApprovedSwap ---
export type ShiftApplyApprovedSwapClientInput = Record<string, never>;

export const ShiftApplyApprovedSwapCapability = {
  capabilityId: "Shift.applyApprovedSwap",
  entity: "Shift",
  command: "applyApprovedSwap",
  route: "/api/manifest/Shift/commands/applyApprovedSwap",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ShiftSwapped"],
} as const;

/**
 * Build command input for Shift.applyApprovedSwap.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftApplyApprovedSwapInput(client: ShiftApplyApprovedSwapClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Shift.applyApprovedSwap. */
export const ShiftApplyApprovedSwapInvalidation = [
  {
    "kind": "entityList",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Shift.cancel ---
export interface ShiftCancelClientInput {
  reason: string;
}

export const ShiftCancelCapability = {
  capabilityId: "Shift.cancel",
  entity: "Shift",
  command: "cancel",
  route: "/api/manifest/Shift/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["ShiftCancelled"],
} as const;

/**
 * Build command input for Shift.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftCancelInput(client: ShiftCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Shift.cancel. */
export const ShiftCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Shift.cancel. */
export const ShiftCancelLifecycle = [
  {
    "property": "status",
    "from": "scheduled",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "started",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- Shift.complete ---
export type ShiftCompleteClientInput = Record<string, never>;

export const ShiftCompleteCapability = {
  capabilityId: "Shift.complete",
  entity: "Shift",
  command: "complete",
  route: "/api/manifest/Shift/commands/complete",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ShiftCompleted"],
} as const;

/**
 * Build command input for Shift.complete.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftCompleteInput(client: ShiftCompleteClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Shift.complete. */
export const ShiftCompleteInvalidation = [
  {
    "kind": "entityList",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Shift.complete. */
export const ShiftCompleteLifecycle = [
  {
    "property": "status",
    "from": "started",
    "to": "completed",
    "proven": true
  }
] as const;

// --- Shift.markNoShow ---
export type ShiftMarkNoShowClientInput = Record<string, never>;

export const ShiftMarkNoShowCapability = {
  capabilityId: "Shift.markNoShow",
  entity: "Shift",
  command: "markNoShow",
  route: "/api/manifest/Shift/commands/markNoShow",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ShiftNoShowMarked"],
} as const;

/**
 * Build command input for Shift.markNoShow.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftMarkNoShowInput(client: ShiftMarkNoShowClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Shift.markNoShow. */
export const ShiftMarkNoShowInvalidation = [
  {
    "kind": "entityList",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Shift.markNoShow. */
export const ShiftMarkNoShowLifecycle = [
  {
    "property": "status",
    "from": "scheduled",
    "to": "no_show",
    "proven": true
  },
  {
    "property": "status",
    "from": "started",
    "to": "no_show",
    "proven": true
  }
] as const;

// --- Shift.schedule ---
export interface ShiftScheduleClientInput {
  personId: string;
  /** Must not be "". */
  startsAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  endsAt: string & { readonly __nonEmpty?: true };
  eventId?: string;
  role?: string;
  shiftTypeId?: string;
  requiredQualificationId?: string;
  requiredTrainingCompletionId?: string;
  notes?: string;
}

export const ShiftScheduleCapability = {
  capabilityId: "Shift.schedule",
  entity: "Shift",
  command: "schedule",
  route: "/api/manifest/Shift/commands/schedule",
  instanceCommand: true,
  clientParameterNames: ["personId","startsAt","endsAt","eventId","role","shiftTypeId","requiredQualificationId","requiredTrainingCompletionId","notes"],
  serverParameterNames: [],
  emits: ["ShiftScheduled"],
} as const;

/**
 * Build command input for Shift.schedule.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftScheduleInput(client: ShiftScheduleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Shift.schedule. */
export const ShiftScheduleInvalidation = [
  {
    "kind": "entityList",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Shift.stageApprovedSwap ---
export interface ShiftStageApprovedSwapClientInput {
  shiftSwapRequestId: string;
  requesterPersonId: string;
  recipientPersonId: string;
  targetQualificationId?: string;
  targetTrainingCompletionId?: string;
}

export const ShiftStageApprovedSwapCapability = {
  capabilityId: "Shift.stageApprovedSwap",
  entity: "Shift",
  command: "stageApprovedSwap",
  route: "/api/manifest/Shift/commands/stageApprovedSwap",
  instanceCommand: true,
  clientParameterNames: ["shiftSwapRequestId","requesterPersonId","recipientPersonId","targetQualificationId","targetTrainingCompletionId"],
  serverParameterNames: [],
  emits: ["ShiftSwapStaged"],
} as const;

/**
 * Build command input for Shift.stageApprovedSwap.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftStageApprovedSwapInput(client: ShiftStageApprovedSwapClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Shift.stageApprovedSwap. */
export const ShiftStageApprovedSwapInvalidation = [
  {
    "kind": "entityList",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Shift.start ---
export type ShiftStartClientInput = Record<string, never>;

export const ShiftStartCapability = {
  capabilityId: "Shift.start",
  entity: "Shift",
  command: "start",
  route: "/api/manifest/Shift/commands/start",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ShiftStarted"],
} as const;

/**
 * Build command input for Shift.start.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftStartInput(client: ShiftStartClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Shift.start. */
export const ShiftStartInvalidation = [
  {
    "kind": "entityList",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Shift",
    "queryKeyHint": "queryKeys.shift.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Shift.start. */
export const ShiftStartLifecycle = [
  {
    "property": "status",
    "from": "scheduled",
    "to": "started",
    "proven": true
  }
] as const;

// --- ShiftSwapRequest.accept ---
export type ShiftSwapRequestAcceptClientInput = Record<string, never>;

export const ShiftSwapRequestAcceptCapability = {
  capabilityId: "ShiftSwapRequest.accept",
  entity: "ShiftSwapRequest",
  command: "accept",
  route: "/api/manifest/ShiftSwapRequest/commands/accept",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ShiftSwapAccepted"],
} as const;

/**
 * Build command input for ShiftSwapRequest.accept.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftSwapRequestAcceptInput(client: ShiftSwapRequestAcceptClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftSwapRequest.accept. */
export const ShiftSwapRequestAcceptInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ShiftSwapRequest.accept. */
export const ShiftSwapRequestAcceptLifecycle = [
  {
    "property": "status",
    "from": "pending_recipient",
    "to": "awaiting_manager",
    "proven": true
  }
] as const;

// --- ShiftSwapRequest.approve ---
export interface ShiftSwapRequestApproveClientInput {
  reviewNote?: string;
}

export const ShiftSwapRequestApproveCapability = {
  capabilityId: "ShiftSwapRequest.approve",
  entity: "ShiftSwapRequest",
  command: "approve",
  route: "/api/manifest/ShiftSwapRequest/commands/approve",
  instanceCommand: true,
  clientParameterNames: ["reviewNote"],
  serverParameterNames: [],
  emits: ["ShiftSwapApproved"],
} as const;

/**
 * Build command input for ShiftSwapRequest.approve.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftSwapRequestApproveInput(client: ShiftSwapRequestApproveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftSwapRequest.approve. */
export const ShiftSwapRequestApproveInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ShiftSwapRequest.approve. */
export const ShiftSwapRequestApproveLifecycle = [
  {
    "property": "status",
    "from": "awaiting_manager",
    "to": "approved",
    "proven": true
  }
] as const;

// --- ShiftSwapRequest.decline ---
export interface ShiftSwapRequestDeclineClientInput {
  reviewNote?: string;
}

export const ShiftSwapRequestDeclineCapability = {
  capabilityId: "ShiftSwapRequest.decline",
  entity: "ShiftSwapRequest",
  command: "decline",
  route: "/api/manifest/ShiftSwapRequest/commands/decline",
  instanceCommand: true,
  clientParameterNames: ["reviewNote"],
  serverParameterNames: [],
  emits: ["ShiftSwapDeclined"],
} as const;

/**
 * Build command input for ShiftSwapRequest.decline.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftSwapRequestDeclineInput(client: ShiftSwapRequestDeclineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftSwapRequest.decline. */
export const ShiftSwapRequestDeclineInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ShiftSwapRequest.decline. */
export const ShiftSwapRequestDeclineLifecycle = [
  {
    "property": "status",
    "from": "pending_recipient",
    "to": "declined",
    "proven": true
  }
] as const;

// --- ShiftSwapRequest.propose ---
export interface ShiftSwapRequestProposeClientInput {
  shiftId: string;
  requesterPersonId: string;
  recipientPersonId: string;
  shiftTypeId?: string;
  sourceQualificationId?: string;
  targetQualificationId?: string;
  targetTrainingCompletionId?: string;
  reason?: string;
}

export const ShiftSwapRequestProposeCapability = {
  capabilityId: "ShiftSwapRequest.propose",
  entity: "ShiftSwapRequest",
  command: "propose",
  route: "/api/manifest/ShiftSwapRequest/commands/propose",
  instanceCommand: true,
  clientParameterNames: ["shiftId","requesterPersonId","recipientPersonId","shiftTypeId","sourceQualificationId","targetQualificationId","targetTrainingCompletionId","reason"],
  serverParameterNames: [],
  emits: ["ShiftSwapProposed"],
} as const;

/**
 * Build command input for ShiftSwapRequest.propose.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftSwapRequestProposeInput(client: ShiftSwapRequestProposeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftSwapRequest.propose. */
export const ShiftSwapRequestProposeInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- ShiftSwapRequest.reject ---
export interface ShiftSwapRequestRejectClientInput {
  reviewNote?: string;
}

export const ShiftSwapRequestRejectCapability = {
  capabilityId: "ShiftSwapRequest.reject",
  entity: "ShiftSwapRequest",
  command: "reject",
  route: "/api/manifest/ShiftSwapRequest/commands/reject",
  instanceCommand: true,
  clientParameterNames: ["reviewNote"],
  serverParameterNames: [],
  emits: ["ShiftSwapRejected"],
} as const;

/**
 * Build command input for ShiftSwapRequest.reject.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftSwapRequestRejectInput(client: ShiftSwapRequestRejectClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftSwapRequest.reject. */
export const ShiftSwapRequestRejectInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ShiftSwapRequest.reject. */
export const ShiftSwapRequestRejectLifecycle = [
  {
    "property": "status",
    "from": "awaiting_manager",
    "to": "rejected",
    "proven": true
  }
] as const;

// --- ShiftSwapRequest.withdraw ---
export type ShiftSwapRequestWithdrawClientInput = Record<string, never>;

export const ShiftSwapRequestWithdrawCapability = {
  capabilityId: "ShiftSwapRequest.withdraw",
  entity: "ShiftSwapRequest",
  command: "withdraw",
  route: "/api/manifest/ShiftSwapRequest/commands/withdraw",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ShiftSwapWithdrawn"],
} as const;

/**
 * Build command input for ShiftSwapRequest.withdraw.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftSwapRequestWithdrawInput(client: ShiftSwapRequestWithdrawClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftSwapRequest.withdraw. */
export const ShiftSwapRequestWithdrawInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftSwapRequest",
    "queryKeyHint": "queryKeys.shiftSwapRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ShiftSwapRequest.withdraw. */
export const ShiftSwapRequestWithdrawLifecycle = [
  {
    "property": "status",
    "from": "pending_recipient",
    "to": "withdrawn",
    "proven": true
  },
  {
    "property": "status",
    "from": "awaiting_manager",
    "to": "withdrawn",
    "proven": true
  }
] as const;

// --- ShiftType.define ---
export interface ShiftTypeDefineClientInput {
  name: string;
  description?: string;
  requiredTrainingModuleId?: string;
}

export const ShiftTypeDefineCapability = {
  capabilityId: "ShiftType.define",
  entity: "ShiftType",
  command: "define",
  route: "/api/manifest/ShiftType/commands/define",
  instanceCommand: true,
  clientParameterNames: ["name","description","requiredTrainingModuleId"],
  serverParameterNames: [],
  emits: ["ShiftTypeDefined"],
} as const;

/**
 * Build command input for ShiftType.define.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftTypeDefineInput(client: ShiftTypeDefineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftType.define. */
export const ShiftTypeDefineInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftType",
    "queryKeyHint": "queryKeys.shiftType.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftType",
    "queryKeyHint": "queryKeys.shiftType.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ShiftType.define. */
export const ShiftTypeDefineLifecycle = [
  {
    "property": "status",
    "from": "retired",
    "to": "active",
    "proven": true
  }
] as const;

// --- ShiftType.reactivate ---
export type ShiftTypeReactivateClientInput = Record<string, never>;

export const ShiftTypeReactivateCapability = {
  capabilityId: "ShiftType.reactivate",
  entity: "ShiftType",
  command: "reactivate",
  route: "/api/manifest/ShiftType/commands/reactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ShiftTypeReactivated"],
} as const;

/**
 * Build command input for ShiftType.reactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftTypeReactivateInput(client: ShiftTypeReactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftType.reactivate. */
export const ShiftTypeReactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftType",
    "queryKeyHint": "queryKeys.shiftType.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftType",
    "queryKeyHint": "queryKeys.shiftType.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ShiftType.reactivate. */
export const ShiftTypeReactivateLifecycle = [
  {
    "property": "status",
    "from": "retired",
    "to": "active",
    "proven": true
  }
] as const;

// --- ShiftType.retire ---
export type ShiftTypeRetireClientInput = Record<string, never>;

export const ShiftTypeRetireCapability = {
  capabilityId: "ShiftType.retire",
  entity: "ShiftType",
  command: "retire",
  route: "/api/manifest/ShiftType/commands/retire",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["ShiftTypeRetired"],
} as const;

/**
 * Build command input for ShiftType.retire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindShiftTypeRetireInput(client: ShiftTypeRetireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful ShiftType.retire. */
export const ShiftTypeRetireInvalidation = [
  {
    "kind": "entityList",
    "entity": "ShiftType",
    "queryKeyHint": "queryKeys.shiftType.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "ShiftType",
    "queryKeyHint": "queryKeys.shiftType.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for ShiftType.retire. */
export const ShiftTypeRetireLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "retired",
    "proven": true
  }
] as const;

// --- StockCountLine.confirmLedgerMatch ---
export type StockCountLineConfirmLedgerMatchClientInput = Record<string, never>;

export const StockCountLineConfirmLedgerMatchCapability = {
  capabilityId: "StockCountLine.confirmLedgerMatch",
  entity: "StockCountLine",
  command: "confirmLedgerMatch",
  route: "/api/manifest/StockCountLine/commands/confirmLedgerMatch",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["StockCountLineMatched"],
} as const;

/**
 * Build command input for StockCountLine.confirmLedgerMatch.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStockCountLineConfirmLedgerMatchInput(client: StockCountLineConfirmLedgerMatchClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StockCountLine.confirmLedgerMatch. */
export const StockCountLineConfirmLedgerMatchInvalidation = [
  {
    "kind": "entityList",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for StockCountLine.confirmLedgerMatch. */
export const StockCountLineConfirmLedgerMatchLifecycle = [
  {
    "property": "status",
    "from": "counted",
    "to": "reconciled",
    "proven": true
  }
] as const;

// --- StockCountLine.freeze ---
export interface StockCountLineFreezeClientInput {
  stockCountSessionId: string;
  inventoryItemId: string;
  locationId: string;
  ingredientId: string;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
}

export const StockCountLineFreezeCapability = {
  capabilityId: "StockCountLine.freeze",
  entity: "StockCountLine",
  command: "freeze",
  route: "/api/manifest/StockCountLine/commands/freeze",
  instanceCommand: true,
  clientParameterNames: ["stockCountSessionId","inventoryItemId","locationId","ingredientId","unit"],
  serverParameterNames: [],
  emits: ["StockCountLineFrozen"],
} as const;

/**
 * Build command input for StockCountLine.freeze.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStockCountLineFreezeInput(client: StockCountLineFreezeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StockCountLine.freeze. */
export const StockCountLineFreezeInvalidation = [
  {
    "kind": "entityList",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- StockCountLine.reconcileVariance ---
export interface StockCountLineReconcileVarianceClientInput {
  reason: string;
}

export const StockCountLineReconcileVarianceCapability = {
  capabilityId: "StockCountLine.reconcileVariance",
  entity: "StockCountLine",
  command: "reconcileVariance",
  route: "/api/manifest/StockCountLine/commands/reconcileVariance",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["StockCountVarianceReconciled"],
} as const;

/**
 * Build command input for StockCountLine.reconcileVariance.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStockCountLineReconcileVarianceInput(client: StockCountLineReconcileVarianceClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StockCountLine.reconcileVariance. */
export const StockCountLineReconcileVarianceInvalidation = [
  {
    "kind": "entityList",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for StockCountLine.reconcileVariance. */
export const StockCountLineReconcileVarianceLifecycle = [
  {
    "property": "status",
    "from": "counted",
    "to": "reconciled",
    "proven": true
  }
] as const;

// --- StockCountLine.recordCount ---
export interface StockCountLineRecordCountClientInput {
  /** Bounds: 0..∞ */
  countedQuantity: number;
  countNote?: string;
}

export const StockCountLineRecordCountCapability = {
  capabilityId: "StockCountLine.recordCount",
  entity: "StockCountLine",
  command: "recordCount",
  route: "/api/manifest/StockCountLine/commands/recordCount",
  instanceCommand: true,
  clientParameterNames: ["countedQuantity","countNote"],
  serverParameterNames: [],
  emits: ["StockCountLineCounted"],
} as const;

/**
 * Build command input for StockCountLine.recordCount.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStockCountLineRecordCountInput(client: StockCountLineRecordCountClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StockCountLine.recordCount. */
export const StockCountLineRecordCountInvalidation = [
  {
    "kind": "entityList",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for StockCountLine.recordCount. */
export const StockCountLineRecordCountLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "counted",
    "proven": true
  }
] as const;

// --- StockCountLine.reviseCount ---
export interface StockCountLineReviseCountClientInput {
  /** Bounds: 0..∞ */
  countedQuantity: number;
  countNote?: string;
}

export const StockCountLineReviseCountCapability = {
  capabilityId: "StockCountLine.reviseCount",
  entity: "StockCountLine",
  command: "reviseCount",
  route: "/api/manifest/StockCountLine/commands/reviseCount",
  instanceCommand: true,
  clientParameterNames: ["countedQuantity","countNote"],
  serverParameterNames: [],
  emits: ["StockCountLineCountRevised"],
} as const;

/**
 * Build command input for StockCountLine.reviseCount.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStockCountLineReviseCountInput(client: StockCountLineReviseCountClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StockCountLine.reviseCount. */
export const StockCountLineReviseCountInvalidation = [
  {
    "kind": "entityList",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StockCountLine",
    "queryKeyHint": "queryKeys.stockCountLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- StockCountSession.close ---
export type StockCountSessionCloseClientInput = Record<string, never>;

export const StockCountSessionCloseCapability = {
  capabilityId: "StockCountSession.close",
  entity: "StockCountSession",
  command: "close",
  route: "/api/manifest/StockCountSession/commands/close",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["StockCountSessionClosed"],
} as const;

/**
 * Build command input for StockCountSession.close.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStockCountSessionCloseInput(client: StockCountSessionCloseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StockCountSession.close. */
export const StockCountSessionCloseInvalidation = [
  {
    "kind": "entityList",
    "entity": "StockCountSession",
    "queryKeyHint": "queryKeys.stockCountSession.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StockCountSession",
    "queryKeyHint": "queryKeys.stockCountSession.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for StockCountSession.close. */
export const StockCountSessionCloseLifecycle = [
  {
    "property": "status",
    "from": "in_progress",
    "to": "closed",
    "proven": true
  }
] as const;

// --- StockCountSession.start ---
export interface StockCountSessionStartClientInput {
  label: string;
  locationIds: string;
  locationNames: string;
  /** Bounds: 0..∞ */
  lineCount: number;
}

export const StockCountSessionStartCapability = {
  capabilityId: "StockCountSession.start",
  entity: "StockCountSession",
  command: "start",
  route: "/api/manifest/StockCountSession/commands/start",
  instanceCommand: true,
  clientParameterNames: ["label","locationIds","locationNames","lineCount"],
  serverParameterNames: [],
  emits: ["StockCountSessionStarted"],
} as const;

/**
 * Build command input for StockCountSession.start.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStockCountSessionStartInput(client: StockCountSessionStartClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StockCountSession.start. */
export const StockCountSessionStartInvalidation = [
  {
    "kind": "entityList",
    "entity": "StockCountSession",
    "queryKeyHint": "queryKeys.stockCountSession.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StockCountSession",
    "queryKeyHint": "queryKeys.stockCountSession.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- StockTransfer.record ---
export interface StockTransferRecordClientInput {
  sourceInventoryItemId: string;
  destinationInventoryItemId: string;
  ingredientId: string;
  sourceLocationId: string;
  destinationLocationId: string;
  /** Bounds: 1..∞ */
  quantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  notes?: string;
}

export const StockTransferRecordCapability = {
  capabilityId: "StockTransfer.record",
  entity: "StockTransfer",
  command: "record",
  route: "/api/manifest/StockTransfer/commands/record",
  instanceCommand: true,
  clientParameterNames: ["sourceInventoryItemId","destinationInventoryItemId","ingredientId","sourceLocationId","destinationLocationId","quantity","unit","notes"],
  serverParameterNames: [],
  emits: ["StockTransferRecorded"],
} as const;

/**
 * Build command input for StockTransfer.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStockTransferRecordInput(client: StockTransferRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StockTransfer.record. */
export const StockTransferRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "StockTransfer",
    "queryKeyHint": "queryKeys.stockTransfer.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StockTransfer",
    "queryKeyHint": "queryKeys.stockTransfer.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- StorageLocation.activate ---
export type StorageLocationActivateClientInput = Record<string, never>;

export const StorageLocationActivateCapability = {
  capabilityId: "StorageLocation.activate",
  entity: "StorageLocation",
  command: "activate",
  route: "/api/manifest/StorageLocation/commands/activate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["StorageLocationActivated"],
} as const;

/**
 * Build command input for StorageLocation.activate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStorageLocationActivateInput(client: StorageLocationActivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StorageLocation.activate. */
export const StorageLocationActivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "StorageLocation",
    "queryKeyHint": "queryKeys.storageLocation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StorageLocation",
    "queryKeyHint": "queryKeys.storageLocation.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for StorageLocation.activate. */
export const StorageLocationActivateLifecycle = [
  {
    "property": "status",
    "from": "inactive",
    "to": "active",
    "proven": true
  }
] as const;

// --- StorageLocation.deactivate ---
export interface StorageLocationDeactivateClientInput {
  reason: string;
}

export const StorageLocationDeactivateCapability = {
  capabilityId: "StorageLocation.deactivate",
  entity: "StorageLocation",
  command: "deactivate",
  route: "/api/manifest/StorageLocation/commands/deactivate",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["StorageLocationDeactivated"],
} as const;

/**
 * Build command input for StorageLocation.deactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStorageLocationDeactivateInput(client: StorageLocationDeactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StorageLocation.deactivate. */
export const StorageLocationDeactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "StorageLocation",
    "queryKeyHint": "queryKeys.storageLocation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StorageLocation",
    "queryKeyHint": "queryKeys.storageLocation.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for StorageLocation.deactivate. */
export const StorageLocationDeactivateLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "inactive",
    "proven": true
  }
] as const;

// --- StorageLocation.register ---
export interface StorageLocationRegisterClientInput {
  name: string;
  locationType?: string;
  temperatureZone?: string;
  minTemperature?: number;
  maxTemperature?: number;
  temperatureUnit?: string;
}

export const StorageLocationRegisterCapability = {
  capabilityId: "StorageLocation.register",
  entity: "StorageLocation",
  command: "register",
  route: "/api/manifest/StorageLocation/commands/register",
  instanceCommand: true,
  clientParameterNames: ["name","locationType","temperatureZone","minTemperature","maxTemperature","temperatureUnit"],
  serverParameterNames: [],
  emits: ["StorageLocationRegistered"],
} as const;

/**
 * Build command input for StorageLocation.register.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStorageLocationRegisterInput(client: StorageLocationRegisterClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StorageLocation.register. */
export const StorageLocationRegisterInvalidation = [
  {
    "kind": "entityList",
    "entity": "StorageLocation",
    "queryKeyHint": "queryKeys.storageLocation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StorageLocation",
    "queryKeyHint": "queryKeys.storageLocation.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- StorageLocation.reviseDetails ---
export interface StorageLocationReviseDetailsClientInput {
  name: string;
  locationType?: string;
  temperatureZone?: string;
  minTemperature?: number;
  maxTemperature?: number;
  temperatureUnit?: string;
}

export const StorageLocationReviseDetailsCapability = {
  capabilityId: "StorageLocation.reviseDetails",
  entity: "StorageLocation",
  command: "reviseDetails",
  route: "/api/manifest/StorageLocation/commands/reviseDetails",
  instanceCommand: true,
  clientParameterNames: ["name","locationType","temperatureZone","minTemperature","maxTemperature","temperatureUnit"],
  serverParameterNames: [],
  emits: ["StorageLocationDetailsRevised"],
} as const;

/**
 * Build command input for StorageLocation.reviseDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindStorageLocationReviseDetailsInput(client: StorageLocationReviseDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful StorageLocation.reviseDetails. */
export const StorageLocationReviseDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "StorageLocation",
    "queryKeyHint": "queryKeys.storageLocation.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "StorageLocation",
    "queryKeyHint": "queryKeys.storageLocation.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- TaxRate.define ---
export interface TaxRateDefineClientInput {
  name: string;
  /** Bounds: 1..100 */
  percentage: number;
  appliesToFood: boolean;
  appliesToService: boolean;
  appliesToRental: boolean;
}

export const TaxRateDefineCapability = {
  capabilityId: "TaxRate.define",
  entity: "TaxRate",
  command: "define",
  route: "/api/manifest/TaxRate/commands/define",
  instanceCommand: true,
  clientParameterNames: ["name","percentage","appliesToFood","appliesToService","appliesToRental"],
  serverParameterNames: [],
  emits: ["TaxRateDefined"],
} as const;

/**
 * Build command input for TaxRate.define.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTaxRateDefineInput(client: TaxRateDefineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TaxRate.define. */
export const TaxRateDefineInvalidation = [
  {
    "kind": "entityList",
    "entity": "TaxRate",
    "queryKeyHint": "queryKeys.taxRate.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TaxRate",
    "queryKeyHint": "queryKeys.taxRate.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- TaxRate.revise ---
export interface TaxRateReviseClientInput {
  name: string;
  /** Bounds: 1..100 */
  percentage: number;
  appliesToFood: boolean;
  appliesToService: boolean;
  appliesToRental: boolean;
}

export const TaxRateReviseCapability = {
  capabilityId: "TaxRate.revise",
  entity: "TaxRate",
  command: "revise",
  route: "/api/manifest/TaxRate/commands/revise",
  instanceCommand: true,
  clientParameterNames: ["name","percentage","appliesToFood","appliesToService","appliesToRental"],
  serverParameterNames: [],
  emits: ["TaxRateRevised"],
} as const;

/**
 * Build command input for TaxRate.revise.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTaxRateReviseInput(client: TaxRateReviseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TaxRate.revise. */
export const TaxRateReviseInvalidation = [
  {
    "kind": "entityList",
    "entity": "TaxRate",
    "queryKeyHint": "queryKeys.taxRate.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TaxRate",
    "queryKeyHint": "queryKeys.taxRate.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- TaxRate.setActive ---
export interface TaxRateSetActiveClientInput {
  active: boolean;
}

export const TaxRateSetActiveCapability = {
  capabilityId: "TaxRate.setActive",
  entity: "TaxRate",
  command: "setActive",
  route: "/api/manifest/TaxRate/commands/setActive",
  instanceCommand: true,
  clientParameterNames: ["active"],
  serverParameterNames: [],
  emits: ["TaxRateActivationChanged"],
} as const;

/**
 * Build command input for TaxRate.setActive.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTaxRateSetActiveInput(client: TaxRateSetActiveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TaxRate.setActive. */
export const TaxRateSetActiveInvalidation = [
  {
    "kind": "entityList",
    "entity": "TaxRate",
    "queryKeyHint": "queryKeys.taxRate.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TaxRate",
    "queryKeyHint": "queryKeys.taxRate.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- TimeOffRequest.approve ---
export interface TimeOffRequestApproveClientInput {
  responseNote?: string;
}

export const TimeOffRequestApproveCapability = {
  capabilityId: "TimeOffRequest.approve",
  entity: "TimeOffRequest",
  command: "approve",
  route: "/api/manifest/TimeOffRequest/commands/approve",
  instanceCommand: true,
  clientParameterNames: ["responseNote"],
  serverParameterNames: [],
  emits: ["TimeOffRequestApproved"],
} as const;

/**
 * Build command input for TimeOffRequest.approve.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTimeOffRequestApproveInput(client: TimeOffRequestApproveClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TimeOffRequest.approve. */
export const TimeOffRequestApproveInvalidation = [
  {
    "kind": "entityList",
    "entity": "TimeOffRequest",
    "queryKeyHint": "queryKeys.timeOffRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TimeOffRequest",
    "queryKeyHint": "queryKeys.timeOffRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for TimeOffRequest.approve. */
export const TimeOffRequestApproveLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "approved",
    "proven": true
  }
] as const;

// --- TimeOffRequest.decline ---
export interface TimeOffRequestDeclineClientInput {
  responseNote?: string;
}

export const TimeOffRequestDeclineCapability = {
  capabilityId: "TimeOffRequest.decline",
  entity: "TimeOffRequest",
  command: "decline",
  route: "/api/manifest/TimeOffRequest/commands/decline",
  instanceCommand: true,
  clientParameterNames: ["responseNote"],
  serverParameterNames: [],
  emits: ["TimeOffRequestDenied"],
} as const;

/**
 * Build command input for TimeOffRequest.decline.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTimeOffRequestDeclineInput(client: TimeOffRequestDeclineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TimeOffRequest.decline. */
export const TimeOffRequestDeclineInvalidation = [
  {
    "kind": "entityList",
    "entity": "TimeOffRequest",
    "queryKeyHint": "queryKeys.timeOffRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TimeOffRequest",
    "queryKeyHint": "queryKeys.timeOffRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for TimeOffRequest.decline. */
export const TimeOffRequestDeclineLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "denied",
    "proven": true
  }
] as const;

// --- TimeOffRequest.submit ---
export interface TimeOffRequestSubmitClientInput {
  personId: string;
  /** Must not be "". */
  startsAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  endsAt: string & { readonly __nonEmpty?: true };
  reason: string;
}

export const TimeOffRequestSubmitCapability = {
  capabilityId: "TimeOffRequest.submit",
  entity: "TimeOffRequest",
  command: "submit",
  route: "/api/manifest/TimeOffRequest/commands/submit",
  instanceCommand: true,
  clientParameterNames: ["personId","startsAt","endsAt","reason"],
  serverParameterNames: [],
  emits: ["TimeOffRequestSubmitted"],
} as const;

/**
 * Build command input for TimeOffRequest.submit.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTimeOffRequestSubmitInput(client: TimeOffRequestSubmitClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TimeOffRequest.submit. */
export const TimeOffRequestSubmitInvalidation = [
  {
    "kind": "entityList",
    "entity": "TimeOffRequest",
    "queryKeyHint": "queryKeys.timeOffRequest.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TimeOffRequest",
    "queryKeyHint": "queryKeys.timeOffRequest.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- TimeRecord.clockIn ---
export interface TimeRecordClockInClientInput {
  personId: string;
  shiftId?: string;
  eventId?: string;
  notes?: string;
}

export const TimeRecordClockInCapability = {
  capabilityId: "TimeRecord.clockIn",
  entity: "TimeRecord",
  command: "clockIn",
  route: "/api/manifest/TimeRecord/commands/clockIn",
  instanceCommand: true,
  clientParameterNames: ["personId","shiftId","eventId","notes"],
  serverParameterNames: [],
  emits: ["TimeRecordClockedIn"],
} as const;

/**
 * Build command input for TimeRecord.clockIn.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTimeRecordClockInInput(client: TimeRecordClockInClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TimeRecord.clockIn. */
export const TimeRecordClockInInvalidation = [
  {
    "kind": "entityList",
    "entity": "TimeRecord",
    "queryKeyHint": "queryKeys.timeRecord.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TimeRecord",
    "queryKeyHint": "queryKeys.timeRecord.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- TimeRecord.clockOut ---
export interface TimeRecordClockOutClientInput {
  /** Bounds: 0..∞ */
  breakMinutes?: number;
  notes?: string;
}

export const TimeRecordClockOutCapability = {
  capabilityId: "TimeRecord.clockOut",
  entity: "TimeRecord",
  command: "clockOut",
  route: "/api/manifest/TimeRecord/commands/clockOut",
  instanceCommand: true,
  clientParameterNames: ["breakMinutes","notes"],
  serverParameterNames: [],
  emits: ["TimeRecordClockedOut"],
} as const;

/**
 * Build command input for TimeRecord.clockOut.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTimeRecordClockOutInput(client: TimeRecordClockOutClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TimeRecord.clockOut. */
export const TimeRecordClockOutInvalidation = [
  {
    "kind": "entityList",
    "entity": "TimeRecord",
    "queryKeyHint": "queryKeys.timeRecord.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TimeRecord",
    "queryKeyHint": "queryKeys.timeRecord.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for TimeRecord.clockOut. */
export const TimeRecordClockOutLifecycle = [
  {
    "property": "status",
    "from": "open",
    "to": "closed",
    "proven": true
  }
] as const;

// --- TimeRecord.correct ---
export interface TimeRecordCorrectClientInput {
  /** Must not be "". */
  clockInAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  clockOutAt: string & { readonly __nonEmpty?: true };
  /** Bounds: 0..∞ */
  breakMinutes?: number;
  notes?: string;
}

export const TimeRecordCorrectCapability = {
  capabilityId: "TimeRecord.correct",
  entity: "TimeRecord",
  command: "correct",
  route: "/api/manifest/TimeRecord/commands/correct",
  instanceCommand: true,
  clientParameterNames: ["clockInAt","clockOutAt","breakMinutes","notes"],
  serverParameterNames: [],
  emits: ["TimeRecordCorrected"],
} as const;

/**
 * Build command input for TimeRecord.correct.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTimeRecordCorrectInput(client: TimeRecordCorrectClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TimeRecord.correct. */
export const TimeRecordCorrectInvalidation = [
  {
    "kind": "entityList",
    "entity": "TimeRecord",
    "queryKeyHint": "queryKeys.timeRecord.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TimeRecord",
    "queryKeyHint": "queryKeys.timeRecord.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for TimeRecord.correct. */
export const TimeRecordCorrectLifecycle = [
  {
    "property": "status",
    "from": "closed",
    "to": "corrected",
    "proven": true
  },
  {
    "property": "status",
    "from": "corrected",
    "to": "corrected",
    "proven": true
  }
] as const;

// --- TrainingCompletion.record ---
export interface TrainingCompletionRecordClientInput {
  personId: string;
  trainingModuleId: string;
  /** Must not be "". */
  completedAt: string & { readonly __nonEmpty?: true };
  /** Bounds: 0..100 */
  assessmentScore: number;
  notes?: string;
}

export const TrainingCompletionRecordCapability = {
  capabilityId: "TrainingCompletion.record",
  entity: "TrainingCompletion",
  command: "record",
  route: "/api/manifest/TrainingCompletion/commands/record",
  instanceCommand: true,
  clientParameterNames: ["personId","trainingModuleId","completedAt","assessmentScore","notes"],
  serverParameterNames: [],
  emits: ["TrainingCompleted"],
} as const;

/**
 * Build command input for TrainingCompletion.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTrainingCompletionRecordInput(client: TrainingCompletionRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TrainingCompletion.record. */
export const TrainingCompletionRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "TrainingCompletion",
    "queryKeyHint": "queryKeys.trainingCompletion.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TrainingCompletion",
    "queryKeyHint": "queryKeys.trainingCompletion.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- TrainingModule.define ---
export interface TrainingModuleDefineClientInput {
  name: string;
  /** Allowed: "food_safety" | "equipment_operation" | "service_standards" | "other" */
  category: "food_safety" | "equipment_operation" | "service_standards" | "other";
  /** Bounds: 0..100 */
  passingScore: number;
  description?: string;
}

export const TrainingModuleDefineCapability = {
  capabilityId: "TrainingModule.define",
  entity: "TrainingModule",
  command: "define",
  route: "/api/manifest/TrainingModule/commands/define",
  instanceCommand: true,
  clientParameterNames: ["name","category","passingScore","description"],
  serverParameterNames: [],
  emits: ["TrainingModuleDefined"],
} as const;

/**
 * Build command input for TrainingModule.define.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTrainingModuleDefineInput(client: TrainingModuleDefineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TrainingModule.define. */
export const TrainingModuleDefineInvalidation = [
  {
    "kind": "entityList",
    "entity": "TrainingModule",
    "queryKeyHint": "queryKeys.trainingModule.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TrainingModule",
    "queryKeyHint": "queryKeys.trainingModule.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for TrainingModule.define. */
export const TrainingModuleDefineLifecycle = [
  {
    "property": "status",
    "from": "retired",
    "to": "active",
    "proven": true
  }
] as const;

// --- TrainingModule.reactivate ---
export type TrainingModuleReactivateClientInput = Record<string, never>;

export const TrainingModuleReactivateCapability = {
  capabilityId: "TrainingModule.reactivate",
  entity: "TrainingModule",
  command: "reactivate",
  route: "/api/manifest/TrainingModule/commands/reactivate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["TrainingModuleReactivated"],
} as const;

/**
 * Build command input for TrainingModule.reactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTrainingModuleReactivateInput(client: TrainingModuleReactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TrainingModule.reactivate. */
export const TrainingModuleReactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "TrainingModule",
    "queryKeyHint": "queryKeys.trainingModule.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TrainingModule",
    "queryKeyHint": "queryKeys.trainingModule.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for TrainingModule.reactivate. */
export const TrainingModuleReactivateLifecycle = [
  {
    "property": "status",
    "from": "retired",
    "to": "active",
    "proven": true
  }
] as const;

// --- TrainingModule.retire ---
export type TrainingModuleRetireClientInput = Record<string, never>;

export const TrainingModuleRetireCapability = {
  capabilityId: "TrainingModule.retire",
  entity: "TrainingModule",
  command: "retire",
  route: "/api/manifest/TrainingModule/commands/retire",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["TrainingModuleRetired"],
} as const;

/**
 * Build command input for TrainingModule.retire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindTrainingModuleRetireInput(client: TrainingModuleRetireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful TrainingModule.retire. */
export const TrainingModuleRetireInvalidation = [
  {
    "kind": "entityList",
    "entity": "TrainingModule",
    "queryKeyHint": "queryKeys.trainingModule.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "TrainingModule",
    "queryKeyHint": "queryKeys.trainingModule.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for TrainingModule.retire. */
export const TrainingModuleRetireLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "retired",
    "proven": true
  }
] as const;

// --- Vehicle.register ---
export interface VehicleRegisterClientInput {
  make: string;
  model: string;
  registration: string;
  /** Allowed: "owned" | "leased" */
  ownership: "owned" | "leased";
  /** Bounds: 1..∞ */
  payloadCapacityKg: number;
  /** Allowed: "available" | "in_use" | "maintenance" | "out_of_service" | "retired" */
  operationalStatus: "available" | "in_use" | "maintenance" | "out_of_service" | "retired";
  statusNote?: string;
}

export const VehicleRegisterCapability = {
  capabilityId: "Vehicle.register",
  entity: "Vehicle",
  command: "register",
  route: "/api/manifest/Vehicle/commands/register",
  instanceCommand: true,
  clientParameterNames: ["make","model","registration","ownership","payloadCapacityKg","operationalStatus","statusNote"],
  serverParameterNames: [],
  emits: ["VehicleRegistered"],
} as const;

/**
 * Build command input for Vehicle.register.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVehicleRegisterInput(client: VehicleRegisterClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Vehicle.register. */
export const VehicleRegisterInvalidation = [
  {
    "kind": "entityList",
    "entity": "Vehicle",
    "queryKeyHint": "queryKeys.vehicle.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Vehicle",
    "queryKeyHint": "queryKeys.vehicle.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Vehicle.reviseDetails ---
export interface VehicleReviseDetailsClientInput {
  make: string;
  model: string;
  registration: string;
  /** Allowed: "owned" | "leased" */
  ownership: "owned" | "leased";
  /** Bounds: 1..∞ */
  payloadCapacityKg: number;
}

export const VehicleReviseDetailsCapability = {
  capabilityId: "Vehicle.reviseDetails",
  entity: "Vehicle",
  command: "reviseDetails",
  route: "/api/manifest/Vehicle/commands/reviseDetails",
  instanceCommand: true,
  clientParameterNames: ["make","model","registration","ownership","payloadCapacityKg"],
  serverParameterNames: [],
  emits: ["VehicleDetailsRevised"],
} as const;

/**
 * Build command input for Vehicle.reviseDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVehicleReviseDetailsInput(client: VehicleReviseDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Vehicle.reviseDetails. */
export const VehicleReviseDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Vehicle",
    "queryKeyHint": "queryKeys.vehicle.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Vehicle",
    "queryKeyHint": "queryKeys.vehicle.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Vehicle.updateOperationalStatus ---
export interface VehicleUpdateOperationalStatusClientInput {
  /** Allowed: "available" | "in_use" | "maintenance" | "out_of_service" | "retired" */
  operationalStatus: "available" | "in_use" | "maintenance" | "out_of_service" | "retired";
  statusNote?: string;
}

export const VehicleUpdateOperationalStatusCapability = {
  capabilityId: "Vehicle.updateOperationalStatus",
  entity: "Vehicle",
  command: "updateOperationalStatus",
  route: "/api/manifest/Vehicle/commands/updateOperationalStatus",
  instanceCommand: true,
  clientParameterNames: ["operationalStatus","statusNote"],
  serverParameterNames: [],
  emits: ["VehicleOperationalStatusUpdated"],
} as const;

/**
 * Build command input for Vehicle.updateOperationalStatus.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVehicleUpdateOperationalStatusInput(client: VehicleUpdateOperationalStatusClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Vehicle.updateOperationalStatus. */
export const VehicleUpdateOperationalStatusInvalidation = [
  {
    "kind": "entityList",
    "entity": "Vehicle",
    "queryKeyHint": "queryKeys.vehicle.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Vehicle",
    "queryKeyHint": "queryKeys.vehicle.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Vendor.onboard ---
export interface VendorOnboardClientInput {
  name: string;
  email?: string;
  phone?: string;
  addressLine1?: string;
  city?: string;
  region?: string;
  postalCode?: string;
  countryCode?: string;
  /** Bounds: 0..365 */
  paymentTermsDays?: number;
  notes?: string;
}

export const VendorOnboardCapability = {
  capabilityId: "Vendor.onboard",
  entity: "Vendor",
  command: "onboard",
  route: "/api/manifest/Vendor/commands/onboard",
  instanceCommand: true,
  clientParameterNames: ["name","email","phone","addressLine1","city","region","postalCode","countryCode","paymentTermsDays","notes"],
  serverParameterNames: [],
  emits: ["VendorOnboarded"],
} as const;

/**
 * Build command input for Vendor.onboard.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOnboardInput(client: VendorOnboardClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Vendor.onboard. */
export const VendorOnboardInvalidation = [
  {
    "kind": "entityList",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Vendor.reinstate ---
export type VendorReinstateClientInput = Record<string, never>;

export const VendorReinstateCapability = {
  capabilityId: "Vendor.reinstate",
  entity: "Vendor",
  command: "reinstate",
  route: "/api/manifest/Vendor/commands/reinstate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["VendorReinstated"],
} as const;

/**
 * Build command input for Vendor.reinstate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorReinstateInput(client: VendorReinstateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Vendor.reinstate. */
export const VendorReinstateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Vendor.reinstate. */
export const VendorReinstateLifecycle = [
  {
    "property": "status",
    "from": "suspended",
    "to": "active",
    "proven": true
  }
] as const;

// --- Vendor.suspend ---
export interface VendorSuspendClientInput {
  reason: string;
}

export const VendorSuspendCapability = {
  capabilityId: "Vendor.suspend",
  entity: "Vendor",
  command: "suspend",
  route: "/api/manifest/Vendor/commands/suspend",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["VendorSuspended"],
} as const;

/**
 * Build command input for Vendor.suspend.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorSuspendInput(client: VendorSuspendClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Vendor.suspend. */
export const VendorSuspendInvalidation = [
  {
    "kind": "entityList",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Vendor.suspend. */
export const VendorSuspendLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "suspended",
    "proven": true
  }
] as const;

// --- Vendor.terminate ---
export interface VendorTerminateClientInput {
  reason: string;
}

export const VendorTerminateCapability = {
  capabilityId: "Vendor.terminate",
  entity: "Vendor",
  command: "terminate",
  route: "/api/manifest/Vendor/commands/terminate",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["VendorTerminated"],
} as const;

/**
 * Build command input for Vendor.terminate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorTerminateInput(client: VendorTerminateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Vendor.terminate. */
export const VendorTerminateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Vendor.terminate. */
export const VendorTerminateLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "terminated",
    "proven": true
  },
  {
    "property": "status",
    "from": "suspended",
    "to": "terminated",
    "proven": true
  }
] as const;

// --- Vendor.updateDetails ---
export interface VendorUpdateDetailsClientInput {
  name: string;
  email?: string;
  phone?: string;
  addressLine1?: string;
  city?: string;
  region?: string;
  postalCode?: string;
  countryCode?: string;
  /** Bounds: 0..365 */
  paymentTermsDays?: number;
  notes?: string;
}

export const VendorUpdateDetailsCapability = {
  capabilityId: "Vendor.updateDetails",
  entity: "Vendor",
  command: "updateDetails",
  route: "/api/manifest/Vendor/commands/updateDetails",
  instanceCommand: true,
  clientParameterNames: ["name","email","phone","addressLine1","city","region","postalCode","countryCode","paymentTermsDays","notes"],
  serverParameterNames: [],
  emits: ["VendorDetailsUpdated"],
} as const;

/**
 * Build command input for Vendor.updateDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorUpdateDetailsInput(client: VendorUpdateDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Vendor.updateDetails. */
export const VendorUpdateDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Vendor",
    "queryKeyHint": "queryKeys.vendor.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrder.cancel ---
export interface VendorOrderCancelClientInput {
  reason: string;
}

export const VendorOrderCancelCapability = {
  capabilityId: "VendorOrder.cancel",
  entity: "VendorOrder",
  command: "cancel",
  route: "/api/manifest/VendorOrder/commands/cancel",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["VendorOrderCancelled"],
} as const;

/**
 * Build command input for VendorOrder.cancel.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderCancelInput(client: VendorOrderCancelClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrder.cancel. */
export const VendorOrderCancelInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for VendorOrder.cancel. */
export const VendorOrderCancelLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "submitted",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "confirmed",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "partially_received",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- VendorOrder.confirm ---
export type VendorOrderConfirmClientInput = Record<string, never>;

export const VendorOrderConfirmCapability = {
  capabilityId: "VendorOrder.confirm",
  entity: "VendorOrder",
  command: "confirm",
  route: "/api/manifest/VendorOrder/commands/confirm",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["VendorOrderConfirmed"],
} as const;

/**
 * Build command input for VendorOrder.confirm.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderConfirmInput(client: VendorOrderConfirmClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrder.confirm. */
export const VendorOrderConfirmInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for VendorOrder.confirm. */
export const VendorOrderConfirmLifecycle = [
  {
    "property": "status",
    "from": "submitted",
    "to": "confirmed",
    "proven": true
  }
] as const;

// --- VendorOrder.ensureWeeklyDraft ---
export interface VendorOrderEnsureWeeklyDraftClientInput {
  vendorId: string;
  /** Must not be "". */
  sourceRangeStart: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  sourceRangeEnd: string & { readonly __nonEmpty?: true };
  purchaseNeedId: string;
  ingredientDemandId: string;
  ingredientId: string;
  requiredQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
}

export const VendorOrderEnsureWeeklyDraftCapability = {
  capabilityId: "VendorOrder.ensureWeeklyDraft",
  entity: "VendorOrder",
  command: "ensureWeeklyDraft",
  route: "/api/manifest/VendorOrder/commands/ensureWeeklyDraft",
  instanceCommand: true,
  clientParameterNames: ["vendorId","sourceRangeStart","sourceRangeEnd","purchaseNeedId","ingredientDemandId","ingredientId","requiredQuantity","unit"],
  serverParameterNames: [],
  emits: ["VendorOrderWeeklyDraftEnsured"],
} as const;

/**
 * Build command input for VendorOrder.ensureWeeklyDraft.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderEnsureWeeklyDraftInput(client: VendorOrderEnsureWeeklyDraftClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrder.ensureWeeklyDraft. */
export const VendorOrderEnsureWeeklyDraftInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrder.markPartiallyReceived ---
export type VendorOrderMarkPartiallyReceivedClientInput = Record<string, never>;

export const VendorOrderMarkPartiallyReceivedCapability = {
  capabilityId: "VendorOrder.markPartiallyReceived",
  entity: "VendorOrder",
  command: "markPartiallyReceived",
  route: "/api/manifest/VendorOrder/commands/markPartiallyReceived",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["VendorOrderPartiallyReceived"],
} as const;

/**
 * Build command input for VendorOrder.markPartiallyReceived.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderMarkPartiallyReceivedInput(client: VendorOrderMarkPartiallyReceivedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrder.markPartiallyReceived. */
export const VendorOrderMarkPartiallyReceivedInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for VendorOrder.markPartiallyReceived. */
export const VendorOrderMarkPartiallyReceivedLifecycle = [
  {
    "property": "status",
    "from": "confirmed",
    "to": "partially_received",
    "proven": true
  }
] as const;

// --- VendorOrder.markReceived ---
export type VendorOrderMarkReceivedClientInput = Record<string, never>;

export const VendorOrderMarkReceivedCapability = {
  capabilityId: "VendorOrder.markReceived",
  entity: "VendorOrder",
  command: "markReceived",
  route: "/api/manifest/VendorOrder/commands/markReceived",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["VendorOrderReceived"],
} as const;

/**
 * Build command input for VendorOrder.markReceived.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderMarkReceivedInput(client: VendorOrderMarkReceivedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrder.markReceived. */
export const VendorOrderMarkReceivedInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for VendorOrder.markReceived. */
export const VendorOrderMarkReceivedLifecycle = [
  {
    "property": "status",
    "from": "confirmed",
    "to": "received",
    "proven": true
  },
  {
    "property": "status",
    "from": "partially_received",
    "to": "received",
    "proven": true
  }
] as const;

// --- VendorOrder.open ---
export interface VendorOrderOpenClientInput {
  vendorId: string;
  eventId?: string;
  sourceRangeStart?: string;
  sourceRangeEnd?: string;
  orderNumber?: string;
  notes?: string;
}

export const VendorOrderOpenCapability = {
  capabilityId: "VendorOrder.open",
  entity: "VendorOrder",
  command: "open",
  route: "/api/manifest/VendorOrder/commands/open",
  instanceCommand: true,
  clientParameterNames: ["vendorId","eventId","sourceRangeStart","sourceRangeEnd","orderNumber","notes"],
  serverParameterNames: [],
  emits: ["VendorOrderOpened"],
} as const;

/**
 * Build command input for VendorOrder.open.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderOpenInput(client: VendorOrderOpenClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrder.open. */
export const VendorOrderOpenInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrder.submit ---
export type VendorOrderSubmitClientInput = Record<string, never>;

export const VendorOrderSubmitCapability = {
  capabilityId: "VendorOrder.submit",
  entity: "VendorOrder",
  command: "submit",
  route: "/api/manifest/VendorOrder/commands/submit",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["VendorOrderSubmitted"],
} as const;

/**
 * Build command input for VendorOrder.submit.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderSubmitInput(client: VendorOrderSubmitClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrder.submit. */
export const VendorOrderSubmitInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for VendorOrder.submit. */
export const VendorOrderSubmitLifecycle = [
  {
    "property": "status",
    "from": "draft",
    "to": "submitted",
    "proven": true
  }
] as const;

// --- VendorOrder.updateTotals ---
export interface VendorOrderUpdateTotalsClientInput {
  /** Bounds: 0..∞ */
  subtotal: number;
  /** Bounds: 0..∞ */
  taxAmount: number;
  /** Bounds: 0..∞ */
  shippingAmount: number;
}

export const VendorOrderUpdateTotalsCapability = {
  capabilityId: "VendorOrder.updateTotals",
  entity: "VendorOrder",
  command: "updateTotals",
  route: "/api/manifest/VendorOrder/commands/updateTotals",
  instanceCommand: true,
  clientParameterNames: ["subtotal","taxAmount","shippingAmount"],
  serverParameterNames: [],
  emits: ["VendorOrderTotalsUpdated"],
} as const;

/**
 * Build command input for VendorOrder.updateTotals.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderUpdateTotalsInput(client: VendorOrderUpdateTotalsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrder.updateTotals. */
export const VendorOrderUpdateTotalsInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrder",
    "queryKeyHint": "queryKeys.vendorOrder.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrderLine.addLine ---
export interface VendorOrderLineAddLineClientInput {
  vendorOrderId: string;
  ingredientId: string;
  /** Bounds: 1..∞ */
  orderedQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Bounds: 0..∞ */
  unitCost: number;
  ingredientDemandId?: string;
  locationId?: string;
}

export const VendorOrderLineAddLineCapability = {
  capabilityId: "VendorOrderLine.addLine",
  entity: "VendorOrderLine",
  command: "addLine",
  route: "/api/manifest/VendorOrderLine/commands/addLine",
  instanceCommand: true,
  clientParameterNames: ["vendorOrderId","ingredientId","orderedQuantity","unit","unitCost","ingredientDemandId","locationId"],
  serverParameterNames: [],
  emits: ["VendorOrderLineAdded"],
} as const;

/**
 * Build command input for VendorOrderLine.addLine.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderLineAddLineInput(client: VendorOrderLineAddLineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrderLine.addLine. */
export const VendorOrderLineAddLineInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for VendorOrderLine.addLine. */
export const VendorOrderLineAddLineLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "added",
    "proven": true
  }
] as const;

// --- VendorOrderLine.cancelLine ---
export interface VendorOrderLineCancelLineClientInput {
  reason: string;
}

export const VendorOrderLineCancelLineCapability = {
  capabilityId: "VendorOrderLine.cancelLine",
  entity: "VendorOrderLine",
  command: "cancelLine",
  route: "/api/manifest/VendorOrderLine/commands/cancelLine",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["VendorOrderLineCancelled"],
} as const;

/**
 * Build command input for VendorOrderLine.cancelLine.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderLineCancelLineInput(client: VendorOrderLineCancelLineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrderLine.cancelLine. */
export const VendorOrderLineCancelLineInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for VendorOrderLine.cancelLine. */
export const VendorOrderLineCancelLineLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "added",
    "to": "cancelled",
    "proven": true
  },
  {
    "property": "status",
    "from": "receiving",
    "to": "cancelled",
    "proven": true
  }
] as const;

// --- VendorOrderLine.ensureWeeklyLine ---
export interface VendorOrderLineEnsureWeeklyLineClientInput {
  vendorOrderId: string;
  ingredientId: string;
  weekNeed: number;
  onHand: number;
  /** Bounds: 1..∞ */
  contributionQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  unitCost: number;
  purchaseNeedId: string;
  ingredientDemandId: string;
}

export const VendorOrderLineEnsureWeeklyLineCapability = {
  capabilityId: "VendorOrderLine.ensureWeeklyLine",
  entity: "VendorOrderLine",
  command: "ensureWeeklyLine",
  route: "/api/manifest/VendorOrderLine/commands/ensureWeeklyLine",
  instanceCommand: true,
  clientParameterNames: ["vendorOrderId","ingredientId","weekNeed","onHand","contributionQuantity","unit","unitCost","purchaseNeedId","ingredientDemandId"],
  serverParameterNames: [],
  emits: ["VendorOrderLineWeeklyEnsured"],
} as const;

/**
 * Build command input for VendorOrderLine.ensureWeeklyLine.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderLineEnsureWeeklyLineInput(client: VendorOrderLineEnsureWeeklyLineClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrderLine.ensureWeeklyLine. */
export const VendorOrderLineEnsureWeeklyLineInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrderLine.recordReceipt ---
export interface VendorOrderLineRecordReceiptClientInput {
  /** Bounds: 1..∞ */
  quantity: number;
  locationId: string;
  /** Bounds: 0..∞ */
  unitPrice: number;
  supplierLotNumber: string;
  /** Bounds: 0..∞ */
  discrepancyQuantity?: number;
  discrepancyNotes?: string;
}

export const VendorOrderLineRecordReceiptCapability = {
  capabilityId: "VendorOrderLine.recordReceipt",
  entity: "VendorOrderLine",
  command: "recordReceipt",
  route: "/api/manifest/VendorOrderLine/commands/recordReceipt",
  instanceCommand: true,
  clientParameterNames: ["quantity","locationId","unitPrice","supplierLotNumber","discrepancyQuantity","discrepancyNotes"],
  serverParameterNames: [],
  emits: ["VendorOrderLineReceived"],
} as const;

/**
 * Build command input for VendorOrderLine.recordReceipt.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderLineRecordReceiptInput(client: VendorOrderLineRecordReceiptClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrderLine.recordReceipt. */
export const VendorOrderLineRecordReceiptInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrderLine.reviseQuantity ---
export interface VendorOrderLineReviseQuantityClientInput {
  /** Bounds: 1..∞ */
  orderedQuantity: number;
  /** Bounds: 0..∞ */
  unitCost?: number;
}

export const VendorOrderLineReviseQuantityCapability = {
  capabilityId: "VendorOrderLine.reviseQuantity",
  entity: "VendorOrderLine",
  command: "reviseQuantity",
  route: "/api/manifest/VendorOrderLine/commands/reviseQuantity",
  instanceCommand: true,
  clientParameterNames: ["orderedQuantity","unitCost"],
  serverParameterNames: [],
  emits: ["VendorOrderLineQuantityRevised"],
} as const;

/**
 * Build command input for VendorOrderLine.reviseQuantity.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderLineReviseQuantityInput(client: VendorOrderLineReviseQuantityClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrderLine.reviseQuantity. */
export const VendorOrderLineReviseQuantityInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrderLine",
    "queryKeyHint": "queryKeys.vendorOrderLine.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrderLineDemand.link ---
export interface VendorOrderLineDemandLinkClientInput {
  vendorOrderLineId: string;
  ingredientDemandId: string;
  vendorOrderId: string;
  /** Bounds: 1..∞ */
  contributionQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
}

export const VendorOrderLineDemandLinkCapability = {
  capabilityId: "VendorOrderLineDemand.link",
  entity: "VendorOrderLineDemand",
  command: "link",
  route: "/api/manifest/VendorOrderLineDemand/commands/link",
  instanceCommand: true,
  clientParameterNames: ["vendorOrderLineId","ingredientDemandId","vendorOrderId","contributionQuantity","unit"],
  serverParameterNames: [],
  emits: ["VendorOrderLineDemandLinked"],
} as const;

/**
 * Build command input for VendorOrderLineDemand.link.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderLineDemandLinkInput(client: VendorOrderLineDemandLinkClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrderLineDemand.link. */
export const VendorOrderLineDemandLinkInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrderLineDemand",
    "queryKeyHint": "queryKeys.vendorOrderLineDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrderLineDemand",
    "queryKeyHint": "queryKeys.vendorOrderLineDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrderLineDemand.retire ---
export interface VendorOrderLineDemandRetireClientInput {
  reason: string;
}

export const VendorOrderLineDemandRetireCapability = {
  capabilityId: "VendorOrderLineDemand.retire",
  entity: "VendorOrderLineDemand",
  command: "retire",
  route: "/api/manifest/VendorOrderLineDemand/commands/retire",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["VendorOrderLineDemandRetired"],
} as const;

/**
 * Build command input for VendorOrderLineDemand.retire.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderLineDemandRetireInput(client: VendorOrderLineDemandRetireClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrderLineDemand.retire. */
export const VendorOrderLineDemandRetireInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrderLineDemand",
    "queryKeyHint": "queryKeys.vendorOrderLineDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrderLineDemand",
    "queryKeyHint": "queryKeys.vendorOrderLineDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- VendorOrderLineDemand.revise ---
export interface VendorOrderLineDemandReviseClientInput {
  /** Bounds: 1..∞ */
  contributionQuantity: number;
}

export const VendorOrderLineDemandReviseCapability = {
  capabilityId: "VendorOrderLineDemand.revise",
  entity: "VendorOrderLineDemand",
  command: "revise",
  route: "/api/manifest/VendorOrderLineDemand/commands/revise",
  instanceCommand: true,
  clientParameterNames: ["contributionQuantity"],
  serverParameterNames: [],
  emits: ["VendorOrderLineDemandRevised"],
} as const;

/**
 * Build command input for VendorOrderLineDemand.revise.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVendorOrderLineDemandReviseInput(client: VendorOrderLineDemandReviseClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful VendorOrderLineDemand.revise. */
export const VendorOrderLineDemandReviseInvalidation = [
  {
    "kind": "entityList",
    "entity": "VendorOrderLineDemand",
    "queryKeyHint": "queryKeys.vendorOrderLineDemand.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "VendorOrderLineDemand",
    "queryKeyHint": "queryKeys.vendorOrderLineDemand.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Venue.activate ---
export type VenueActivateClientInput = Record<string, never>;

export const VenueActivateCapability = {
  capabilityId: "Venue.activate",
  entity: "Venue",
  command: "activate",
  route: "/api/manifest/Venue/commands/activate",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["VenueActivated"],
} as const;

/**
 * Build command input for Venue.activate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVenueActivateInput(client: VenueActivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Venue.activate. */
export const VenueActivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Venue.activate. */
export const VenueActivateLifecycle = [
  {
    "property": "status",
    "from": "inactive",
    "to": "active",
    "proven": true
  }
] as const;

// --- Venue.changeCapacity ---
export interface VenueChangeCapacityClientInput {
  /** Bounds: 0..∞ */
  capacity: number;
}

export const VenueChangeCapacityCapability = {
  capabilityId: "Venue.changeCapacity",
  entity: "Venue",
  command: "changeCapacity",
  route: "/api/manifest/Venue/commands/changeCapacity",
  instanceCommand: true,
  clientParameterNames: ["capacity"],
  serverParameterNames: [],
  emits: ["VenueCapacityChanged"],
} as const;

/**
 * Build command input for Venue.changeCapacity.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVenueChangeCapacityInput(client: VenueChangeCapacityClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Venue.changeCapacity. */
export const VenueChangeCapacityInvalidation = [
  {
    "kind": "entityList",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Venue.deactivate ---
export interface VenueDeactivateClientInput {
  reason: string;
}

export const VenueDeactivateCapability = {
  capabilityId: "Venue.deactivate",
  entity: "Venue",
  command: "deactivate",
  route: "/api/manifest/Venue/commands/deactivate",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["VenueDeactivated"],
} as const;

/**
 * Build command input for Venue.deactivate.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVenueDeactivateInput(client: VenueDeactivateClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Venue.deactivate. */
export const VenueDeactivateInvalidation = [
  {
    "kind": "entityList",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for Venue.deactivate. */
export const VenueDeactivateLifecycle = [
  {
    "property": "status",
    "from": "active",
    "to": "inactive",
    "proven": true
  }
] as const;

// --- Venue.register ---
export interface VenueRegisterClientInput {
  name: string;
  /** Allowed: "client_site" | "banquet_hall" | "outdoor" | "office" | "private_home" | "other" */
  venueType: "client_site" | "banquet_hall" | "outdoor" | "office" | "private_home" | "other";
  /** Bounds: 0..∞ */
  capacity: number;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  region?: string;
  postalCode?: string;
  countryCode?: string;
  contactName?: string;
  contactEmail?: string;
  contactPhone?: string;
  accessNotes?: string;
  cateringNotes?: string;
}

export const VenueRegisterCapability = {
  capabilityId: "Venue.register",
  entity: "Venue",
  command: "register",
  route: "/api/manifest/Venue/commands/register",
  instanceCommand: true,
  clientParameterNames: ["name","venueType","capacity","addressLine1","addressLine2","city","region","postalCode","countryCode","contactName","contactEmail","contactPhone","accessNotes","cateringNotes"],
  serverParameterNames: [],
  emits: ["VenueRegistered"],
} as const;

/**
 * Build command input for Venue.register.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVenueRegisterInput(client: VenueRegisterClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Venue.register. */
export const VenueRegisterInvalidation = [
  {
    "kind": "entityList",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- Venue.updateDetails ---
export interface VenueUpdateDetailsClientInput {
  name: string;
  /** Allowed: "client_site" | "banquet_hall" | "outdoor" | "office" | "private_home" | "other" */
  venueType: "client_site" | "banquet_hall" | "outdoor" | "office" | "private_home" | "other";
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  region?: string;
  postalCode?: string;
  countryCode?: string;
  contactName?: string;
  contactEmail?: string;
  contactPhone?: string;
  accessNotes?: string;
  cateringNotes?: string;
}

export const VenueUpdateDetailsCapability = {
  capabilityId: "Venue.updateDetails",
  entity: "Venue",
  command: "updateDetails",
  route: "/api/manifest/Venue/commands/updateDetails",
  instanceCommand: true,
  clientParameterNames: ["name","venueType","addressLine1","addressLine2","city","region","postalCode","countryCode","contactName","contactEmail","contactPhone","accessNotes","cateringNotes"],
  serverParameterNames: [],
  emits: ["VenueDetailsUpdated"],
} as const;

/**
 * Build command input for Venue.updateDetails.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindVenueUpdateDetailsInput(client: VenueUpdateDetailsClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful Venue.updateDetails. */
export const VenueUpdateDetailsInvalidation = [
  {
    "kind": "entityList",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "Venue",
    "queryKeyHint": "queryKeys.venue.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- WasteRecord.record ---
export interface WasteRecordRecordClientInput {
  ingredientId: string;
  locationId: string;
  /** Bounds: 1..∞ */
  quantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Allowed: "spoilage" | "prep_error" | "overproduction" | "other" */
  reason: "spoilage" | "prep_error" | "overproduction" | "other";
  eventId?: string;
  inventoryItemId?: string;
  /** Bounds: 0..∞ */
  unitCost?: number;
  notes?: string;
}

export const WasteRecordRecordCapability = {
  capabilityId: "WasteRecord.record",
  entity: "WasteRecord",
  command: "record",
  route: "/api/manifest/WasteRecord/commands/record",
  instanceCommand: true,
  clientParameterNames: ["ingredientId","locationId","quantity","unit","reason","eventId","inventoryItemId","unitCost","notes"],
  serverParameterNames: [],
  emits: ["WasteRecorded"],
} as const;

/**
 * Build command input for WasteRecord.record.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindWasteRecordRecordInput(client: WasteRecordRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful WasteRecord.record. */
export const WasteRecordRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "WasteRecord",
    "queryKeyHint": "queryKeys.wasteRecord.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "WasteRecord",
    "queryKeyHint": "queryKeys.wasteRecord.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for WasteRecord.record. */
export const WasteRecordRecordLifecycle = [
  {
    "property": "status",
    "from": "pending",
    "to": "recorded",
    "proven": true
  }
] as const;

// --- WasteRecord.voidRecord ---
export interface WasteRecordVoidRecordClientInput {
  reason: string;
}

export const WasteRecordVoidRecordCapability = {
  capabilityId: "WasteRecord.voidRecord",
  entity: "WasteRecord",
  command: "voidRecord",
  route: "/api/manifest/WasteRecord/commands/voidRecord",
  instanceCommand: true,
  clientParameterNames: ["reason"],
  serverParameterNames: [],
  emits: ["WasteVoided"],
} as const;

/**
 * Build command input for WasteRecord.voidRecord.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindWasteRecordVoidRecordInput(client: WasteRecordVoidRecordClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful WasteRecord.voidRecord. */
export const WasteRecordVoidRecordInvalidation = [
  {
    "kind": "entityList",
    "entity": "WasteRecord",
    "queryKeyHint": "queryKeys.wasteRecord.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "WasteRecord",
    "queryKeyHint": "queryKeys.wasteRecord.detail(id)",
    "label": "entity detail"
  }
] as const;

/** Proven lifecycle transitions for WasteRecord.voidRecord. */
export const WasteRecordVoidRecordLifecycle = [
  {
    "property": "status",
    "from": "recorded",
    "to": "voided",
    "proven": true
  }
] as const;

// --- WeeklyPurchasingConfig.configure ---
export interface WeeklyPurchasingConfigConfigureClientInput {
  defaultVendorId: string;
}

export const WeeklyPurchasingConfigConfigureCapability = {
  capabilityId: "WeeklyPurchasingConfig.configure",
  entity: "WeeklyPurchasingConfig",
  command: "configure",
  route: "/api/manifest/WeeklyPurchasingConfig/commands/configure",
  instanceCommand: true,
  clientParameterNames: ["defaultVendorId"],
  serverParameterNames: [],
  emits: [],
} as const;

/**
 * Build command input for WeeklyPurchasingConfig.configure.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindWeeklyPurchasingConfigConfigureInput(client: WeeklyPurchasingConfigConfigureClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful WeeklyPurchasingConfig.configure. */
export const WeeklyPurchasingConfigConfigureInvalidation = [
  {
    "kind": "entityList",
    "entity": "WeeklyPurchasingConfig",
    "queryKeyHint": "queryKeys.weeklyPurchasingConfig.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "WeeklyPurchasingConfig",
    "queryKeyHint": "queryKeys.weeklyPurchasingConfig.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- WeeklyPurchasingConfig.routeNeed ---
export interface WeeklyPurchasingConfigRouteNeedClientInput {
  purchaseNeedId: string;
  eventId: string;
  ingredientDemandId: string;
  ingredientId: string;
  requiredQuantity: number;
  /** Allowed: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion" */
  unit: "each" | "gram" | "kilogram" | "ounce" | "pound" | "milliliter" | "liter" | "teaspoon" | "tablespoon" | "cup" | "pint" | "quart" | "gallon" | "portion";
  /** Must not be "". */
  purchasingWeekStart: string & { readonly __nonEmpty?: true };
  preferredVendorId?: string;
}

export const WeeklyPurchasingConfigRouteNeedCapability = {
  capabilityId: "WeeklyPurchasingConfig.routeNeed",
  entity: "WeeklyPurchasingConfig",
  command: "routeNeed",
  route: "/api/manifest/WeeklyPurchasingConfig/commands/routeNeed",
  instanceCommand: true,
  clientParameterNames: ["purchaseNeedId","eventId","ingredientDemandId","ingredientId","requiredQuantity","unit","purchasingWeekStart","preferredVendorId"],
  serverParameterNames: [],
  emits: ["PurchaseNeedReadyForWeeklyDraft"],
} as const;

/**
 * Build command input for WeeklyPurchasingConfig.routeNeed.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindWeeklyPurchasingConfigRouteNeedInput(client: WeeklyPurchasingConfigRouteNeedClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful WeeklyPurchasingConfig.routeNeed. */
export const WeeklyPurchasingConfigRouteNeedInvalidation = [
  {
    "kind": "entityList",
    "entity": "WeeklyPurchasingConfig",
    "queryKeyHint": "queryKeys.weeklyPurchasingConfig.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "WeeklyPurchasingConfig",
    "queryKeyHint": "queryKeys.weeklyPurchasingConfig.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- WeeklyScheduleNotice.acknowledge ---
export type WeeklyScheduleNoticeAcknowledgeClientInput = Record<string, never>;

export const WeeklyScheduleNoticeAcknowledgeCapability = {
  capabilityId: "WeeklyScheduleNotice.acknowledge",
  entity: "WeeklyScheduleNotice",
  command: "acknowledge",
  route: "/api/manifest/WeeklyScheduleNotice/commands/acknowledge",
  instanceCommand: true,
  clientParameterNames: [],
  serverParameterNames: [],
  emits: ["WeeklyScheduleAcknowledged"],
} as const;

/**
 * Build command input for WeeklyScheduleNotice.acknowledge.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindWeeklyScheduleNoticeAcknowledgeInput(client: WeeklyScheduleNoticeAcknowledgeClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful WeeklyScheduleNotice.acknowledge. */
export const WeeklyScheduleNoticeAcknowledgeInvalidation = [
  {
    "kind": "entityList",
    "entity": "WeeklyScheduleNotice",
    "queryKeyHint": "queryKeys.weeklyScheduleNotice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "WeeklyScheduleNotice",
    "queryKeyHint": "queryKeys.weeklyScheduleNotice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- WeeklyScheduleNotice.publishSchedule ---
export interface WeeklyScheduleNoticePublishScheduleClientInput {
  personId: string;
  recipientAuthSubjectId?: string;
  /** Must not be "". */
  weekStartsAt: string & { readonly __nonEmpty?: true };
  /** Must not be "". */
  weekEndsAt: string & { readonly __nonEmpty?: true };
  /** Bounds: 1..∞ */
  shiftCount: number;
  shiftSummary: string;
}

export const WeeklyScheduleNoticePublishScheduleCapability = {
  capabilityId: "WeeklyScheduleNotice.publishSchedule",
  entity: "WeeklyScheduleNotice",
  command: "publishSchedule",
  route: "/api/manifest/WeeklyScheduleNotice/commands/publishSchedule",
  instanceCommand: true,
  clientParameterNames: ["personId","recipientAuthSubjectId","weekStartsAt","weekEndsAt","shiftCount","shiftSummary"],
  serverParameterNames: [],
  emits: ["WeeklySchedulePublished"],
} as const;

/**
 * Build command input for WeeklyScheduleNotice.publishSchedule.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindWeeklyScheduleNoticePublishScheduleInput(client: WeeklyScheduleNoticePublishScheduleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful WeeklyScheduleNotice.publishSchedule. */
export const WeeklyScheduleNoticePublishScheduleInvalidation = [
  {
    "kind": "entityList",
    "entity": "WeeklyScheduleNotice",
    "queryKeyHint": "queryKeys.weeklyScheduleNotice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "WeeklyScheduleNotice",
    "queryKeyHint": "queryKeys.weeklyScheduleNotice.detail(id)",
    "label": "entity detail"
  }
] as const;

// --- WeeklyScheduleNotice.republishSchedule ---
export interface WeeklyScheduleNoticeRepublishScheduleClientInput {
  recipientAuthSubjectId?: string;
  /** Bounds: 1..∞ */
  shiftCount: number;
  shiftSummary: string;
}

export const WeeklyScheduleNoticeRepublishScheduleCapability = {
  capabilityId: "WeeklyScheduleNotice.republishSchedule",
  entity: "WeeklyScheduleNotice",
  command: "republishSchedule",
  route: "/api/manifest/WeeklyScheduleNotice/commands/republishSchedule",
  instanceCommand: true,
  clientParameterNames: ["recipientAuthSubjectId","shiftCount","shiftSummary"],
  serverParameterNames: [],
  emits: ["WeeklyScheduleRepublished"],
} as const;

/**
 * Build command input for WeeklyScheduleNotice.republishSchedule.
 * Client fields only; server-owned fields are injected separately.
 */
export function bindWeeklyScheduleNoticeRepublishScheduleInput(client: WeeklyScheduleNoticeRepublishScheduleClientInput): Record<string, unknown> {
  return { ...client };
}

/** Invalidation targets after a successful WeeklyScheduleNotice.republishSchedule. */
export const WeeklyScheduleNoticeRepublishScheduleInvalidation = [
  {
    "kind": "entityList",
    "entity": "WeeklyScheduleNotice",
    "queryKeyHint": "queryKeys.weeklyScheduleNotice.lists()",
    "label": "entity list"
  },
  {
    "kind": "entityDetail",
    "entity": "WeeklyScheduleNotice",
    "queryKeyHint": "queryKeys.weeklyScheduleNotice.detail(id)",
    "label": "entity detail"
  }
] as const;

/** All capability ids in this contract (sorted). */
export const ALL_CAPABILITY_IDS = [
  "Attachment.attach",
  "Attachment.remove",
  "AvailabilityWindow.declare",
  "AvailabilityWindow.withdraw",
  "Client.archive",
  "Client.assignOwner",
  "Client.changeBillingProfile",
  "Client.changeContact",
  "Client.markMerged",
  "Client.reactivate",
  "Client.register",
  "Client.stageClientMerge",
  "ClientCommunication.record",
  "ClientContact.add",
  "ClientContact.reassignClient",
  "ClientContact.remove",
  "ClientContact.setPrimary",
  "ClientContact.stageClientMerge",
  "ClientContact.updateDetails",
  "ClientMerge.merge",
  "Contract.draft",
  "Contract.expire",
  "Contract.markViewed",
  "Contract.markVoided",
  "Contract.reassignClient",
  "Contract.send",
  "Contract.sign",
  "Contract.stageClientMerge",
  "CorrectiveAction.close",
  "CorrectiveAction.open",
  "CreditMemo.issue",
  "CreditMemo.reassignClient",
  "CreditMemo.stageClientMerge",
  "Delivery.cancel",
  "Delivery.confirmDelivery",
  "Delivery.markFailed",
  "Delivery.schedule",
  "Delivery.startTransit",
  "Dish.classifyAllergens",
  "Dish.introduce",
  "Dish.reinstate",
  "Dish.retire",
  "Dish.reviseDetails",
  "Dish.updatePortioning",
  "DishRecipe.attach",
  "DishRecipe.detach",
  "DishTask.add",
  "DishTask.retire",
  "DishTask.revise",
  "EmailNotificationSubscription.configure",
  "EmailNotificationSubscription.updateSubscriptions",
  "Equipment.reactivate",
  "Equipment.recount",
  "Equipment.register",
  "Equipment.retire",
  "Equipment.reviseDetails",
  "Equipment.updateCondition",
  "EquipmentMaintenanceTask.applyService",
  "EquipmentMaintenanceTask.schedule",
  "EquipmentReservation.cancel",
  "EquipmentReservation.checkOut",
  "EquipmentReservation.markReturned",
  "EquipmentServiceEntry.record",
  "Event.approve",
  "Event.assignOwner",
  "Event.beginExecution",
  "Event.cancel",
  "Event.changeHeadcount",
  "Event.changePricing",
  "Event.changePrimaryContact",
  "Event.changeRequirements",
  "Event.changeVenue",
  "Event.closeOut",
  "Event.complete",
  "Event.configureRecurrence",
  "Event.planEngagement",
  "Event.reassignClient",
  "Event.reschedule",
  "Event.returnToPlanning",
  "Event.stageClientMerge",
  "Event.stopRecurrence",
  "Event.submitForApproval",
  "EventAllergenCheck.record",
  "EventAssignment.assign",
  "EventAssignment.checkIn",
  "EventAssignment.checkOut",
  "EventAssignment.confirm",
  "EventAssignment.markNoShow",
  "EventAssignment.unassign",
  "EventCloseout.capture",
  "EventCloseout.finalize",
  "EventDish.addToEvent",
  "EventDish.adjustServings",
  "EventDish.changeCourse",
  "EventDish.remove",
  "EventDish.updateInstructions",
  "EventDishRecipeSeed.seed",
  "EventGuest.assignTable",
  "EventGuest.checkIn",
  "EventGuest.invite",
  "EventGuest.rsvpConfirm",
  "EventGuest.rsvpDecline",
  "EventGuest.withdraw",
  "EventIngredientContribution.record",
  "EventIngredientContribution.retire",
  "EventIngredientContribution.revise",
  "EventTemplate.archive",
  "EventTemplate.define",
  "EventTemplate.reactivate",
  "EventTemplate.revise",
  "EventTimelineActivity.adjust",
  "EventTimelineActivity.remove",
  "EventTimelineActivity.schedule",
  "Incident.beginInvestigation",
  "Incident.clearCorrectiveActionLock",
  "Incident.dismiss",
  "Incident.markResolved",
  "Incident.report",
  "Ingredient.classifyAllergens",
  "Ingredient.configureSubstitutes",
  "Ingredient.discontinue",
  "Ingredient.introduce",
  "Ingredient.reinstate",
  "Ingredient.setPreferredVendor",
  "Ingredient.setPreferredVendors",
  "Ingredient.updateCosting",
  "Ingredient.updateDetails",
  "IngredientDemand.calculate",
  "IngredientDemand.confirm",
  "IngredientDemand.ensurePurchaseEligible",
  "IngredientDemand.fulfill",
  "IngredientDemand.markReleased",
  "IngredientDemand.recalculate",
  "IngredientDemand.supersede",
  "IngredientDemand.syncFromContributions",
  "IngredientPriceObservation.record",
  "InventoryItem.adjustQuantity",
  "InventoryItem.open",
  "InventoryItem.receiveStock",
  "InventoryItem.recount",
  "InventoryItem.remove",
  "InventoryItem.setExpiry",
  "InventoryItem.transferIn",
  "InventoryItem.transferOut",
  "InventoryItem.updateLevels",
  "InventoryLot.record",
  "InventoryReservation.consume",
  "InventoryReservation.release",
  "InventoryReservation.reserve",
  "Invoice.applyCredit",
  "Invoice.applyPayment",
  "Invoice.issue",
  "Invoice.markDepositPaid",
  "Invoice.markOverdue",
  "Invoice.markViewed",
  "Invoice.markVoided",
  "Invoice.reassignClient",
  "Invoice.recordCreditMemo",
  "Invoice.recordRefund",
  "Invoice.send",
  "Invoice.sendBalanceReminder",
  "Invoice.setDeposit",
  "Invoice.stageClientMerge",
  "Invoice.writeOff",
  "Lead.capture",
  "Lead.confirmConversion",
  "Lead.confirmProposalSent",
  "Lead.reviseDetails",
  "Lead.stageConversion",
  "Lead.stageProposal",
  "Lead.updatePipeline",
  "Menu.archive",
  "Menu.draft",
  "Menu.markPublished",
  "Menu.restore",
  "Menu.reviseDetails",
  "Menu.unpublish",
  "Menu.updatePricing",
  "MenuDish.add",
  "MenuDish.remove",
  "MenuDish.updateDetails",
  "MenuDish.updateSellingPrice",
  "Organization.configureBranding",
  "Organization.deactivate",
  "Organization.reactivate",
  "Organization.register",
  "Organization.rename",
  "Organization.suspend",
  "OrganizationCapabilitySetting.register",
  "OrganizationCapabilitySetting.setEnabled",
  "PackList.cancel",
  "PackList.dispatch",
  "PackList.markLoaded",
  "PackList.markPacked",
  "PackList.open",
  "PackList.startPacking",
  "PackListItem.addItem",
  "PackListItem.adjustQuantity",
  "PackListItem.markMissing",
  "PackListItem.markPacked",
  "Payment.beginProcessing",
  "Payment.fail",
  "Payment.reassignClient",
  "Payment.record",
  "Payment.refund",
  "Payment.settle",
  "Payment.stageClientMerge",
  "PaymentMethod.clearDefault",
  "PaymentMethod.expire",
  "PaymentMethod.invalidate",
  "PaymentMethod.makeDefault",
  "PaymentMethod.reactivate",
  "PaymentMethod.reassignClient",
  "PaymentMethod.register",
  "PaymentMethod.remove",
  "PaymentMethod.stageClientMerge",
  "PayrollInput.finalize",
  "PayrollInput.markVoided",
  "PayrollInput.prepare",
  "Person.assignRole",
  "Person.correctIdentity",
  "Person.deactivate",
  "Person.hire",
  "Person.reactivate",
  "Person.terminate",
  "PrepTask.cancel",
  "PrepTask.claim",
  "PrepTask.complete",
  "PrepTask.markBlocked",
  "PrepTask.open",
  "PrepTask.refreshGenerated",
  "PrepTask.release",
  "PrepTask.revise",
  "PrepTask.start",
  "PrepTask.unblock",
  "PrepTaskDependency.declare",
  "PrepTaskDependency.satisfy",
  "ProductionBatch.cancel",
  "ProductionBatch.complete",
  "ProductionBatch.plan",
  "ProductionBatch.start",
  "Proposal.accept",
  "Proposal.decline",
  "Proposal.draft",
  "Proposal.expire",
  "Proposal.markViewed",
  "Proposal.reassignClient",
  "Proposal.send",
  "Proposal.stageClientMerge",
  "PurchaseNeed.assignToDraft",
  "PurchaseNeed.cancel",
  "PurchaseNeed.create",
  "PurchaseNeed.markDraftOrdered",
  "PurchaseNeed.markFulfilled",
  "PurchaseNeed.markOrdered",
  "PurchaseNeed.reviseRequired",
  "Qualification.expire",
  "Qualification.grant",
  "Qualification.revoke",
  "QualityCheck.fail",
  "QualityCheck.open",
  "QualityCheck.pass",
  "QualityCheck.reinspect",
  "Recipe.draft",
  "Recipe.publishVersion",
  "Recipe.retire",
  "Recipe.retract",
  "Recipe.reviseDraft",
  "RecipeImport.approveReview",
  "RecipeImport.beginFinalization",
  "RecipeImport.beginReview",
  "RecipeImport.cancel",
  "RecipeImport.complete",
  "RecipeImport.markFailed",
  "RecipeImport.recordParse",
  "RecipeImport.recordRecipe",
  "RecipeImport.recordResolutionProgress",
  "RecipeImport.resumeReview",
  "RecipeImport.upload",
  "RecipeImportLine.attachCreatedIngredient",
  "RecipeImportLine.confirmExisting",
  "RecipeImportLine.confirmNew",
  "RecipeImportLine.discard",
  "RecipeImportLine.markNew",
  "RecipeImportLine.resetResolution",
  "RecipeImportLine.stage",
  "RecipeImportLine.suggestExactMatch",
  "RecipeImportLine.suggestPossibleMatches",
  "RecipeIngredient.add",
  "RecipeIngredient.adjustQuantity",
  "RecipeIngredient.remove",
  "RecipeStep.add",
  "RecipeStep.remove",
  "RecipeStep.revise",
  "RecurringAvailability.declare",
  "RecurringAvailability.withdraw",
  "SavedReportDefinition.archive",
  "SavedReportDefinition.changeSharing",
  "SavedReportDefinition.createDefinition",
  "SavedReportDefinition.rename",
  "SavedReportDefinition.restore",
  "SavedReportDefinition.updateDefinition",
  "Shift.applyApprovedSwap",
  "Shift.cancel",
  "Shift.complete",
  "Shift.markNoShow",
  "Shift.schedule",
  "Shift.stageApprovedSwap",
  "Shift.start",
  "ShiftSwapRequest.accept",
  "ShiftSwapRequest.approve",
  "ShiftSwapRequest.decline",
  "ShiftSwapRequest.propose",
  "ShiftSwapRequest.reject",
  "ShiftSwapRequest.withdraw",
  "ShiftType.define",
  "ShiftType.reactivate",
  "ShiftType.retire",
  "StockCountLine.confirmLedgerMatch",
  "StockCountLine.freeze",
  "StockCountLine.reconcileVariance",
  "StockCountLine.recordCount",
  "StockCountLine.reviseCount",
  "StockCountSession.close",
  "StockCountSession.start",
  "StockTransfer.record",
  "StorageLocation.activate",
  "StorageLocation.deactivate",
  "StorageLocation.register",
  "StorageLocation.reviseDetails",
  "TaxRate.define",
  "TaxRate.revise",
  "TaxRate.setActive",
  "TimeOffRequest.approve",
  "TimeOffRequest.decline",
  "TimeOffRequest.submit",
  "TimeRecord.clockIn",
  "TimeRecord.clockOut",
  "TimeRecord.correct",
  "TrainingCompletion.record",
  "TrainingModule.define",
  "TrainingModule.reactivate",
  "TrainingModule.retire",
  "Vehicle.register",
  "Vehicle.reviseDetails",
  "Vehicle.updateOperationalStatus",
  "Vendor.onboard",
  "Vendor.reinstate",
  "Vendor.suspend",
  "Vendor.terminate",
  "Vendor.updateDetails",
  "VendorOrder.cancel",
  "VendorOrder.confirm",
  "VendorOrder.ensureWeeklyDraft",
  "VendorOrder.markPartiallyReceived",
  "VendorOrder.markReceived",
  "VendorOrder.open",
  "VendorOrder.submit",
  "VendorOrder.updateTotals",
  "VendorOrderLine.addLine",
  "VendorOrderLine.cancelLine",
  "VendorOrderLine.ensureWeeklyLine",
  "VendorOrderLine.recordReceipt",
  "VendorOrderLine.reviseQuantity",
  "VendorOrderLineDemand.link",
  "VendorOrderLineDemand.retire",
  "VendorOrderLineDemand.revise",
  "Venue.activate",
  "Venue.changeCapacity",
  "Venue.deactivate",
  "Venue.register",
  "Venue.updateDetails",
  "WasteRecord.record",
  "WasteRecord.voidRecord",
  "WeeklyPurchasingConfig.configure",
  "WeeklyPurchasingConfig.routeNeed",
  "WeeklyScheduleNotice.acknowledge",
  "WeeklyScheduleNotice.publishSchedule",
  "WeeklyScheduleNotice.republishSchedule"
] as const;
