import type { ComponentType, SVGProps } from "react";
import {
  BoxIcon,
  BuildingIcon,
  CalendarIcon,
  ChartIcon,
  CoinsIcon,
  ContactIcon,
  FlameIcon,
  GearIcon,
  HomeIcon,
  TruckIcon,
  UsersIcon,
} from "../ui/icons";

export interface NavArea {
  path: string;
  label: string;
  group: "Operate" | "People" | "Business" | "System";
  icon: ComponentType<SVGProps<SVGSVGElement>>;
  /** Areas that ship in a later slice render a single "planned" page. */
  planned?: string;
}

export const NAV_AREAS: NavArea[] = [
  { path: "/", label: "Home", group: "Operate", icon: HomeIcon },
  { path: "/events", label: "Events", group: "Operate", icon: CalendarIcon },
  {
    path: "/kitchen",
    label: "Kitchen",
    group: "Operate",
    icon: FlameIcon,
  },
  {
    path: "/inventory",
    label: "Inventory",
    group: "Operate",
    icon: BoxIcon,
  },
  {
    path: "/logistics",
    label: "Logistics",
    group: "Operate",
    icon: TruckIcon,
  },
  {
    path: "/staff",
    label: "Staff",
    group: "People",
    icon: UsersIcon,
  },
  {
    path: "/my",
    label: "My Day",
    group: "People",
    icon: CalendarIcon,
  },
  {
    path: "/clients",
    label: "Clients & CRM",
    group: "People",
    icon: ContactIcon,
  },
  {
    path: "/finance",
    label: "Finance",
    group: "Business",
    icon: CoinsIcon,
  },
  {
    path: "/reports",
    label: "Reports",
    group: "Business",
    icon: ChartIcon,
  },
  {
    path: "/facilities",
    label: "Facilities",
    group: "System",
    icon: BuildingIcon,
  },
  {
    path: "/admin",
    label: "Administration",
    group: "System",
    icon: GearIcon,
  },
];

export const NAV_GROUPS = ["Operate", "People", "Business", "System"] as const;
