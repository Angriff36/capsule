export type CommandFailureCategory =
  "denied" | "validation" | "guard_blocked" | "conflict" | "unexpected";

/** A corrective step the user can take directly from the failure banner. */
export interface CommandFailureAction {
  label: string;
  /** Reload the page — the correct fix for stale/conflict/removed-record failures. */
  reload?: boolean;
}

export interface CommandFailure {
  category: CommandFailureCategory;
  title: string;
  detail: string;
  action?: CommandFailureAction;
}

const REFRESH_ACTION: CommandFailureAction = {
  label: "Refresh & retry",
  reload: true,
};

/** Turn a snake_case stage/state token into readable words ("pending_approval" -> "pending approval"). */
function humanizeState(token: string): string {
  return token.replace(/_/g, " ").trim();
}

/**
 * Parse the generated "Invalid state transition" guard message into plain language.
 * Raw shape: Invalid state transition for 'stage': 'planning' -> 'approved' is not
 * allowed. Allowed from 'planning': ['pending_approval', 'cancelled']
 */
function stateTransitionFailure(detail: string): CommandFailure | null {
  const match = detail.match(
    /Invalid state transition for '[^']+':\s*'([^']+)'\s*->\s*'([^']+)'[^.]*\.\s*Allowed from '[^']+':\s*\[([^\]]*)\]/i,
  );
  if (!match) return null;
  const [, from, to] = match;
  const allowed = (match[3] ?? "")
    .split(",")
    .map((s) => s.replace(/['"\s]/g, ""))
    .filter(Boolean)
    .map(humanizeState);
  const nextSteps =
    allowed.length > 0
      ? `From here you can move it to: ${allowed.join(", ")}.`
      : `It's already ${humanizeState(from)} and can't change from here.`;
  return {
    category: "guard_blocked",
    title: "Not ready for this step yet",
    detail: `This can't move to "${humanizeState(to)}" while it's "${humanizeState(
      from,
    )}". ${nextSteps}`,
  };
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

interface NormalizedCommandError {
  detail: string;
  operation?: string;
  requestId?: string;
}

function normalizeCommandError(error: unknown): NormalizedCommandError {
  const raw = messageOf(error).trim();
  const operation = raw.match(/mutations:([A-Za-z0-9_]+)/)?.[1];
  const requestId = raw.match(/\[Request ID:\s*([^\]]+)\]/i)?.[1];
  const uncaught = raw.match(/Uncaught Error:\s*([^\r\n]+)/i)?.[1];
  const detail = (uncaught ?? raw)
    .replace(/^\[CONVEX [^\]]+\]\s*/, "")
    .replace(/^Server Error\s*/i, "")
    .replace(/^Uncaught Error:\s*/i, "")
    .replace(/^Error:\s*/i, "")
    .replace(/\s+Called by client\s*$/i, "")
    .trim();
  return { detail, operation, requestId };
}

function creationSubject(operation: string | undefined): string {
  const entity = operation?.match(/^([A-Za-z0-9]+)_createVia/)?.[1];
  return entity
    ? entity.replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase()
    : "record";
}

export function classifyCommandFailure(error: unknown): CommandFailure {
  const normalized = normalizeCommandError(error);
  const { detail, operation, requestId } = normalized;
  if (/ConcurrencyConflict|VERSION_MISMATCH/i.test(detail)) {
    return {
      category: "conflict",
      title: "This record changed elsewhere",
      detail:
        "Someone else updated this record while you were working. Refresh to load the latest, then try again — your entered details are still valid.",
      action: REFRESH_ACTION,
    };
  }
  const transition = stateTransitionFailure(detail);
  if (transition) return transition;
  if (/\bnot found\b/i.test(detail)) {
    return {
      category: "conflict",
      title: "This record isn't available",
      detail:
        "It may have been removed, or it isn't part of your workspace. Refresh to see the current list.",
      action: REFRESH_ACTION,
    };
  }
  if (/No tenant|authentication context|not authenticated/i.test(detail)) {
    return {
      category: "denied",
      title: "Workspace access required",
      detail:
        "Your session does not include the workspace access this action requires.",
    };
  }
  if (/staff may|permission|not allowed|policy/i.test(detail)) {
    return { category: "denied", title: "Action denied", detail };
  }
  if (/Guard \d+ failed/i.test(detail) && /_createVia/.test(operation ?? "")) {
    const subject = creationSubject(operation);
    return {
      category: "guard_blocked",
      title: `${subject[0]?.toUpperCase() ?? "R"}${subject.slice(1)} wasn't created`,
      detail: `The ${subject} could not be created because one of its requirements was not met. Nothing was saved.${requestId ? ` Request ID: ${requestId}.` : ""}`,
    };
  }
  if (/Guard \d+ failed|Invalid state transition/i.test(detail)) {
    return {
      category: "guard_blocked",
      title: "Action could not be completed",
      detail: `One of this action's requirements was not met. No changes were saved.${requestId ? ` Request ID: ${requestId}.` : ""}`,
    };
  }
  if (
    /required|must be|cannot be|between|after its start|two characters|Invalid argument|before parsing|Reading the selected file/i.test(
      detail,
    )
  ) {
    return {
      category: "validation",
      title: "Check the entered details",
      detail,
    };
  }
  return {
    category: "unexpected",
    title: "Action failed unexpectedly",
    detail: detail || "The server did not return an error description.",
  };
}
