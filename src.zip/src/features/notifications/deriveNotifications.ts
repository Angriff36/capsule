import type { Doc } from "../../lib/api";
import { formatDate, formatMoney } from "../../lib/format";

/**
 * Client-derived notifications. Capsule reads are live Convex queries, so
 * deriving from row state is already real-time; the compiler does not support
 * child-creating reactions, so there is no generated Notification table to
 * consume (see docs/generation/manifest-builder.md).
 */
export interface AppNotification {
  /** Stable id — read/unread state keys off this. */
  id: string;
  kind:
    | "event_stage"
    | "approval_request"
    | "invoice_overdue"
    | "low_stock"
    | "shift_conflict"
    | "time_off_request"
    | "certification_expiry"
    | "allergen_incident";
  message: string;
  /** Route to the relevant record. */
  link: string;
  /** When the underlying condition arose (sort key). */
  at: number;
}

export const NOTIFICATION_KIND_LABELS: Record<AppNotification["kind"], string> =
  {
    event_stage: "Event",
    approval_request: "Approval",
    invoice_overdue: "Invoice",
    low_stock: "Stock",
    shift_conflict: "Staffing",
    time_off_request: "Time off",
    certification_expiry: "Certification",
    allergen_incident: "Allergen",
  };

/** Stage changes older than this are history, not notifications. */
const RECENT_WINDOW_MS = 7 * 86_400_000;

const STAGE_TIMESTAMPS: Array<{
  stage: string;
  field:
    | "approvedAt"
    | "executionStartedAt"
    | "completedAt"
    | "cancelledAt"
    | "closedOutAt";
  label: string;
}> = [
  { stage: "approved", field: "approvedAt", label: "approved" },
  { stage: "executing", field: "executionStartedAt", label: "in execution" },
  { stage: "completed", field: "completedAt", label: "completed" },
  { stage: "cancelled", field: "cancelledAt", label: "cancelled" },
  { stage: "closed_out", field: "closedOutAt", label: "closed out" },
];

const OVERDUE_ELIGIBLE_STATUSES = new Set(["sent", "viewed", "partial"]);

export interface NotificationSources {
  now: number;
  currentAuthSubjectId: string | undefined;
  events: Doc<"events">[] | undefined;
  incidents: Doc<"incidents">[] | undefined;
  invoices: Doc<"invoices">[] | undefined;
  inventoryItems: Doc<"inventoryItems">[] | undefined;
  ingredients: Doc<"ingredients">[] | undefined;
  shifts: Doc<"shifts">[] | undefined;
  people: Doc<"people">[] | undefined;
  qualifications: Doc<"qualifications">[] | undefined;
  timeOffRequests: Doc<"timeOffRequests">[] | undefined;
}

export function deriveNotifications(
  src: NotificationSources,
): AppNotification[] {
  const out: AppNotification[] = [];
  const { now } = src;

  for (const event of src.events ?? []) {
    if (event.deletedAt != null) continue;
    if (event.stage === "pending_approval") {
      out.push({
        id: `event-approval:${event._id}`,
        kind: "approval_request",
        message: `"${event.title}" is awaiting approval`,
        link: `/events/${event._id}`,
        at: event.updatedAt ?? event.createdAt ?? now,
      });
    }
    const entry = STAGE_TIMESTAMPS.find((s) => s.stage === event.stage);
    if (entry) {
      const at = event[entry.field];
      if (at != null && now - at <= RECENT_WINDOW_MS) {
        out.push({
          id: `event-stage:${event._id}:${event.stage}`,
          kind: "event_stage",
          message: `"${event.title}" is now ${entry.label}`,
          link: `/events/${event._id}`,
          at,
        });
      }
    }
  }

  const eventTitles = new Map(
    (src.events ?? []).map((e) => [e._id as string, e.title]),
  );
  for (const incident of src.incidents ?? []) {
    if (incident.deletedAt != null || incident.reportedAt == null) continue;
    if (incident.category !== "allergen") continue;
    if (incident.status !== "open" && incident.status !== "investigating")
      continue;
    const eventTitle =
      eventTitles.get(incident.eventId as string) ?? "an event";
    out.push({
      id: `allergen-incident:${incident._id}`,
      kind: "allergen_incident",
      message: `Allergen incident reported for "${eventTitle}" — corrective action required`,
      link: `/events/${incident.eventId}`,
      at: incident.reportedAt,
    });
  }

  for (const invoice of src.invoices ?? []) {
    if (invoice.deletedAt != null || invoice.amountDue <= 0) continue;
    const overdue =
      invoice.status === "overdue" ||
      (invoice.dueDate != null &&
        invoice.dueDate < now &&
        OVERDUE_ELIGIBLE_STATUSES.has(invoice.status));
    if (!overdue) continue;
    const label = invoice.invoiceNumber
      ? `Invoice ${invoice.invoiceNumber}`
      : "An invoice";
    out.push({
      id: `invoice-overdue:${invoice._id}`,
      kind: "invoice_overdue",
      message: `${label} is overdue — ${formatMoney(invoice.amountDue)} due`,
      link: `/finance/invoices/${invoice._id}`,
      at: invoice.overdueSince ?? invoice.dueDate ?? now,
    });
  }

  const ingredientNames = new Map(
    (src.ingredients ?? []).map((i) => [i._id as string, i.name]),
  );
  for (const item of src.inventoryItems ?? []) {
    if (item.deletedAt != null || item.removedAt != null) continue;
    if (item.quantityOnHand > item.reorderThreshold) continue;
    const name =
      ingredientNames.get(item.ingredientId as string) ?? "An ingredient";
    out.push({
      id: `low-stock:${item._id}`,
      kind: "low_stock",
      message: `${name} is low: ${item.quantityOnHand} ${item.unit} on hand (reorder at ${item.reorderThreshold})`,
      link: "/inventory/stock",
      at: item.updatedAt ?? now,
    });
  }

  const personNames = new Map(
    (src.people ?? []).map((p) => [
      p._id as string,
      `${p.givenName} ${p.familyName}`.trim(),
    ]),
  );
  for (const request of src.timeOffRequests ?? []) {
    if (
      src.currentAuthSubjectId == null ||
      request.requesterAuthSubjectId === src.currentAuthSubjectId ||
      request.deletedAt != null ||
      request.status !== "pending" ||
      request.submittedAt == null
    ) {
      continue;
    }
    const who = personNames.get(request.personId as string) ?? "A staff member";
    const range =
      request.startsAt != null && request.endsAt != null
        ? `${formatDate(request.startsAt)} – ${formatDate(request.endsAt - 1)}`
        : "requested dates";
    out.push({
      id: `time-off-request:${request._id}`,
      kind: "time_off_request",
      message: `${who} requested time off · ${range}`,
      link: "/staff/time-off",
      at: request.submittedAt,
    });
  }

  const certificationWindowEnd = now + 30 * 86_400_000;
  for (const qualification of src.qualifications ?? []) {
    if (
      qualification.deletedAt != null ||
      qualification.status !== "active" ||
      qualification.expiresAt == null ||
      qualification.expiresAt > certificationWindowEnd
    ) {
      continue;
    }
    const who =
      personNames.get(qualification.personId as string) ?? "A staff member";
    const expired = qualification.expiresAt < now;
    out.push({
      id: `certification-expiry:${qualification._id}`,
      kind: "certification_expiry",
      message: expired
        ? `${who}'s ${qualification.name} expired on ${formatDate(qualification.expiresAt)}`
        : `${who}'s ${qualification.name} expires ${formatDate(qualification.expiresAt)}`,
      link: "/staff/qualifications",
      at: qualification.expiresAt,
    });
  }

  const byPerson = new Map<string, Doc<"shifts">[]>();
  for (const shift of src.shifts ?? []) {
    if (shift.deletedAt != null) continue;
    if (shift.status !== "scheduled" && shift.status !== "started") continue;
    if (shift.startsAt == null || shift.endsAt == null) continue;
    const key = shift.personId as string;
    const list = byPerson.get(key);
    if (list) list.push(shift);
    else byPerson.set(key, [shift]);
  }
  for (const [personId, shifts] of byPerson) {
    shifts.sort((a, b) => (a.startsAt ?? 0) - (b.startsAt ?? 0));
    for (let i = 1; i < shifts.length; i++) {
      const prev = shifts[i - 1];
      const cur = shifts[i];
      if ((cur.startsAt ?? 0) >= (prev.endsAt ?? 0)) continue;
      const who = personNames.get(personId) ?? "A staff member";
      out.push({
        id: `shift-conflict:${prev._id}:${cur._id}`,
        kind: "shift_conflict",
        message: `${who} has overlapping shifts on ${formatDate(cur.startsAt)}`,
        link: "/staff/roster",
        at: cur.startsAt ?? now,
      });
    }
  }

  out.sort((a, b) => b.at - a.at);
  return out;
}
